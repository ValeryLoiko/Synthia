//
//  LogoutUsersResponse.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 22/03/2023.
//

import Foundation

struct LogoutUsersResponse: Codable {
  let message: String
  let status: String
}
