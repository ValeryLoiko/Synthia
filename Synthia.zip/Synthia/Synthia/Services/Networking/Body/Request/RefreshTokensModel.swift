//
//  RefreshTokensModel.swift
//  Synthia
//
//  Created by Sławek on 06/03/2023.
//

import Foundation

struct RefreshTokensModel: Codable {
    let refreshToken: String
}
