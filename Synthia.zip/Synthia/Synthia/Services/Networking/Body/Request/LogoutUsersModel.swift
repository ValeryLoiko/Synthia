//
//  LogoutUsersModel.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 22/03/2023.
//

import Foundation

struct LogoutUsersModel: Codable {
    let refreshToken: String
}
