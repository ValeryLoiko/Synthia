//
//  Localization+Buttons.swift
//  Synthia
//
//  Created by Sławek on 16/12/2022.
//

import Foundation

extension Localization {
    enum Buttons {
        static let signInWithEmailButton = String(localized: "sign_in_with_email_button")
        static let createNewAccountButton = String(localized: "create_new_account_button")
        static let registerButton = String(localized: "register_button")
        static let forgotPasswordButton = String(localized: "forgot_password_button")
        static let googleLoginButton = String(localized: "google_login_button")
        static let resetButton = String(localized: "reset_password_button")
        static let confirmButton = String(localized: "confimr_button")
        static let startButton = String(localized: "start_app_button")
        static let nextButton = String(localized: "next_setup_account_button")
        static let listOfSupportedDevicesButton = String(localized: "list_of_supported_devices_button")
        static let addNewDeviceButton = String(localized: "add_new_device_button")
        static let addNewDataButton = String(localized: "add_new_data_button")
        static let signinOrJoinButton = String(localized: "login_button_welcome_screen")
        static let startUsingNowButton = String(localized: "no_login_button_welcome_screen")
        static let signInButton = String(localized: "sing_in_button")
        static let resetEmailButton = String(localized: "resend_email_button")
        static let continueButton = String(localized: "continue_button")
        static let acceptButton = String(localized: "accept_terms_button")
        static let declineButton = String(localized: "decline_terms_button")
        static let editButton = String(localized: "edit_button")
        static let addButton = String(localized: "add_button")
        static let measurementsHistoryButton = String(localized: "measurements_history")
        
        enum GuideTourScreen {
            static let skipGuideTourButton = String(localized: "guidetour_skip_button")
            static let nextButton = String(localized: "guidetour_next_button")
            static let startButton = String(localized: "guidetour_start_button")
            static let getStartedButton = String(localized: "guidetour_getstarted_button")
        }
        
        enum AccountSetupScreen {
            static let skipButton = String(localized: "skip_account_setup_button")
            static let nextButton = String(localized: "next_setup_account_button")
        }
    }
}
