//
//  Localization+LoginSingupScreen.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import Foundation

extension Localization {
    enum LoginSingupScreen {
        static let title = String(localized: "title_LoginSignup_screen")
        static let emailLabel = String(localized: "email_label")
        static let orLabel = String(localized: "or_label")
    }
}
