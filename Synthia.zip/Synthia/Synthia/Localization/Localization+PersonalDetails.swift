//
//  Localization+PersonalDetails.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 15/03/2023.
//

import Foundation
extension Localization {
    enum PersonalDetailsScreen {
        static let measurements = String(localized: "title_meaurements_screen")
        static let personalDetails = String(localized: "personal_details")
        static let measurementUnit = String(localized: "measurement_result_unit")
        static let metric = String(localized: "metric")
        static let imperial = String(localized: "imperial")
        static let unassignedValue = String(localized: "unassigned")
        static let temperatureFormat = String(localized: "temperature_format")
        static let firstName = String(localized: "first_name")
        static let lastName = String(localized: "last_name")
        static let age = String(localized: "age")
        static let sex = String(localized: "sex")
        static let height = String(localized: "height")
        static let weight = String(localized: "weight")
    }
}
