//
//  Localization+GuideTour.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 18/01/2023.
//

import Foundation

extension Localization {
    enum GuideTour {
        static let titleView1 = String(localized: "guideTour_title_view1")
        static let titleView2 = String(localized: "guideTour_title_view2")
        static let titleView3 = String(localized: "guideTour_title_view3")
        static let titleView4 = String(localized: "guideTour_title_view4")
        static let subTitleView1 = String(localized: "guideTour_subtitle_view1")
        static let subTitleView2 = String(localized: "guideTour_subtitle_view2")
        static let subTitleView3 = String(localized: "guideTour_subtitle_view3")
        static let subTitleView4 = String(localized: "guideTour_subtitle_view4")
    }
}
