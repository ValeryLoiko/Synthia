//
//  Localization+SupportedDevices.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/03/2023.
//

import Foundation
extension Localization {
    enum SupportedDevices {
        static let title = String(localized: "title_supported_devices")
        static let placeholder = String(localized: "supported_devices_textfield_placeholder")
        static let thermometer = "device_type_thermometers"
        static let scale = "device_type_scale"
        static let pressure = "device_type_pressure_sensors"
    }
}
