//
//  Localization+SearchingScreen.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 21/02/2023.
//

import Foundation

extension Localization {
    enum SearchingScreen {
        static let title = String(localized: "title_searching_screen")
        static let subtitleLabel = String(localized: "searching_screen_subtitle")
        static let subtitleLabelTap = String(localized: "searching_timeLimit_subtitle_tap")
        static let timeLimitTitle = String(localized: "searching_timeLimit_title")
        static let timeLimitSubtitle = String(localized: "searching_timeLimit_subtitle")
        static let troublesButton = String(localized: "searching_troubles_button")
    }
}
