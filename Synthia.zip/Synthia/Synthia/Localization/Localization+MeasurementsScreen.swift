//
//  Localization+MeasurementsScreen.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 12/01/2023.
//

import Foundation

extension Localization {
    enum MeasurementsScreen {
        static let title = String(localized: "title_meaurements_screen")
    }
}
