//
//  Localization+OnboardingScreen.swift
//  Synthia
//
//  Created by Sławek on 23/12/2022.
//

import Foundation

extension Localization {
    enum WelcomeScreen {
        static let titleView1 = String(localized: "welcomeScreen_title_view1")
        static let titleView2 = String(localized: "welcomeScreen_title_view2")
        static let titleView3 = String(localized: "welcomeScreen_title_view3")
        static let titleView4 = String(localized: "welcomeScreen_title_view4")
        static let subTitleView1 = String(localized: "welcomeScreen_subtitle_view1")
        static let subTitleView2 = String(localized: "welcomeScreen_subtitle_view2")
        static let subTitleView3 = String(localized: "welcomeScreen_subtitle_view3")
        static let subTitleView4 = String(localized: "welcomeScreen_subtitle_view4")
    }
}
