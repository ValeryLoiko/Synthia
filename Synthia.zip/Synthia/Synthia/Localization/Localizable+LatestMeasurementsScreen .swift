//
//  Localizable+LatestMeasurementsScreen .swift
//  Synthia
//
//  Created by Walery Łojko on 17/02/2023.
//

import Foundation

extension Localization {
    enum LatestMeasurementsScreen {
        static let title = String(localized: "title_latest_measurement")
    }
}
