//
//  Localization+ResetEmailScreen.swift
//  Synthia
//
//  Created by Sławek on 10/01/2023.
//

import Foundation

extension Localization {
    enum ResetEmailScreen {
        static let title = String(localized: "title_resetEmailSent_screen")
        static let infoLabel = String(localized: "reset_emial_sent_info")
        static let codeLabel = String(localized: "code_label")
        static let codeLabelPlaceholder = String(localized: "code_label_placeholder")
        static let newPasswordLabel = String(localized: "new_password_label")
        static let confimrNewPasswordLabel = String(localized: "confirm_new_password_label")
    }
}
