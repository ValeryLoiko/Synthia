//
//  Localization+TermsConditionsScreen.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import Foundation

extension Localization {
    enum TermsConditionsScreen {
        static let title = String(localized: "title_terms_conditions")
        static let alertTitle = String(localized: "alert_title")
        static let messageAlert = String(localized: "alert_message")
    }
}
