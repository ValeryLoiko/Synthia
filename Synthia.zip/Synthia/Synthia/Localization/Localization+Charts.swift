//
//  Localization+Charts.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 07/03/2023.
//

import Foundation
extension Localization {
    enum MeasurementChartsScreen {
        static let periods = [String(localized: "period_day"), String(localized: "period_week"), String(localized: "period_month")]
        static let reminders = String(localized: "reminders")
        static let historyLabel = String(localized: "history_label")
        static let addDataType = String(localized: "add_data_list_title")
    }
}
