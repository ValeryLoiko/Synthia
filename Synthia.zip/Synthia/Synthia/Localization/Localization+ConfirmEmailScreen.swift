//
//  Localization+ConfirmEmailScreen.swift
//  Synthia
//
//  Created by Sławek on 10/01/2023.
//

import Foundation

extension Localization {
    enum ConfirmEmailScreen {
        static let title = String(localized: "title_confirmEmail_screen")
        static let infoLabel = String(localized: "confirm_eamil_label_info")
        static let alertTitle = String(localized: "config_email_alert_title")
        static let alertMessage = String(localized: "congig_email_alert_message")
    }
}
