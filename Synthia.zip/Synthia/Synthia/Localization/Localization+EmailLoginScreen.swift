//
//  Localization+EmailLoginScreen.swift
//  Synthia
//
//  Created by Sławek on 23/12/2022.
//

import Foundation

extension Localization {
    enum EmailLoginScreen {
        static let title = String(localized: "title_emailLogin_screen")
        static let emailLabel = String(localized: "email_label")
        static let passwordLabel = String(localized: "password_label")
    }
}
