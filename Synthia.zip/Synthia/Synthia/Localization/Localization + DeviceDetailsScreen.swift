//
//  Localization + DeviceDetailsScreen.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import Foundation

extension Localization {
    enum DeviceDetailsScreen {
        static let title = String(localized: "device_name")
        static let deviceConnected = String(localized: "device_connected")
        static let deviceNotConnected = String(localized: "device_not_connected")
        static let tryConnect = String(localized: "try_connect")
        static let disconnect = String(localized: "disconnect")
        static let measurHistoryButtonTitle = String(localized: "measurements_history")
        static let detailsLabel = String(localized: "details_label")
        static let deviceNamePlaceholder = String(localized: "device_name_placeholder")
        static let multipleUserstitle = String(localized: "multiple_users")
        static let manufacturer = String(localized: "manufacturer")
        static let serialNumber = String(localized: "serial_number")
        static let model = String(localized: "model")
        static let firmware = String(localized: "Firmware")
    }
}
