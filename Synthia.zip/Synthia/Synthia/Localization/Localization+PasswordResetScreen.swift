//
//  Localization+PasswordResetScreen.swift
//  Synthia
//
//  Created by Sławek on 10/01/2023.
//

import Foundation

extension Localization {
    enum PasswordResetScreen {
        static let title = String(localized: "title_resetPassword_screen")
        static let infoLabel = String(localized: "reset_password_label_info")
    }
}
