//
//  Localization+AccountSetUpScreen.swift
//  Synthia
//
//  Created by Walery Łojko on 12/01/2023.
//

import Foundation

extension Localization {
    enum AccountSetUpScreen {
        static let skipButton = String(localized: "skip_button")
        static let nameLabel = String(localized: "name_label")
        static let sexLabel = String(localized: "sex_label")
        static let ageLabel = String(localized: "age_label")
        static let heightLabel = String(localized: "height_label")
        static let weightLabel = String(localized: "weight_label")
        static let questionName = String(localized: "question_name")
        static let questionNameLabelInfo = String(localized: "info_label_name")
        static let questionSex = String(localized: "question_sex")
        static let subtitleSexLabel = String(localized: "info_label_sex")
        static let sexOther = String(localized: "sex_other")
        static let sexMale = String(localized: "sex_male")
        static let sexFemale = String(localized: "sex_female")
        static let ageScreenQuestion = String(localized: "age_screen_question_label")
        static let ageScreenSubtitle = String(localized: "age_screen_subtitle_label")
        static let ageScreenTextFieldTitle = String(localized: "age_screen_textfield_title")
        static let ageScreenTextFieldPlaceholder = String(localized: "age_screen_textfield_placeholder")
        static let heightScreenQuestion = String(localized: "height_screen_question_label")
        static let heightScreenSubtitle = String(localized: "height_screen_subtitle_label")
        static let heightScreenHeightTextFieldTitle = String(localized: "height_screen_height_textfield_title")
        static let heightScreenHeightTextFieldPlaceholder = String(localized: "height_screen_height_textfield_placeholder")
        static let weightScreenHeightTextFieldTitle = String(localized: "height_screen_weight_textfield_title")
        static let weightScreenHeightTextFieldPlaceholder = String(localized: "height_screen_weight_textfield_placeholder")
        static let kgUnit = String(localized: "kg_unit")
        static let cmUnit = String(localized: "cm_unit")
    }
}
