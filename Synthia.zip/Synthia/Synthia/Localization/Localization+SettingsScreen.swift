//
//  Localization+SettingsScreen.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 12/01/2023.
//

import Foundation

extension Localization {
    enum SettingsScreen {
        static let title = String(localized: "title_settings_screen")
        static let personalDetails = String(localized: "personal_details")
        static let createAccount = String(localized: "create_account")
        static let notificationsSettings = String(localized: "notifications_settings")
        static let notifications = String(localized: "notifications")
        static let notificationsSublabel = String(localized: "notifications_sublabel")
        static let guideTour = String(localized: "guide_tour")
        static let repeatGuideTour = String(localized: "repeat_guide_tour")
        static let welcomeScreen = String(localized: "welcome_screen")
        static let legal = String(localized: "legal")
        static let termsConditions = String(localized: "terms_conditions")
        static let privacy = String(localized: "privacy")
        static let deleteAllData = String(localized: "delete_all_data")
        static let changePassword = String(localized: "change_password")
        static let logOut = String(localized: "log_out")
        static let deleteAccount = String(localized: "delete_account")
        static let appVersion = String(localized: "app_version")
        static let deleteAccountAlertTitle = String(localized: "delete_account_alert_title")
        static let deleteAccountAlertMessage = String(localized: "delete_account_alert_message")
        static let deleteAllDataTitle = String(localized: "delete_all_data_alert_title")
        static let deleteAllDataMessage = String(localized: "delete_all_data_alert_message")
    }
}
