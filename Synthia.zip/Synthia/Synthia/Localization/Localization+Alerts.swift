//
//  Localization+Alerts.swift
//  Synthia
//
//  Created by Walery Łojko on 12/01/2023.
//

import Foundation

extension Localization {
    enum Alerts {
        static let removeDeviceTitle = String(localized: "remove_device_title")
        static let removeDeviceMessage = String(localized: "remove_device_message")
        static let removeDeviceDevice = String(localized: "remove_device_device")
        static let removeDeviceDeviceData = String(localized: "remove_device_device_data")
        static let areYouSureTitle = String(localized: "are_you_sure_title")
        static let areYouSureMessage = String(localized: "are_you_sure_message")
        static let remove = String(localized: "remove")
        static let cancel = String(localized: "cancel")
        static let quit = String(localized: "quit")
        static let confirm = String(localized: "confirm")
        static let pair = String(localized: "pair")
        static let areYouSurePair = String(localized: "are_you_sure_pair")
        static let numberOfUsersTitle = String(localized: "number_of_users_title")
        static let numberOfUsersMessage = String(localized: "number_of_users_message")
        static let onlyUser = String(localized: "only_user")
        static let multipleUsers = String(localized: "multiple_users")
        static let noRegistrationTitle = String(localized: "no_registration_title")
        static let noRegistrationMessage = String(localized: "no_registration_message")
        static let continueButtonTitle = String(localized: "continue_button")
    }
}
