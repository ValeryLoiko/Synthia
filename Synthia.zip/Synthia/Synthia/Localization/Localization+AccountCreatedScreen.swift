//
//  Localization+AccountCreatedScreen.swift
//  Synthia
//
//  Created by Sławek on 10/01/2023.
//

import Foundation

extension Localization {
    enum CreatedAccountScreen {
        static let title = String(localized: "title_accountCreated_screen")
        static let labelInfo = String(localized: "account_created_label_info")
    }
}
