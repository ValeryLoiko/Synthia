//
//  Localization.swift
//  Synthia
//
//  Created by Sławek on 16/12/2022.
//

import Foundation

enum Localization {}
