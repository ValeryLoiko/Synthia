//
//  Localization+EmailSignupScreen.swift
//  Synthia
//
//  Created by Sławek on 23/12/2022.
//

import Foundation

extension Localization {
    enum EmailSignupScreen {
        static let title = String(localized: "title_emailSingup_screen")
        static let emailLabel = String(localized: "email_label")
        static let passwordLabel = String(localized: "password_label")
        static let repeatLabel = String(localized: "repeat_password_label")
    }
}
