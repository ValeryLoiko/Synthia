//
//  Localization+Validation.swift
//  Synthia
//
//  Created by Walery Łojko on 24/01/2023.
//

import Foundation

extension Localization {
    enum ValidationErrors {
        static let emptyEmail = String(localized: "empty_email")
        static let emailFormat = String(localized: "email_format")
        static let oneUppercase = String(localized: "one_uppercase")
        static let oneDigit = String(localized: "one_digit")
        static let oneSymbol = String(localized: "one_symbol")
        static let oneLovercase = String(localized: "one_lovercase")
        static let eightCharacters = String(localized: "8_characters")
        static let moreCharacters = String(localized: "256_characters")
        static let enterYourCode = String(localized: "your_code")
        static let sixDigits = String(localized: "enter_6_digits")
        static let notTheSame = String(localized: "not_the_same")
        static let invalidAge = String(localized: "invalid_age")
        static let emptyAge = String(localized: "empty_age")
        static let emptyWeight = String(localized: "empty_weight")
        static let invalidWeight = String(localized: "invalid_weight")
        static let emptyHeight = String(localized: "empty_height")
        static let invalidHeight = String(localized: "invalid_height")
        static let emptySex = String(localized: "empty_sex")
        static let emptyUsername = String(localized: "empty_username")
        static let newDataValidationError = String(localized: "invalid_data")
    }
}
