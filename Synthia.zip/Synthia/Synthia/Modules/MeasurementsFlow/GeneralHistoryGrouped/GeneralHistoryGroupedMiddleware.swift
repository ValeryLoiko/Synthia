//
//  GeneralHistoryGroupedMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import RxSwift

final class GeneralHistoryGroupedMiddlewareImpl: GeneralHistoryGroupedMiddleware, GeneralHistoryGroupedCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = GeneralHistoryGroupedResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showGeneralHistorySingle(measurementName: let measurementName, day: let day):
                dependencies.appNavigation?.showGeneralHistorySingle(measurementName: measurementName, day: day)
            case .measurementDeleted:
                break
            }
        }
        return .just(result)
    }
}
