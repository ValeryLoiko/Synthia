//
//  GeneralHistoryGroupedContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import RxSwift
import Foundation

enum GeneralHistoryGroupedIntent {
    case viewLoaded
    case cellTapped(measurementName: MeasurementName, day: Date)
    case deleteMeasurement(row: Int)
}

struct GeneralHistoryGroupedViewState: Equatable {
    var measurementName: MeasurementName
    var measurements: [Measurement] = []
}

enum GeneralHistoryGroupedEffect: Equatable {
    case showGeneralHistorySingle(measurementName: MeasurementName, day: Date)
    case measurementDeleted
}

struct GeneralHistoryGroupedBuilderInput {
    var measurementName: MeasurementName
}

protocol GeneralHistoryGroupedCallback {
}

enum GeneralHistoryGroupedResult: Equatable {
    case partialState(_ value: GeneralHistoryGroupedPartialState)
    case effect(_ value: GeneralHistoryGroupedEffect)
}

enum GeneralHistoryGroupedPartialState: Equatable {
    case updateMeasurementsArray(measurements: [Measurement])
    func reduce(previousState: GeneralHistoryGroupedViewState) -> GeneralHistoryGroupedViewState {
        var state = previousState
        switch self {
        case .updateMeasurementsArray(measurements: let measurements):
            state.measurements = measurements
        }
        return state
    }
}

protocol GeneralHistoryGroupedBuilder {
    func build(with input: GeneralHistoryGroupedBuilderInput) -> GeneralHistoryGroupedModule
}

struct GeneralHistoryGroupedModule {
    let view: GeneralHistoryGroupedView
    let callback: GeneralHistoryGroupedCallback
}

protocol GeneralHistoryGroupedView: BaseView {
    var intents: Observable<GeneralHistoryGroupedIntent> { get }
    func render(state: GeneralHistoryGroupedViewState)
}

protocol GeneralHistoryGroupedPresenter: AnyObject, BasePresenter {
    func bindIntents(view: GeneralHistoryGroupedView, triggerEffect: PublishSubject<GeneralHistoryGroupedEffect>) -> Observable<GeneralHistoryGroupedViewState>
}

protocol GeneralHistoryGroupedInteractor: BaseInteractor {
    func loadMeasurements() -> Observable<GeneralHistoryGroupedResult>
    func deleteMeasurement(at row: Int) -> Observable<GeneralHistoryGroupedResult>
}

protocol GeneralHistoryGroupedMiddleware {
    var middlewareObservable: Observable<GeneralHistoryGroupedResult> { get }
    func process(result: GeneralHistoryGroupedResult) -> Observable<GeneralHistoryGroupedResult>
}
