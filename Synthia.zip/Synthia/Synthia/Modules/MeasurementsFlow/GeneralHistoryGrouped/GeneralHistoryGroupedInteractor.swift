//
//  GeneralHistoryGroupedInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import RxSwift
import Foundation

final class GeneralHistoryGroupedInteractorImpl: GeneralHistoryGroupedInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = GeneralHistoryGroupedResult
    
    private let dependencies: Dependencies
    private let input: GeneralHistoryGroupedBuilderInput

    init(dependencies: Dependencies, input: GeneralHistoryGroupedBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    private var measurementsArray: [Measurement] = []

    func loadMeasurements() -> RxSwift.Observable<GeneralHistoryGroupedResult> {
        dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByName(name: self.input.measurementName)
                    .asObservable()
            }
            .map({ measurements -> [Measurement] in
                measurements.map { measurement in
                    Measurement(deviceId: measurement.deviceId, name: measurement.name, value: measurement.value, unit: measurement.unit, measurementDate: measurement.measurementDate, measurementID: measurement.measurementID)
                }
            })
            .map({ savedMeasurements -> GeneralHistoryGroupedResult in
                let calendar = Calendar.current
                let groupingComponentFlags: Set<Calendar.Component> = [.year, .month, .day]
                let groupedMeasurements = Dictionary(grouping: savedMeasurements) { measurement in
                    calendar.dateComponents(groupingComponentFlags, from: measurement.measurementDate)
                }
                let latestMeasurements = groupedMeasurements.compactMap { _, measurements in
                    measurements.sorted { $0.measurementDate > $1.measurementDate }.first
                }.sorted { $0.measurementDate > $1.measurementDate }
                self.measurementsArray = latestMeasurements
                return .partialState(.updateMeasurementsArray(measurements: latestMeasurements))
            })
            .asObservable()
    }
    
    func deleteMeasurement(at row: Int) -> RxSwift.Observable<GeneralHistoryGroupedResult> {
        let chosenMeasurement = measurementsArray[row]
        dependencies.measurementsPersistanceService.deleteMeasurementsFromSelectedDay(measurement: chosenMeasurement)
        return .just(.effect(.measurementDeleted))
    }
}
