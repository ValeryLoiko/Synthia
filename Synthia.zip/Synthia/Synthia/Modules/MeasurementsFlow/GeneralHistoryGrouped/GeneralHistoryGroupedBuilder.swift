//
//  GeneralHistoryGroupedBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import UIKit
import RxSwift

final class GeneralHistoryGroupedBuilderImpl: GeneralHistoryGroupedBuilder {
    typealias Dependencies = GeneralHistoryGroupedInteractorImpl.Dependencies & GeneralHistoryGroupedMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: GeneralHistoryGroupedBuilderInput) -> GeneralHistoryGroupedModule {
        let interactor = GeneralHistoryGroupedInteractorImpl(dependencies: dependencies, input: input)
        let middleware = GeneralHistoryGroupedMiddlewareImpl(dependencies: dependencies)
        let presenter = GeneralHistoryGroupedPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: GeneralHistoryGroupedViewState(measurementName: input.measurementName))
        let view = GeneralHistoryGroupedViewController(presenter: presenter)
        return GeneralHistoryGroupedModule(view: view, callback: middleware)
    }
}
