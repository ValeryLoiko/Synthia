//
//  MeasurementsScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class MeasurementsScreenViewController: BaseViewController, MeasurementsScreenView {
    typealias ViewState = MeasurementsScreenViewState
    typealias Effect = MeasurementsScreenEffect
    typealias Intent = MeasurementsScreenIntent
    typealias B = Localization.Buttons
    typealias M = Localization.MeasurementsScreen
    
    @IntentSubject() var intents: Observable<MeasurementsScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: MeasurementsScreenPresenter
    
    private let dataSubject = PublishSubject<[Measurement]>()
    
    private lazy var addDataButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringPlus, title: B.addNewDataButton)
        button.addTarget(self, action: #selector(addDataPressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var downloadButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.leftDownload, title: "")
        button.addTarget(self, action: #selector(downloadButtonPressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var latestMeasurementsLabel: UILabel = {
        let label = UILabel()
        label.text = M.title
        label.tintColor = .blackColor
        label.font = .OpenSansSemiBold28
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.register(SavedMeasurementsCell.self, forCellReuseIdentifier: SavedMeasurementsCell.identifier)
        tableView.layer.cornerRadius = 8
        tableView.separatorStyle = .none
        tableView.rowHeight = 120
        return tableView
    }()
    
    init(presenter: MeasurementsScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        _intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        self.navigationItem.rightBarButtonItem = addDataButton
        self.navigationItem.leftBarButtonItem = downloadButton
        view.backgroundColor = .devicesScreenBackgroundColor
        view.addSubview(latestMeasurementsLabel)
        view.addSubview(tableView)
        view.backgroundColor = .devicesScreenBackgroundColor
        
        latestMeasurementsLabel.snp.makeConstraints {
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(8)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(40)
        }
        
        tableView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(latestMeasurementsLabel.snp.bottom).offset(16)
            $0.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).inset(16)
        }
    }
    
    private func bindControls() {
        dataSubject.bind(to: tableView.rx.items(cellIdentifier: SavedMeasurementsCell.identifier, cellType: SavedMeasurementsCell.self)) { _, item, cell in
            cell.configureCell(measurementName: item.name.rawValue, measurementResult: item.value, measurementResultUnit: item.unit, measurementDate: item.measurementDate)
        }
        .disposed(by: bag)
        
        tableView.rx.modelSelected(Measurement.self)
            .subscribe(onNext: { [weak self] measurement in
                self?._intents.subject.onNext(.cellTapped(measurementName: measurement.name))
        })
        .disposed(by: bag)
    }
    
    @objc private func addDataPressed() {
        _intents.subject.onNext(.addDataPressed)
    }
    
    @objc private func downloadButtonPressed() {
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showAddDataList:
            break
        case .showChartsScreen(measurementName: _):
            break
        default:
            break
        }
    }
    
    func render(state: ViewState) {
        dataSubject.onNext(state.measurementsArray)
    }
}
