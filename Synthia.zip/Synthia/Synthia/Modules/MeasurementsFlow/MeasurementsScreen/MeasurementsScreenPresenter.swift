//
//  MeasurementsScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift

final class MeasurementsScreenPresenterImpl: MeasurementsScreenPresenter {
    typealias View = MeasurementsScreenView
    typealias ViewState = MeasurementsScreenViewState
    typealias Middleware = MeasurementsScreenMiddleware
    typealias Interactor = MeasurementsScreenInteractor
    typealias Effect = MeasurementsScreenEffect
    typealias Result = MeasurementsScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { intent -> Observable<Result> in
            switch intent {
            case .addDataPressed:
                return .just(.effect(.showAddDataList))
            case .viewLoaded:
                return self.interactor.loadMeasurements()
            case .cellTapped(measurementName: let measurementName):
                return .just(.effect(.showChartsScreen(measurementName: measurementName)))
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
