//
//  MeasurementsScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift

enum MeasurementsScreenIntent {
    case viewLoaded
    case addDataPressed
    case cellTapped(measurementName: MeasurementName)
}

struct MeasurementsScreenViewState: Equatable {
    var measurementsArray: [Measurement] = []
}

enum MeasurementsScreenEffect: Equatable {
    case showAddDataList
    case showChartsScreen(measurementName: MeasurementName)
    case measurementsLoaded
}

struct MeasurementsScreenBuilderInput {
}

protocol MeasurementsScreenCallback {
}

enum MeasurementsScreenResult: Equatable {
    case partialState(_ value: MeasurementsScreenPartialState)
    case effect(_ value: MeasurementsScreenEffect)
}

enum MeasurementsScreenPartialState: Equatable {
    case somethingWentWrong
    case measurementsErorr
    case updateData(measurements: [Measurement])
    func reduce(previousState: MeasurementsScreenViewState) -> MeasurementsScreenViewState {
        var state = previousState
        switch self {
        case .updateData(measurements: let measurements):
            state.measurementsArray = measurements
        case .somethingWentWrong:
            print("something Went Wrong")
        case .measurementsErorr:
            print("something Went Wrong")
        }
        return state
    }
}

protocol MeasurementsScreenBuilder {
    func build(with input: MeasurementsScreenBuilderInput) -> MeasurementsScreenModule
}

struct MeasurementsScreenModule {
    let view: MeasurementsScreenView
    let callback: MeasurementsScreenCallback
}

protocol MeasurementsScreenView: BaseView {
    var intents: Observable<MeasurementsScreenIntent> { get }
    func render(state: MeasurementsScreenViewState)
}

protocol MeasurementsScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: MeasurementsScreenView, triggerEffect: PublishSubject<MeasurementsScreenEffect>) -> Observable<MeasurementsScreenViewState>
}

protocol MeasurementsScreenInteractor: BaseInteractor {
    func loadMeasurements() -> Observable<MeasurementsScreenResult>
    func fetchLatestMeasurements() -> Observable<MeasurementsScreenResult>
    func getMeasurementsFromBackend() -> RxSwift.Observable<MeasurementsScreenResult>
}

protocol MeasurementsScreenMiddleware {
    var middlewareObservable: Observable<MeasurementsScreenResult> { get }
    func process(result: MeasurementsScreenResult) -> Observable<MeasurementsScreenResult>
}
