//
//  MeasurementsScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift
import Foundation

final class MeasurementsScreenInteractorImpl: MeasurementsScreenInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService & HasNetworkingService & HasAccessManager
    typealias Result = MeasurementsScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func loadMeasurements() -> RxSwift.Observable<MeasurementsScreenResult> {
        return dependencies.accessManager.userStateRelay
            .flatMapLatest({ state -> Observable<MeasurementsScreenResult> in
                var result: Observable<MeasurementsScreenResult>
                if state == .loggedIn {
                    result = .merge(
                        self.getMeasurementsFromBackend()
                        .startWith(MeasurementsScreenResult.effect(.measurementsLoaded)),
                        self.fetchLatestMeasurements()
                            .startWith(MeasurementsScreenResult.effect(.measurementsLoaded))
                    )
                } else {
                    result = self.fetchLatestMeasurements()
                        .startWith(MeasurementsScreenResult.effect(.measurementsLoaded))
                }
                return result
            })
    }
    
    func fetchLatestMeasurements() -> RxSwift.Observable<MeasurementsScreenResult> {
        return dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchLatestMeasurementsForEachType()
                    .asObservable()
            }
            .map { measurements in
                let sortedMeasurements = measurements.sorted(by: { $0.measurementDate > $1.measurementDate })
                return .partialState(.updateData(measurements: sortedMeasurements))
            }
            .asObservable()
    }
    
    func getMeasurementsFromBackend() -> RxSwift.Observable<MeasurementsScreenResult> {
        return dependencies.networkingService.execute(request: API.Endpoint.getMeasurements(beforeTime: nil, afterTime: nil, deviceName: nil, deviceAddress: nil, typeId: nil), decodingFormat: .jsonArray)
            .flatMap { (response: [GetMeasurementsResponse]) in
                let measurements = response.map { measurementsResponse in
                    Measurement(from: measurementsResponse)
                }
                    .sorted(by: { $0.measurementDate > $1.measurementDate })
                self.dependencies.measurementsPersistanceService.saveMeasurementsFromBackend(measurements: measurements)
                return .just(.effect(.measurementsLoaded))
            }
            .asObservable()
            .catch { error -> Observable<MeasurementsScreenResult> in
                guard let apiError = error as? ApiError else {
                    return .just(.partialState(.somethingWentWrong)) }
                    switch apiError {
                    case .statusCode(let int):
                        guard GetUserResponse.Code(rawValue: int) != nil else {
                            return .just(.partialState(.somethingWentWrong))
                        }
                        return .just(.partialState(.measurementsErorr))
                }
            }
    }
}
