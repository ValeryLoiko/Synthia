//
//  MeasurementsScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import UIKit
import RxSwift

final class MeasurementsScreenBuilderImpl: MeasurementsScreenBuilder {
    typealias Dependencies = MeasurementsScreenInteractorImpl.Dependencies & MeasurementsScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: MeasurementsScreenBuilderInput) -> MeasurementsScreenModule {
        let interactor = MeasurementsScreenInteractorImpl(dependencies: dependencies)
        let middleware = MeasurementsScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = MeasurementsScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: MeasurementsScreenViewState())
        let view = MeasurementsScreenViewController(presenter: presenter)
        return MeasurementsScreenModule(view: view, callback: middleware)
    }
}
