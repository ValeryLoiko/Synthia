//
//  GeneralHistorySingleInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import RxSwift

final class GeneralHistorySingleInteractorImpl: GeneralHistorySingleInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = GeneralHistorySingleResult
    
    private let dependencies: Dependencies
    private let input: GeneralHistorySingleBuilderInput
    
    init(dependencies: Dependencies, input: GeneralHistorySingleBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    private var measurementsArray: [Measurement] = []
    
    func loadMeasurements() -> RxSwift.Observable<GeneralHistorySingleResult> {
        dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByDateName(name: self.input.measurementName, date: self.input.date)
                    .asObservable()
            }
            .map({ measurements -> [Measurement] in
                measurements.map { measurement in
                    Measurement(deviceId: measurement.deviceId, name: measurement.name, value: measurement.value, unit: measurement.unit, measurementDate: measurement.measurementDate, measurementID: measurement.measurementID)
                }
            })
            .map({ savedMeasurements -> GeneralHistorySingleResult in
                let sortedMeasurements = savedMeasurements.sorted { $0.measurementDate > $1.measurementDate }
                self.measurementsArray = sortedMeasurements
                return .partialState(.updateMeasurementsArray(measurements: sortedMeasurements))
            })
            .asObservable()
    }
    
    func deleteMeasurement(at row: Int) -> RxSwift.Observable<GeneralHistorySingleResult> {
        dependencies.measurementsPersistanceService.deleteMeasurement(measurementID: measurementsArray[row].measurementID)
        return .just(.effect(.measurementDeleted))
    }
}
