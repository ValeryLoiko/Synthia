//
//  GeneralHistorySingleBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import UIKit
import RxSwift

final class GeneralHistorySingleBuilderImpl: GeneralHistorySingleBuilder {
    typealias Dependencies = GeneralHistorySingleInteractorImpl.Dependencies & GeneralHistorySingleMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: GeneralHistorySingleBuilderInput) -> GeneralHistorySingleModule {
        let interactor = GeneralHistorySingleInteractorImpl(dependencies: dependencies, input: input)
        let middleware = GeneralHistorySingleMiddlewareImpl(dependencies: dependencies)
        let presenter = GeneralHistorySinglePresenterImpl(interactor: interactor, middleware: middleware, initialViewState: GeneralHistorySingleViewState(measurementName: input.measurementName, date: input.date))
        let view = GeneralHistorySingleViewController(presenter: presenter)
        return GeneralHistorySingleModule(view: view, callback: middleware)
    }
}
