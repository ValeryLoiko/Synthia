//
//  GeneralHistorySingleContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import RxSwift
import Foundation

enum GeneralHistorySingleIntent {
    case viewLoaded
    case deleteMeasurement(row: Int)
}

struct GeneralHistorySingleViewState: Equatable {
    var measurementName: MeasurementName
    var date: Date
    var measurements: [Measurement] = []
}

enum GeneralHistorySingleEffect: Equatable {
    case measurementDeleted
}

struct GeneralHistorySingleBuilderInput {
    var measurementName: MeasurementName
    var date: Date
}

protocol GeneralHistorySingleCallback {
}

enum GeneralHistorySingleResult: Equatable {
    case partialState(_ value: GeneralHistorySinglePartialState)
    case effect(_ value: GeneralHistorySingleEffect)
}

enum GeneralHistorySinglePartialState: Equatable {
    case updateMeasurementsArray(measurements: [Measurement])
    func reduce(previousState: GeneralHistorySingleViewState) -> GeneralHistorySingleViewState {
        var state = previousState
        switch self {
        case .updateMeasurementsArray(measurements: let measurements):
            state.measurements = measurements
        }
        return state
    }
}

protocol GeneralHistorySingleBuilder {
    func build(with input: GeneralHistorySingleBuilderInput) -> GeneralHistorySingleModule
}

struct GeneralHistorySingleModule {
    let view: GeneralHistorySingleView
    let callback: GeneralHistorySingleCallback
}

protocol GeneralHistorySingleView: BaseView {
    var intents: Observable<GeneralHistorySingleIntent> { get }
    func render(state: GeneralHistorySingleViewState)
}

protocol GeneralHistorySinglePresenter: AnyObject, BasePresenter {
    func bindIntents(view: GeneralHistorySingleView, triggerEffect: PublishSubject<GeneralHistorySingleEffect>) -> Observable<GeneralHistorySingleViewState>
}

protocol GeneralHistorySingleInteractor: BaseInteractor {
    func loadMeasurements() -> Observable<GeneralHistorySingleResult>
    func deleteMeasurement(at row: Int) -> Observable<GeneralHistorySingleResult>
}

protocol GeneralHistorySingleMiddleware {
    var middlewareObservable: Observable<GeneralHistorySingleResult> { get }
    func process(result: GeneralHistorySingleResult) -> Observable<GeneralHistorySingleResult>
}
