//
//  GeneralHistorySingleViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 01/03/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class GeneralHistorySingleViewController: BaseViewController, GeneralHistorySingleView {
    typealias ViewState = GeneralHistorySingleViewState
    typealias Effect = GeneralHistorySingleEffect
    typealias Intent = GeneralHistorySingleIntent
    
    @IntentSubject() var intents: Observable<GeneralHistorySingleIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: GeneralHistorySinglePresenter
    
    private enum Constants {
        static let rowHeight = 56
    }
    
    private var measurementsSubject = PublishSubject<[Measurement]>()
    private var numberOfMeasurementsSubject = PublishSubject<Int>()
    private var isDeleteTableViewVisible = false

    init(presenter: GeneralHistorySinglePresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var editButton: UIBarButtonItem = {
        let button: UIButton = Button(style: .rightStringBlack, title: Localization.Buttons.editButton)
        button.addTarget(self, action: #selector(editMeasurement), for: .touchUpInside)
        let editButton = UIBarButtonItem(customView: button)
        return editButton
    }()
    
    private lazy var generalStackView: UIStackView = {
        let view = UIStackView()
        view.axis = .horizontal
        view.distribution = .fill
        view.backgroundColor = .clear
        view.spacing = 5
        return view
    }()
    
    private var mainTableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .singleLine
        tableView.separatorColor = .black
        tableView.rowHeight = 56
        tableView.register(MeasurementSingleDataCell.self, forCellReuseIdentifier: MeasurementSingleDataCell.identifier)
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.black.cgColor
        tableView.layer.cornerRadius = 8
        return tableView
    }()
    
    private var deleteTableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.separatorColor = .none
        tableView.rowHeight = 56
        tableView.register(DeleteDataCell.self, forCellReuseIdentifier: DeleteDataCell.identifier)
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = false
        self.navigationItem.setHidesBackButton(false, animated: true)
        navigationItem.rightBarButtonItem = editButton
        view.addSubview(generalStackView)
        generalStackView.addArrangedSubview(mainTableView)
        generalStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
        }
    }
    
    private func calculateHeightOfTableView(numberOfRows: Int) {
        let tableViewHeight = numberOfRows * Constants.rowHeight
        
        generalStackView.snp.remakeConstraints {
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(tableViewHeight)
        }
    }
    
    private func bindControls() {
        measurementsSubject
            .bind(to: mainTableView.rx.items(cellIdentifier: MeasurementSingleDataCell.identifier, cellType: MeasurementSingleDataCell.self)) { _, item, cell in
                let date = Date.utcToLocalNoYear(utcDate: item.measurementDate)
                cell.configureCell(measurementResult: "\(item.value) \(item.unit.rawValue)", measurementData: date)
            }
            .disposed(by: bag)
        
        measurementsSubject.bind(to: deleteTableView.rx.items(cellIdentifier: DeleteDataCell.identifier, cellType: DeleteDataCell.self)) { _, _, _ in
        }
        .disposed(by: bag)
        
        numberOfMeasurementsSubject.distinctUntilChanged()
            .subscribe(onNext: {
                self.calculateHeightOfTableView(numberOfRows: $0)
            })
            .disposed(by: bag)
        
        deleteTableView.rx.itemSelected
            .subscribe(onNext: { indexPath in
                self._intents.subject.onNext(.deleteMeasurement(row: indexPath.row))
            })
            .disposed(by: bag)
    }
    
    @objc private func editMeasurement() {
        if !isDeleteTableViewVisible {
            generalStackView.addArrangedSubview(deleteTableView)
            deleteTableView.snp.remakeConstraints {
                $0.width.equalToSuperview().multipliedBy(0.1)
            }
            isDeleteTableViewVisible = true
        } else {
            generalStackView.removeArrangedSubview(deleteTableView)
            generalStackView.addArrangedSubview(mainTableView)
            isDeleteTableViewVisible = false
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .measurementDeleted:
            break
        }
    }
    
    func render(state: ViewState) {
        title = state.measurementName.rawValue
        measurementsSubject.onNext(state.measurements)
        numberOfMeasurementsSubject.onNext(state.measurements.count)
    }
}
