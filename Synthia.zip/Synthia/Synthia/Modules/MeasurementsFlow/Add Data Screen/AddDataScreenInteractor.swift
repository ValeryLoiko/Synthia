//
//  AddDataScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import RxSwift

final class AddDataScreenInteractorImpl: AddDataScreenInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService & HasNetworkingService & HasKeychainManager & HasAccessManager
    typealias Result = AddDataScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func addNewMeasurement(newMeasurement: Measurement) -> RxSwift.Observable<AddDataScreenResult> {
        return dependencies.accessManager.userStateRelay
            .flatMapLatest({ state -> Observable<AddDataScreenResult> in
                var result: Observable<AddDataScreenResult>
                if state == .loggedIn {
                    result = self.saveNewMeasurementToCD(newMeasurement: newMeasurement)
                        .startWith(AddDataScreenResult.effect(.measurementAdded(measurement: newMeasurement)))
                } else {
                    result = self.saveNewMeasurementToCD(newMeasurement: newMeasurement)
                        .startWith(AddDataScreenResult.effect(.measurementAdded(measurement: newMeasurement)))
                }
                return result
            })
    }
    
    func saveNewMeasurementToCD(newMeasurement: Measurement) -> RxSwift.Observable<AddDataScreenResult> {
        dependencies.measurementsPersistanceService.saveNewMeasurement(measurement: newMeasurement)
        return .just(.effect(.dismissScreen))
    }
}
