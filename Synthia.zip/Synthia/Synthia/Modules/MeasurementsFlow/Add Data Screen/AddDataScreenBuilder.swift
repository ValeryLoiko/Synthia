//
//  AddDataScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import UIKit
import RxSwift

final class AddDataScreenBuilderImpl: AddDataScreenBuilder {
    typealias Dependencies = AddDataScreenInteractorImpl.Dependencies & AddDataScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AddDataScreenBuilderInput) -> AddDataScreenModule {
        let interactor = AddDataScreenInteractorImpl(dependencies: dependencies)
        let middleware = AddDataScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = AddDataScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AddDataScreenViewState(dataType: input.dataType))
        let view = AddDataScreenViewController(presenter: presenter)
        return AddDataScreenModule(view: view, callback: middleware)
    }
}
