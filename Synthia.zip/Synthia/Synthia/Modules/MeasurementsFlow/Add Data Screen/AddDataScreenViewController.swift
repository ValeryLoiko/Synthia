//
//  AddDataScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AddDataScreenViewController: BaseViewController, AddDataScreenView {
    typealias ViewState = AddDataScreenViewState
    typealias Effect = AddDataScreenEffect
    typealias Intent = AddDataScreenIntent
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<AddDataScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AddDataScreenPresenter
    
    var chosenMeasurement: MeasurementName = .unknown
    
    private lazy var addDataButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringBlack, title: B.addButton)
        button.addTarget(self, action: #selector(addDataPressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var addDataView = AddDataView()
    
    init(presenter: AddDataScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        addDataButton.isEnabled = false
        addDataView.datePicker.maximumDate = Date()
        addDataView.timePicker.maximumDate = Date()
    }
    
    private func layoutView() {
        self.navigationItem.rightBarButtonItem = addDataButton
        view.addSubview(addDataView)
        
        addDataView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.height.equalTo(200)
        }
    }
    
    private func bindControls() {
    }
    
    private func validateUserInput() {
        addDataView.textField.validateMeasurementInput(measurementType: chosenMeasurement)
            .skip(1)
            .subscribe(onNext: { [weak self] error in
                self?.addDataView.errorLabel.text = error
                switch error.isEmpty {
                case true: self?.addDataButton.isEnabled = true
                default: self?.addDataButton.isEnabled = false
                }
            })
            .disposed(by: bag)
    }
    
    @objc private func addDataPressed() {
        let date = DateOnly(from: addDataView.datePicker.date)
        let time = TimeOnly(from: addDataView.timePicker.date)
        let combinedDate = Date.combineDate(utcDate: date, utcTime: time)
        let unit = MeasurementName.getUnitForMeasurement(measurementName: chosenMeasurement)
        if let text = addDataView.textField.text, let result = Double(text) {
            let measurementToSave = Measurement(deviceId: "", name: chosenMeasurement, value: result, unit: unit, measurementDate: combinedDate, measurementID: UUID().uuidString)
            _intents.subject.onNext(.addButtonTapped(measurement: measurementToSave))
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .measurementAdded(measurement: _):
            break
        case .dismissScreen:
            break
        }
    }
    
    func render(state: ViewState) {
        self.title = state.dataType.rawValue
        chosenMeasurement = state.dataType
        addDataView.configureResultView(measurementName: state.dataType.rawValue)
        let unit = MeasurementName.getUnitForMeasurement(measurementName: state.dataType)
        addDataView.textField.placeholder = unit.rawValue
        validateUserInput()
    }
}
