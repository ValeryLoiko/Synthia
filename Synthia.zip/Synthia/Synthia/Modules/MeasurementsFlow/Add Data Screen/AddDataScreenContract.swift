//
//  AddDataScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import RxSwift

enum AddDataScreenIntent {
    case addButtonTapped(measurement: Measurement)
}

struct AddDataScreenViewState: Equatable {
    var dataType: MeasurementName
}

enum AddDataScreenEffect: Equatable {
    case measurementAdded(measurement: Measurement)
    case dismissScreen
}

struct AddDataScreenBuilderInput {
    var dataType: MeasurementName
}

protocol AddDataScreenCallback {
}

enum AddDataScreenResult: Equatable {
    case partialState(_ value: AddDataScreenPartialState)
    case effect(_ value: AddDataScreenEffect)
}

enum AddDataScreenPartialState: Equatable {
    func reduce(previousState: AddDataScreenViewState) -> AddDataScreenViewState {
        let state = previousState
        switch self {
        }
        return state
    }
}

protocol AddDataScreenBuilder {
    func build(with input: AddDataScreenBuilderInput) -> AddDataScreenModule
}

struct AddDataScreenModule {
    let view: AddDataScreenView
    let callback: AddDataScreenCallback
}

protocol AddDataScreenView: BaseView {
    var intents: Observable<AddDataScreenIntent> { get }
    func render(state: AddDataScreenViewState)
}

protocol AddDataScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AddDataScreenView, triggerEffect: PublishSubject<AddDataScreenEffect>) -> Observable<AddDataScreenViewState>
}

protocol AddDataScreenInteractor: BaseInteractor {
    func addNewMeasurement(newMeasurement: Measurement) -> RxSwift.Observable<AddDataScreenResult>
}

protocol AddDataScreenMiddleware {
    var middlewareObservable: Observable<AddDataScreenResult> { get }
    func process(result: AddDataScreenResult) -> Observable<AddDataScreenResult>
}
