//
//  AddDataListPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import RxSwift

final class AddDataListPresenterImpl: AddDataListPresenter {
    typealias View = AddDataListView
    typealias ViewState = AddDataListViewState
    typealias Middleware = AddDataListMiddleware
    typealias Interactor = AddDataListInteractor
    typealias Effect = AddDataListEffect
    typealias Result = AddDataListResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { intent -> Observable<Result> in
            switch intent {
            case .cellTapped(dataType: let dataType):
                return .just(.effect(.showAddDataScreen(dataType: dataType)))
            case .dismissScreen:
                return .just(.effect(.dismiss))
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
