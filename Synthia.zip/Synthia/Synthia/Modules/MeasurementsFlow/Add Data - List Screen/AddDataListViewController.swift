//
//  AddDataListViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AddDataListViewController: BaseViewController, AddDataListView {
    typealias ViewState = AddDataListViewState
    typealias Effect = AddDataListEffect
    typealias Intent = AddDataListIntent
    
    @IntentSubject() var intents: Observable<AddDataListIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AddDataListPresenter
    
    private var dataTypeSubject = PublishSubject<[MeasurementName]>()
    
    private lazy var backButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.leftBackButton, title: "")
        button.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var addButton: UIBarButtonItem = {
        let button: UIButton = Button(style: .rightStringBlack, title: Localization.Buttons.addButton)
        button.addTarget(self, action: #selector(addNewType), for: .touchUpInside)
        let editButton = UIBarButtonItem(customView: button)
        return editButton
    }()
    
    private var tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .singleLine
        tableView.separatorColor = .black
        tableView.rowHeight = 56
        tableView.register(AddDataListCell.self, forCellReuseIdentifier: AddDataListCell.identifier)
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.black.cgColor
        tableView.layer.cornerRadius = 8
        return tableView
    }()
    
    init(presenter: AddDataListPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = false
        navigationItem.rightBarButtonItem = addButton
        navigationItem.leftBarButtonItem = backButton
        self.title = L.MeasurementChartsScreen.addDataType
        view.addSubview(tableView)
        
        tableView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).inset(16)
        }
    }
    
    private func bindControls() {
        dataTypeSubject
            .bind(to: tableView.rx.items(cellIdentifier: AddDataListCell.identifier, cellType: AddDataListCell.self)) { _, item, cell in
                cell.configureCell(dataType: item.rawValue)
            }
            .disposed(by: bag)
        
        tableView.rx.modelSelected(MeasurementName.self)
            .subscribe(onNext: { [weak self] measurementName in
            self?._intents.subject.onNext(.cellTapped(dataType: measurementName))
        })
        .disposed(by: bag)
    }
    
    @objc private func backButtonPressed() {
        _intents.subject.onNext(.dismissScreen)
      }
    
    @objc private func addNewType() {
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showAddDataScreen(dataType: _):
            break
        case .dismiss:
            break
        }
    }
    
    func render(state: ViewState) {
        dataTypeSubject.onNext(state.dataTypeArray.sorted(by: { $0.rawValue < $1.rawValue }))
    }
}
