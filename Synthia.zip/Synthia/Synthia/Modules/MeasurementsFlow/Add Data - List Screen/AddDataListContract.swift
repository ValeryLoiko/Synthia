//
//  AddDataListContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import RxSwift

enum AddDataListIntent {
    case cellTapped(dataType: MeasurementName)
    case dismissScreen
}

struct AddDataListViewState: Equatable {
    var dataTypeArray = Array(MeasurementName.allCases)
}

enum AddDataListEffect: Equatable {
    case showAddDataScreen(dataType: MeasurementName)
    case dismiss
}

struct AddDataListBuilderInput {
}

protocol AddDataListCallback {
}

enum AddDataListResult: Equatable {
    case partialState(_ value: AddDataListPartialState)
    case effect(_ value: AddDataListEffect)
}

enum AddDataListPartialState: Equatable {
    func reduce(previousState: AddDataListViewState) -> AddDataListViewState {
        let state = previousState
        switch self {
        }
        return state
    }
}

protocol AddDataListBuilder {
    func build(with input: AddDataListBuilderInput) -> AddDataListModule
}

struct AddDataListModule {
    let view: AddDataListView
    let callback: AddDataListCallback
}

protocol AddDataListView: BaseView {
    var intents: Observable<AddDataListIntent> { get }
    func render(state: AddDataListViewState)
}

protocol AddDataListPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AddDataListView, triggerEffect: PublishSubject<AddDataListEffect>) -> Observable<AddDataListViewState>
}

protocol AddDataListInteractor: BaseInteractor {
}

protocol AddDataListMiddleware {
    var middlewareObservable: Observable<AddDataListResult> { get }
    func process(result: AddDataListResult) -> Observable<AddDataListResult>
}
