//
//  AddDataListBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import UIKit
import RxSwift

final class AddDataListBuilderImpl: AddDataListBuilder {
    typealias Dependencies = AddDataListInteractorImpl.Dependencies & AddDataListMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AddDataListBuilderInput) -> AddDataListModule {
        let interactor = AddDataListInteractorImpl(dependencies: dependencies)
        let middleware = AddDataListMiddlewareImpl(dependencies: dependencies)
        let presenter = AddDataListPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AddDataListViewState())
        let view = AddDataListViewController(presenter: presenter)
        return AddDataListModule(view: view, callback: middleware)
    }
}
