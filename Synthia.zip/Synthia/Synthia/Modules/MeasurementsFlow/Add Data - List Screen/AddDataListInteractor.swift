//
//  AddDataListInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/02/2023.
//

import RxSwift

final class AddDataListInteractorImpl: AddDataListInteractor {
    typealias Dependencies = Any
    typealias Result = AddDataListResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
}
