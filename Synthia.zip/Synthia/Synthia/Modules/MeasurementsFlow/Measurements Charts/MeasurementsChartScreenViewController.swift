//
//  MeasurementsChartScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 27/02/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit
import Charts

final class MeasurementsChartScreenViewController: BaseViewController, MeasurementsChartScreenView, ChartViewDelegate {
    typealias ViewState = MeasurementsChartScreenViewState
    typealias Effect = MeasurementsChartScreenEffect
    typealias Intent = MeasurementsChartScreenIntent
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<MeasurementsChartScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: MeasurementsChartScreenPresenter
    
    private let periods = L.MeasurementChartsScreen.periods
    private let valuesLabelTextRelay = BehaviorRelay<String>(value: "")
    private let dateLabelTextRelay = BehaviorRelay<String>(value: "")
    private var chartEntries = [ChartDataEntry]()
    private var chosenMeasurementName: MeasurementName = .unknown
    
    private lazy var addDataButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringPlus, title: "")
        button.addTarget(self, action: #selector(addDataPressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var segmentedControl: UISegmentedControl = {
        let control = UISegmentedControl(items: periods)
        control.selectedSegmentIndex = 0
        return control
    }()
    
    private lazy var valuesLabel: UILabel = {
        let label = UILabel()
        label.tintColor = .blackColor
        label.font = .OpenSansSemiBold28
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        return label
    }()
    
    private lazy var unitsLabel: UILabel = {
        let label = UILabel()
        label.textColor = .lightGray
        label.font = .OpenSansSemiBold16
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        return label
    }()
    
    private lazy var resultsStackView: UIStackView = {
        let contentView = UIStackView(arrangedSubviews: [valuesLabel, unitsLabel])
        contentView.axis = .horizontal
        contentView.distribution = .fill
        contentView.spacing = 4
        return contentView
    }()
    
    private lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.textColor = .lightGray
        label.font = .OpenSansRegular16
        label.textAlignment = .left
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    private lazy var chartView: LineChartView = {
        let chartView = LineChartView()
        chartView.backgroundColor = .clear
        chartView.borderColor = .red
        chartView.leftAxis.enabled = false
        chartView.legend.enabled = false
//        chartView.dragEnabled = false
//        chartView.scaleXEnabled = false
//        chartView.scaleYEnabled = false
//        chartView.pinchZoomEnabled = false
//        chartView.enabl
        
        let yAxis = chartView.rightAxis
        yAxis.gridColor = .clear
        yAxis.setLabelCount(4, force: false)
        yAxis.labelTextColor = .lightGray
        yAxis.axisLineColor = .lightGray
        yAxis.axisLineDashLengths = [8, 6]
        yAxis.gridLineDashPhase = 2
        
        let xAxis = chartView.xAxis
        xAxis.setLabelCount(4, force: false)
        xAxis.labelTextColor = .lightGray
        xAxis.axisLineColor = .lightGray
        xAxis.gridLineDashLengths = [8, 6]
        xAxis.gridLineDashPhase = 2
        xAxis.gridColor = .gray
        xAxis.labelPosition = .bottom
        xAxis.drawLabelsEnabled = false
        xAxis.valueFormatter = IndexAxisValueFormatter()
        return chartView
    }()
    
    private lazy var remindersLabel: UILabel = {
        let label = UILabel()
        label.text = L.MeasurementChartsScreen.reminders
        label.textColor = .black
        label.font = .OpenSansSemiBold16
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        return label
    }()
    
    private lazy var remindersButton = Button.reminderButton()
    
    private lazy var remindersStackView: UIStackView = {
        let contentView = UIStackView(arrangedSubviews: [remindersLabel, remindersButton])
        contentView.axis = .vertical
        contentView.distribution = .fill
        contentView.spacing = 8
        return contentView
    }()
    
    private lazy var historyLabel: UILabel = {
        let label = UILabel()
        label.text = L.MeasurementChartsScreen.historyLabel
        label.textColor = .black
        label.font = .OpenSansSemiBold16
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .left
        return label
    }()
    
    private lazy var measurementsHistoryButton = Button.measurementsHistoryButton()
    
    private lazy var historyStackView: UIStackView = {
        let contentView = UIStackView(arrangedSubviews: [historyLabel, measurementsHistoryButton])
        contentView.axis = .vertical
        contentView.distribution = .fill
        contentView.spacing = 8
        return contentView
    }()
    
    init(presenter: MeasurementsChartScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
//        self._intents.subject.onNext(.viewLoaded)
        self._intents.subject.onNext(.segmentControlIntent(index: 0))
        self.configureChart(index: 0)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = false
        self.navigationItem.rightBarButtonItem = addDataButton
        view.addSubview(segmentedControl)
        view.addSubview(resultsStackView)
        view.addSubview(dateLabel)
        view.addSubview(chartView)
        view.addSubview(historyStackView)
//        view.addSubview(remindersStackView)
        
        segmentedControl.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(24)
            $0.height.equalTo(32)
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
        }
        
        resultsStackView.snp.makeConstraints {
            $0.left.equalToSuperview().inset(24)
            $0.top.equalTo(segmentedControl.snp.bottom).offset(16)
            $0.height.equalTo(40)
        }
        
        dateLabel.snp.makeConstraints {
            $0.left.equalToSuperview().inset(24)
            $0.right.equalToSuperview().inset(8)
            $0.height.equalTo(24)
            $0.top.equalTo(resultsStackView.snp.bottom)
        }
        
        chartView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(12)
            $0.height.equalTo(280)
            $0.top.equalTo(dateLabel.snp.bottom).offset(16)
        }
        
        historyStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(24)
            $0.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).inset(40)
        }
        
        historyLabel.snp.makeConstraints {
            $0.height.equalTo(24)
        }
        
        measurementsHistoryButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
        
//        remindersStackView.snp.makeConstraints {
//            $0.left.right.equalToSuperview().inset(24)
//            $0.bottom.equalTo(historyStackView.snp.top).offset(-16)
//        }
//
//        remindersLabel.snp.makeConstraints {
//            $0.height.equalTo(24)
//        }
//
//        remindersButton.snp.makeConstraints {
//            $0.height.equalTo(56)
//        }
    }
    
    private func bindControls() {
        segmentedControl.rx.selectedSegmentIndex
            .subscribe { index in
                if let chosenIndex = index.element {
                    self._intents.subject.onNext(.segmentControlIntent(index: chosenIndex))
                    self.configureChart(index: chosenIndex)
                }
            }
            .disposed(by: bag)
        
//        remindersButton.rx.tap
//            .subscribe(onNext: { [weak self] _ in
//            })
//            .disposed(by: bag)
        
        measurementsHistoryButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let self = self else { return }
                self._intents.subject.onNext(.measurementsHistoryIntent(chosenMeasurent: self.chosenMeasurementName))
            })
            .disposed(by: bag)
        
        valuesLabelTextRelay
            .bind(to: valuesLabel.rx.text)
            .disposed(by: bag)
        
        dateLabelTextRelay
            .bind(to: dateLabel.rx.text)
            .disposed(by: bag)
    }
    
    @objc private func addDataPressed() {
        _intents.subject.onNext(.addDataPressed)
    }
    
    private func configureChart(index: Int) {
        let calendar = Calendar.current
        let today = Date()
        let beginningOfDay = calendar.startOfDay(for: today)
        let beginningOfDayTimeInterval = beginningOfDay.timeIntervalSince1970
        if let endOfDay = calendar.date(byAdding: .day, value: 1, to: beginningOfDay)?.addingTimeInterval(-1), let data = chartView.data {
            let endOfDayTimeInterval = endOfDay.timeIntervalSince1970
            let xAxis = chartView.xAxis
            xAxis.axisMaximum = Double(endOfDayTimeInterval)
            chartView.rightAxis.axisMinimum = data.yMin - (data.yMax - data.yMin) * 0.1
            chartView.rightAxis.axisMaximum = data.yMax + (data.yMax - data.yMin) * 0.1
            // swiftlint:disable: force_unwrapping
            switch index {
            case 0:
                xAxis.axisMinimum = Double(beginningOfDayTimeInterval)
            case 1:
                let lastWeek = calendar.date(byAdding: .weekOfYear, value: -1, to: Date())
                let timeInterval = lastWeek?.timeIntervalSince1970
                xAxis.axisMinimum = Double(timeInterval!)
            case 2:
                let lastMonth = calendar.date(byAdding: .month, value: -1, to: Date())
                let timeInterval = lastMonth?.timeIntervalSince1970
                xAxis.axisMinimum = Double(timeInterval!)
            default:
                xAxis.axisMinimum = Double(beginningOfDayTimeInterval)
            }
            // swiftlint:enable: force_unwrapping
            chartView.notifyDataSetChanged()
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        default: break
        }
    }
    
    private func getRangeOfValues(measurements: [Measurement]) {
        if let minValue = measurements.min(by: { $0.value < $1.value }), let maxValue = measurements.max(by: { $0.value < $1.value }) {
            let text = "\(minValue.value)-\(maxValue.value)"
            valuesLabelTextRelay.accept(text)
        }
    }
    
    private func getRangeOfDates(measurements: [Measurement]) {
        if let latestDate = measurements.max(by: { $0.measurementDate < $1.measurementDate })?.measurementDate, let oldestDate = measurements.min(by: { $0.measurementDate < $1.measurementDate })?.measurementDate {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "EEEE, d MMMM yyyy"
            let oldestDateString = dateFormatter.string(from: oldestDate)
            let latestDateString = dateFormatter.string(from: latestDate)
            var text = ""
            if oldestDateString == latestDateString {
                text = latestDateString
            } else {
                text = "\(oldestDateString)-\(latestDateString)"
            }
            dateLabelTextRelay.accept(text)
        }
    }
    
    func render(state: ViewState) {
        self.title = state.chosenMeasurement.rawValue
        unitsLabel.text = MeasurementName.getUnitForMeasurement(measurementName: chosenMeasurementName).rawValue
        getRangeOfValues(measurements: state.measurements)
        getRangeOfDates(measurements: state.measurements)
        chosenMeasurementName = state.chosenMeasurement
        let dataSet = LineChartDataSet(entries: state.chartEntries)
        dataSet.lineWidth = 2
        dataSet.setColor(.black)
        dataSet.circleRadius = 4
        dataSet.circleHoleRadius = 2
        dataSet.setCircleColor(.black)
        chartView.data = LineChartData(dataSet: dataSet)
        chartView.notifyDataSetChanged()
    }
    // swiftlint:disable:next file_length
}
