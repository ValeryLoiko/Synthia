//
//  MeasurementsChartScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 27/02/2023.
//

import RxSwift
import Foundation
import Charts

final class MeasurementsChartScreenInteractorImpl: MeasurementsChartScreenInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = MeasurementsChartScreenResult
    
    private let dependencies: Dependencies
    private let input: MeasurementsChartScreenBuilderInput
    
    init(dependencies: Dependencies, input: MeasurementsChartScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    var measurementsArray = [Measurement]()
    
    func fetchMeasurementsByRange(index: Int) -> RxSwift.Observable<MeasurementsChartScreenResult> {
        let currentDate = Date()
        let calendar = Calendar.current
        return dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByType(name: self.input.chosenMeasurement)
                    .asObservable()
            }
            .map { measurements in
                var chartEntries: [ChartDataEntry] = []
                var filteredMeasurements: [Measurement] = []
                // swiftlint:disable: force_unwrapping
                switch index {
                case 0:
                    filteredMeasurements = measurements.filter { measurement in
                        return calendar.isDate(measurement.measurementDate, inSameDayAs: currentDate)
                    }
                case 1:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.weekOfYear], from: measurement.measurementDate, to: currentDate)
                        return components.weekOfYear! <= 1
                    }
                    
                case 2:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.month], from: measurement.measurementDate, to: currentDate)
                        return components.month! <= 1
                    }
                default:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.day], from: measurement.measurementDate, to: currentDate)
                        return components.day! <= 1
                    }
                    // swiftlint:enable: force_unwrapping
                }
                filteredMeasurements = filteredMeasurements.sorted { $0.measurementDate < $1.measurementDate }
                return .partialState(.fetchMeasurementsByRange(measurements: filteredMeasurements))
            }
            .asObservable()
    }
    
    func updateChartEntries(index: Int) -> RxSwift.Observable<MeasurementsChartScreenResult> {
        let currentDate = Date()
        let calendar = Calendar.current
        return dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByType(name: self.input.chosenMeasurement)
                    .asObservable()
            }
            .map { measurements in
                var chartEntries: [ChartDataEntry] = []
                var filteredMeasurements: [Measurement] = []
                // swiftlint:disable: force_unwrapping
                switch index {
                case 0:
                    filteredMeasurements = measurements.filter { measurement in
                        return calendar.isDate(measurement.measurementDate, inSameDayAs: currentDate)
                    }
                case 1:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.weekOfYear], from: measurement.measurementDate, to: currentDate)
                        return components.weekOfYear! <= 1
                    }
                    
                case 2:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.month], from: measurement.measurementDate, to: currentDate)
                        return components.month! <= 1
                    }
                default:
                    filteredMeasurements = measurements.filter { measurement in
                        let components = calendar.dateComponents([.day], from: measurement.measurementDate, to: currentDate)
                        return components.day! <= 1
                    }
                    // swiftlint:enable: force_unwrapping
                }
                filteredMeasurements.sorted { $0.measurementDate < $1.measurementDate }
                    .map { measurement in
                        let chartEntry = ChartDataEntry(x: Double(measurement.measurementDate.timeIntervalSince1970), y: measurement.value)
                        chartEntries.append(chartEntry)
                    }
                return .partialState(.updateChartEntries(chartEntries: chartEntries))
            }
            .asObservable()
    }
}
