//
//  MeasurementsChartScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 27/02/2023.
//

import RxSwift
import Charts
enum MeasurementsChartScreenIntent {
    case segmentControlIntent(index: Int)
    case addDataPressed
    case measurementsHistoryIntent(chosenMeasurent: MeasurementName)
}

struct MeasurementsChartScreenViewState: Equatable {
    var chosenMeasurement: MeasurementName
    var measurements: [Measurement] = []
    var chartEntries: [ChartDataEntry] = []
}

enum MeasurementsChartScreenEffect: Equatable {
    case measurementsLoaded
    case showAddDataScreen(chosenMeasurement: MeasurementName)
    case showMeasurementHistory(chosenMeasurement: MeasurementName)
}

struct MeasurementsChartScreenBuilderInput {
    var chosenMeasurement: MeasurementName
}

protocol MeasurementsChartScreenCallback {
}

enum MeasurementsChartScreenResult: Equatable {
    case partialState(_ value: MeasurementsChartScreenPartialState)
    case effect(_ value: MeasurementsChartScreenEffect)
}

enum MeasurementsChartScreenPartialState: Equatable {
    case fetchMeasurementsByRange(measurements: [Measurement])
    case updateChartEntries(chartEntries: [ChartDataEntry])
    func reduce(previousState: MeasurementsChartScreenViewState) -> MeasurementsChartScreenViewState {
        var state = previousState
        switch self {
        case .updateChartEntries(chartEntries: let chartEntries):
            state.chartEntries = chartEntries
        case .fetchMeasurementsByRange(measurements: let measurements):
            state.measurements = measurements
        }
        return state
    }
}

protocol MeasurementsChartScreenBuilder {
    func build(with input: MeasurementsChartScreenBuilderInput) -> MeasurementsChartScreenModule
}

struct MeasurementsChartScreenModule {
    let view: MeasurementsChartScreenView
    let callback: MeasurementsChartScreenCallback
}

protocol MeasurementsChartScreenView: BaseView {
    var intents: Observable<MeasurementsChartScreenIntent> { get }
    func render(state: MeasurementsChartScreenViewState)
}

protocol MeasurementsChartScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: MeasurementsChartScreenView, triggerEffect: PublishSubject<MeasurementsChartScreenEffect>) -> Observable<MeasurementsChartScreenViewState>
}

protocol MeasurementsChartScreenInteractor: BaseInteractor {
    func fetchMeasurementsByRange(index: Int) -> RxSwift.Observable<MeasurementsChartScreenResult>
    func updateChartEntries(index: Int) -> Observable<MeasurementsChartScreenResult>
}

protocol MeasurementsChartScreenMiddleware {
    var middlewareObservable: Observable<MeasurementsChartScreenResult> { get }
    func process(result: MeasurementsChartScreenResult) -> Observable<MeasurementsChartScreenResult>
}
