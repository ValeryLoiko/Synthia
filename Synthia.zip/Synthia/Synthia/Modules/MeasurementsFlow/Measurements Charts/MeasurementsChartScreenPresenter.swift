//
//  MeasurementsChartScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 27/02/2023.
//

import RxSwift

final class MeasurementsChartScreenPresenterImpl: MeasurementsChartScreenPresenter {
    typealias View = MeasurementsChartScreenView
    typealias ViewState = MeasurementsChartScreenViewState
    typealias Middleware = MeasurementsChartScreenMiddleware
    typealias Interactor = MeasurementsChartScreenInteractor
    typealias Effect = MeasurementsChartScreenEffect
    typealias Result = MeasurementsChartScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    private let input: MeasurementsChartScreenBuilderInput
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState, input: MeasurementsChartScreenBuilderInput) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
        self.input = input
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .segmentControlIntent(index: let index):
                return .merge(
                    interactor.updateChartEntries(index: index),
                    interactor.fetchMeasurementsByRange(index: index)
                )
            case .measurementsHistoryIntent(chosenMeasurent: let chosenMeasurent):
                return .just(.effect(.showMeasurementHistory(chosenMeasurement: chosenMeasurent)))
            case .addDataPressed:
                return .just(.effect(.showAddDataScreen(chosenMeasurement: input.chosenMeasurement)))
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
