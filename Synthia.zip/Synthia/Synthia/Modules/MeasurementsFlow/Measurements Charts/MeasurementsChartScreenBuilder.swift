//
//  MeasurementsChartScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 27/02/2023.
//

import UIKit
import RxSwift

final class MeasurementsChartScreenBuilderImpl: MeasurementsChartScreenBuilder {
    typealias Dependencies = MeasurementsChartScreenInteractorImpl.Dependencies & MeasurementsChartScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: MeasurementsChartScreenBuilderInput) -> MeasurementsChartScreenModule {
        let interactor = MeasurementsChartScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = MeasurementsChartScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = MeasurementsChartScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: MeasurementsChartScreenViewState(chosenMeasurement: input.chosenMeasurement), input: input)
        let view = MeasurementsChartScreenViewController(presenter: presenter)
        return MeasurementsChartScreenModule(view: view, callback: middleware)
    }
}
