//
//  AccountSetupNameScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AccountSetupNameScreenViewController: BaseViewController, AccountSetupNameScreenView {
    typealias ViewState = AccountSetupNameScreenViewState
    typealias Effect = AccountSetupNameScreenEffect
    typealias Intent = AccountSetupNameScreenIntent
    typealias B = Localization.Buttons

    @IntentSubject() var intents: Observable<AccountSetupNameScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AccountSetupNameScreenPresenter
    
    init(presenter: AccountSetupNameScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var nextButton = Button(style: .normal, title: B.nextButton)

    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        self.title = "Account Setup"
        self.view.addSubview(nextButton)
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(56)
        }
    }
    
    private func bindControls() {
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        }
    }
    
    func render(state: ViewState) {
    }
}
