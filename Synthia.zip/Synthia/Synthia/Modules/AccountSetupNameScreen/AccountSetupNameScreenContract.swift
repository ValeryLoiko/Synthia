//
//  AccountSetupNameScreenContract.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

enum AccountSetupNameScreenIntent {
}

struct AccountSetupNameScreenViewState: Equatable {
}

enum AccountSetupNameScreenEffect: Equatable {
}

struct AccountSetupNameScreenBuilderInput {
}

protocol AccountSetupNameScreenCallback {
}

enum AccountSetupNameScreenResult: Equatable {
    case partialState(_ value: AccountSetupNameScreenPartialState)
    case effect(_ value: AccountSetupNameScreenEffect)
}

enum AccountSetupNameScreenPartialState: Equatable {
    func reduce(previousState: AccountSetupNameScreenViewState) -> AccountSetupNameScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountSetupNameScreenBuilder {
    func build(with input: AccountSetupNameScreenBuilderInput) -> AccountSetupNameScreenModule
}

struct AccountSetupNameScreenModule {
    let view: AccountSetupNameScreenView
    let callback: AccountSetupNameScreenCallback
}

protocol AccountSetupNameScreenView: BaseView {
    var intents: Observable<AccountSetupNameScreenIntent> { get }
    func render(state: AccountSetupNameScreenViewState)
}

protocol AccountSetupNameScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountSetupNameScreenView, triggerEffect: PublishSubject<AccountSetupNameScreenEffect>) -> Observable<AccountSetupNameScreenViewState>
}

protocol AccountSetupNameScreenInteractor: BaseInteractor {
}

protocol AccountSetupNameScreenMiddleware {
    var middlewareObservable: Observable<AccountSetupNameScreenResult> { get }
    func process(result: AccountSetupNameScreenResult) -> Observable<AccountSetupNameScreenResult>
}
