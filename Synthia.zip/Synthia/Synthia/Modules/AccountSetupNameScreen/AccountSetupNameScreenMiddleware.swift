//
//  AccountSetupNameScreenMiddleware.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

final class AccountSetupNameScreenMiddlewareImpl: AccountSetupNameScreenMiddleware, AccountSetupNameScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = AccountSetupNameScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            }
        }
        return .just(result)
    }
}
