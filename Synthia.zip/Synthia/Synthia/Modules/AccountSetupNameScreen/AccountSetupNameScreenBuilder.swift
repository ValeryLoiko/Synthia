//
//  AccountSetupNameScreenBuilder.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import UIKit
import RxSwift

final class AccountSetupNameScreenBuilderImpl: AccountSetupNameScreenBuilder {
    typealias Dependencies = AccountSetupNameScreenInteractorImpl.Dependencies & AccountSetupNameScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AccountSetupNameScreenBuilderInput) -> AccountSetupNameScreenModule {
        let interactor = AccountSetupNameScreenInteractorImpl(dependencies: dependencies)
        let middleware = AccountSetupNameScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = AccountSetupNameScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AccountSetupNameScreenViewState())
        let view = AccountSetupNameScreenViewController(presenter: presenter)
        return AccountSetupNameScreenModule(view: view, callback: middleware)
    }
}
