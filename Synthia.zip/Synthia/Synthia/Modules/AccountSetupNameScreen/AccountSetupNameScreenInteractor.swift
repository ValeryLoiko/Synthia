//
//  AccountSetupNameScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

final class AccountSetupNameScreenInteractorImpl: AccountSetupNameScreenInteractor {
    typealias Dependencies = Any
    typealias Result = AccountSetupNameScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
}
