//
//  PasswordResetConfirmationScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

final class PasswordResetConfirmationScreenInteractorImpl: PasswordResetConfirmationScreenInteractor {
    typealias Dependencies = HasNetworkingService
    typealias Result = PasswordResetConfirmationScreenResult
    
    private let dependencies: Dependencies
    private let input: PasswordResetConfirmationScreenBuilderInput
    
    init(dependencies: Dependencies, input: PasswordResetConfirmationScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func confirmButtonAction(code: String, newPassword: String) -> Observable<PasswordResetConfirmationScreenResult> {
        return dependencies.networkingService.execute(request: API.Endpoint.forgotPasswordConfirm(verificationCode: code, password: newPassword, email: input.email), decodingFormat: .json).map { (response: [ForgotPasswordConfirmResponse]) in
            return .effect(.showMeasurementScreen)
        }
        .asObservable()
    }
}
