//
//  PasswordResetConfirmationScreenContract.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

enum PasswordResetConfirmationScreenIntent {
    case confirmButtonIntent(code: String, newPassword: String)
    case dismissScreenIntent
}

struct PasswordResetConfirmationScreenViewState: Equatable {
}

enum PasswordResetConfirmationScreenEffect: Equatable {
    case dismissScreen
    case showMeasurementScreen
}

struct PasswordResetConfirmationScreenBuilderInput {
    var email: String
}

protocol PasswordResetConfirmationScreenCallback {
}

enum PasswordResetConfirmationScreenResult: Equatable {
    case partialState(_ value: PasswordResetConfirmationScreenPartialState)
    case effect(_ value: PasswordResetConfirmationScreenEffect)
}

enum PasswordResetConfirmationScreenPartialState: Equatable {
    func reduce(previousState: PasswordResetConfirmationScreenViewState) -> PasswordResetConfirmationScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol PasswordResetConfirmationScreenBuilder {
    func build(with input: PasswordResetConfirmationScreenBuilderInput) -> PasswordResetConfirmationScreenModule
}

struct PasswordResetConfirmationScreenModule {
    let view: PasswordResetConfirmationScreenView
    let callback: PasswordResetConfirmationScreenCallback
}

protocol PasswordResetConfirmationScreenView: BaseView {
    var intents: Observable<PasswordResetConfirmationScreenIntent> { get }
    func render(state: PasswordResetConfirmationScreenViewState)
}

protocol PasswordResetConfirmationScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: PasswordResetConfirmationScreenView, triggerEffect: PublishSubject<PasswordResetConfirmationScreenEffect>) -> Observable<PasswordResetConfirmationScreenViewState>
}

protocol PasswordResetConfirmationScreenInteractor: BaseInteractor {
    func confirmButtonAction(code: String, newPassword: String) -> Observable<PasswordResetConfirmationScreenResult>
}

protocol PasswordResetConfirmationScreenMiddleware {
    var middlewareObservable: Observable<PasswordResetConfirmationScreenResult> { get }
    func process(result: PasswordResetConfirmationScreenResult) -> Observable<PasswordResetConfirmationScreenResult>
}
