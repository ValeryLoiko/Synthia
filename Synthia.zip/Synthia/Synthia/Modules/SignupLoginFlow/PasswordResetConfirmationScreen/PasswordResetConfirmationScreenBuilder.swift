//
//  PasswordResetConfirmationScreenBuilder.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import UIKit
import RxSwift

final class PasswordResetConfirmationScreenBuilderImpl: PasswordResetConfirmationScreenBuilder {
    typealias Dependencies = PasswordResetConfirmationScreenInteractorImpl.Dependencies & PasswordResetConfirmationScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: PasswordResetConfirmationScreenBuilderInput) -> PasswordResetConfirmationScreenModule {
        let interactor = PasswordResetConfirmationScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = PasswordResetConfirmationScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = PasswordResetConfirmationScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: PasswordResetConfirmationScreenViewState())
        let view = PasswordResetConfirmationScreenViewController(presenter: presenter)
        return PasswordResetConfirmationScreenModule(view: view, callback: middleware)
    }
}
