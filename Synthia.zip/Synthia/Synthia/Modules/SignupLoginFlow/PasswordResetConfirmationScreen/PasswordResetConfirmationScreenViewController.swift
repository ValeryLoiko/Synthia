//
//  PasswordResetConfirmationScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class PasswordResetConfirmationScreenViewController: BaseViewController, PasswordResetConfirmationScreenView {
    typealias ViewState = PasswordResetConfirmationScreenViewState
    typealias Effect = PasswordResetConfirmationScreenEffect
    typealias Intent = PasswordResetConfirmationScreenIntent
    typealias B = Localization.Buttons
    typealias R = Localization.ResetEmailScreen
    
    @IntentSubject() var intents: Observable<PasswordResetConfirmationScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: PasswordResetConfirmationScreenPresenter
    
    init(presenter: PasswordResetConfirmationScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = R.infoLabel
        label.tintColor = .blackColor
        label.font = .OpenSansRegular14
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: .rightXmarkBlack, title: "")
        button.addTarget(self, action: #selector(dismissView), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    private lazy var codeTextField = TextFieldInput(type: .generalField, title: R.codeLabel, placeholder: R.codeLabelPlaceholder)
    private lazy var newPasswordTexField = TextFieldInput(type: .passwordField, title: R.newPasswordLabel, placeholder: R.newPasswordLabel)
    private lazy var confirmNewPawsswordTextField = TextFieldInput(type: .passwordField, title: R.confimrNewPasswordLabel, placeholder: R.confimrNewPasswordLabel)
    private lazy var confirmButton = Button(style: .normal, title: B.confirmButton)

    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        self.title = R.title
        self.view.addSubview(infoLabel)
        self.view.addSubview(codeTextField)
        self.view.addSubview(newPasswordTexField)
        self.view.addSubview(confirmNewPawsswordTextField)
        self.view.addSubview(confirmButton)
        navigationItem.rightBarButtonItem = closeButton

        infoLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(80)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(40)
        }
        
        codeTextField.snp.makeConstraints { make in
            make.top.equalTo(infoLabel.snp.bottom).offset(24)
            make.left.right.equalToSuperview().inset(16)
        }
        
        newPasswordTexField.snp.makeConstraints { make in
            make.top.equalTo(codeTextField.snp.bottom).offset(24)
            make.left.right.equalToSuperview().inset(16)
        }
        
        confirmNewPawsswordTextField.snp.makeConstraints { make in
            make.top.equalTo(newPasswordTexField.snp.bottom).offset(24)
            make.left.right.equalToSuperview().inset(16)
        }
        
        confirmButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-80)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(58)
        }
    }
    
    @objc private func dismissView() {
        _intents.subject.onNext(.dismissScreenIntent)
    }
    
    private func bindControls() {
        confirmButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let code = self?.codeTextField.textField.text, let newPassword = self?.newPasswordTexField.textField.text else { return }
                self?._intents.subject.onNext(.confirmButtonIntent(code: code, newPassword: newPassword))
            })
            .disposed(by: bag)
        
        codeTextField.textField.validatedCode
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.codeTextField.errorLabel.text = error
                self?.checkTextFieldInput()
            })
            .disposed(by: bag)
        
        newPasswordTexField.textField.validatedPassword
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.newPasswordTexField.errorLabel.text = error
                self?.checkTextFieldInput()
            })
            .disposed(by: bag)
                
        confirmNewPawsswordTextField.textField.passwordTheSame(newPasswordTexField.textField)
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.confirmNewPawsswordTextField.errorLabel.text = error
                self?.checkTextFieldInput()
            })
            .disposed(by: bag)
        
        newPasswordTexField.textField.passwordTheSame(confirmNewPawsswordTextField.textField)
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.confirmNewPawsswordTextField.errorLabel.text = error
                self?.checkTextFieldInput()
            })
            .disposed(by: bag)
    }
    
    private func checkTextFieldInput() {
        guard let codeText = codeTextField.textField.text else { return }
        guard let newPasswordText = newPasswordTexField.textField.text else { return }
        guard let confirmPasswordText = confirmNewPawsswordTextField.textField.text else { return }
        
        if codeTextField.errorLabel.text?.isEmpty ?? false
            && newPasswordTexField.errorLabel.text?.isEmpty ?? false
            && confirmNewPawsswordTextField.errorLabel.text?.isEmpty ?? false
            && !codeText.isEmpty
            && !newPasswordText.isEmpty
            && !confirmPasswordText.isEmpty {
            confirmButton.enableButton()
        } else {
            confirmButton.disableButton()
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .dismissScreen:
            break
        case .showMeasurementScreen:
            break
        }
    }
    
    func render(state: ViewState) {
    }
}
