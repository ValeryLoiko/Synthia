//
//  AccountSetupNameScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AccountSetupNameScreenViewController: BaseViewController, AccountSetupNameScreenView {
    typealias ViewState = AccountSetupNameScreenViewState
    typealias Effect = AccountSetupNameScreenEffect
    typealias Intent = AccountSetupNameScreenIntent
    typealias B = Localization.Buttons.AccountSetupScreen
    typealias A = Localization.AccountSetUpScreen

    @IntentSubject() var intents: Observable<AccountSetupNameScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AccountSetupNameScreenPresenter
    
    init(presenter: AccountSetupNameScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var questionLabel: UILabel = {
        let label = UILabel()
        label.text = A.questionName
        label.tintColor = .blackColor
        label.font = .OpenSansSemiBold16
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = A.questionNameLabelInfo
        label.tintColor = .blackColor
        label.font = .OpenSansRegular14
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    private lazy var nextButton = Button(style: .normal, title: B.nextButton)
    private lazy var userNameLabel = TextFieldInput(type: .generalField, title: A.nameLabel, placeholder: A.nameLabel)
    private lazy var skipButton: UIBarButtonItem = {
        let button = Button(style: .rightStringBlack, title: B.skipButton)
        button.addTarget(self, action: #selector(skipSetup), for: .touchUpInside)
        let skipButton = UIBarButtonItem(customView: button)
        return skipButton
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        nextButton.disableButton()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
      }
    
    private func layoutView() {
        self.view.addSubview(questionLabel)
        self.view.addSubview(infoLabel)
        self.view.addSubview(userNameLabel)
        self.view.addSubview(nextButton)
        navigationItem.rightBarButtonItem = skipButton
        navigationController?.navigationBar.isHidden = false
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        questionLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(112)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(24)
        }
        
        infoLabel.snp.makeConstraints { make in
            make.top.equalTo(questionLabel.snp.bottom).offset(8)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(20)
        }
        
        userNameLabel.snp.makeConstraints { make in
            make.top.equalTo(infoLabel.snp.bottom).offset(24)
            make.left.right.equalToSuperview().inset(16)
        }
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(56)
        }
    }
    
    @objc private func skipSetup() {
        return _intents.subject.onNext(.skipToGuideTourIntent)
    }
    
    private func checkTextFiledInput() {
        if userNameLabel.errorLabel.text?.isEmpty ?? false {
            self.nextButton.enableButton()
        } else {
            self.nextButton.disableButton()
        }
    }
    
    private func bindControls() {
        nextButton.rx.tap
            .map {
                if let userName = self.userNameLabel.textField.text {
                    return Intent.nextViewButtonIntent(accountInfo: AccountSetupModel(name: userName, sex: nil, age: nil, height: nil, weight: nil))
                } else {
                    return Intent.nextViewButtonIntent(accountInfo: AccountSetupModel(name: nil, sex: nil, age: nil, height: nil, weight: nil))
                }
            }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        userNameLabel.textField.validateUserName
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.userNameLabel.errorLabel.text = error
                self?.checkTextFiledInput()
            })
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .skipButtonAccountSetup:
            break
        case .nextButtonAccountSetup:
            break
        }
    }
    
    func render(state: ViewState) {
    }
}
