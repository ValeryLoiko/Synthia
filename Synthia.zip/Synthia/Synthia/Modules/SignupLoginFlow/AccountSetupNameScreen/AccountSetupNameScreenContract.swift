//
//  AccountSetupNameScreenContract.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

struct AccountSetupModel: Equatable {
    let name: String?
    let sex: String?
    let age: Int?
    let height: Int?
    let weight: Int?
}

enum AccountSetupNameScreenIntent {
    case skipToGuideTourIntent
    case nextViewButtonIntent(accountInfo: AccountSetupModel)
}

struct AccountSetupNameScreenViewState: Equatable {
}

enum AccountSetupNameScreenEffect: Equatable {
    case skipButtonAccountSetup
    case nextButtonAccountSetup(accountInfo: AccountSetupModel)
}

struct AccountSetupNameScreenBuilderInput {
}

protocol AccountSetupNameScreenCallback { 
}

enum AccountSetupNameScreenResult: Equatable {
    case partialState(_ value: AccountSetupNameScreenPartialState)
    case effect(_ value: AccountSetupNameScreenEffect)
}

enum AccountSetupNameScreenPartialState: Equatable {
    func reduce(previousState: AccountSetupNameScreenViewState) -> AccountSetupNameScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountSetupNameScreenBuilder {
    func build(with input: AccountSetupNameScreenBuilderInput) -> AccountSetupNameScreenModule
}

struct AccountSetupNameScreenModule {
    let view: AccountSetupNameScreenView
    let callback: AccountSetupNameScreenCallback
}

protocol AccountSetupNameScreenView: BaseView {
    var intents: Observable<AccountSetupNameScreenIntent> { get }
    func render(state: AccountSetupNameScreenViewState)
}

protocol AccountSetupNameScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountSetupNameScreenView, triggerEffect: PublishSubject<AccountSetupNameScreenEffect>) -> Observable<AccountSetupNameScreenViewState>
}

protocol AccountSetupNameScreenInteractor: BaseInteractor {
    func checkUserName(accountInfo: AccountSetupModel) -> Observable<AccountSetupNameScreenResult>
}

protocol AccountSetupNameScreenMiddleware {
    var middlewareObservable: Observable<AccountSetupNameScreenResult> { get }
    func process(result: AccountSetupNameScreenResult) -> Observable<AccountSetupNameScreenResult>
}
