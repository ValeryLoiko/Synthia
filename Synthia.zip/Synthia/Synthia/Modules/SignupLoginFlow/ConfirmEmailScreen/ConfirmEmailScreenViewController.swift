//
//  ConfirmEmailScreenViewController.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class ConfirmEmailScreenViewController: BaseViewController, ConfirmEmailScreenView {
    typealias ViewState = ConfirmEmailScreenViewState
    typealias Effect = ConfirmEmailScreenEffect
    typealias Intent = ConfirmEmailScreenIntent
    typealias C = Localization.ConfirmEmailScreen
    typealias L = Localization
    
    @IntentSubject() var intents: Observable<ConfirmEmailScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: ConfirmEmailScreenPresenter
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        let closeButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: nil)
        return closeButton
    }()
    
    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = L.ConfirmEmailScreen.infoLabel
        label.tintColor = .blackColor
        label.font = .OpenSansRegular14
        label.numberOfLines = 0
        return label
    }()
    private lazy var resendEmailButton = Button(style: .normal, title: L.Buttons.resetEmailButton)
    
    init(presenter: ConfirmEmailScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        _intents.subject.onNext(.sendEmailToBackEnd)
    }
    
    private func layoutView() {
        title = L.ConfirmEmailScreen.title
        self.navigationItem.rightBarButtonItem = closeButton
        view.addSubview(infoLabel)
        view.addSubview(resendEmailButton)
        
        infoLabel.snp.makeConstraints {
            $0.top.equalToSuperview().inset(80)
            $0.left.right.equalToSuperview().inset(24)
        }
        
        resendEmailButton.snp.makeConstraints {
            $0.bottom.equalToSuperview().inset(50)
            $0.height.equalTo(56)
            $0.left.right.equalToSuperview().inset(16)
        }
    }
    
    private func bindControls() {
        closeButton.rx.tap
            .map { Intent.closeButton }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        resendEmailButton.rx.tap
            .map { Intent.resetEmailButton }
            .bind(to: _intents.subject)
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .dismissScreen:
            break
        case .showAccountCreatedScreen:
            break
        case .showAlert:
            chooseAlert(type: .twoBtnsAlert(title: C.alertTitle, message: C.alertMessage, rightBtnTitle: L.Alerts.quit, rightBtnStyle: .destructive, rightBtnAction: { _ in
                self._intents.subject.onNext(.dismissScreen)
            }))
        }
    }
    
    func render(state: ViewState) {
        infoLabel.text? += state.email
    }
}
