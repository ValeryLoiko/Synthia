//
//  ConfirmEmailScreenMiddleware.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

final class ConfirmEmailScreenMiddlewareImpl: ConfirmEmailScreenMiddleware, ConfirmEmailScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = ConfirmEmailScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .dismissScreen:
                dependencies.appNavigation?.dismiss()
            case .showAccountCreatedScreen:
                dependencies.appNavigation?.showAccountCreatedScreen()
            case .showAlert:
                break
            }
        }
        return .just(result)
    }
}
