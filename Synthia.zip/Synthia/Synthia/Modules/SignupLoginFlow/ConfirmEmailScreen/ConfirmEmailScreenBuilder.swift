//
//  ConfirmEmailScreenBuilder.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import UIKit
import RxSwift

final class ConfirmEmailScreenBuilderImpl: ConfirmEmailScreenBuilder {
    typealias Dependencies = ConfirmEmailScreenInteractorImpl.Dependencies & ConfirmEmailScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: ConfirmEmailScreenBuilderInput) -> ConfirmEmailScreenModule {
        let interactor = ConfirmEmailScreenInteractorImpl(dependencies: dependencies, userEmail: input.email)
        let middleware = ConfirmEmailScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = ConfirmEmailScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: ConfirmEmailScreenViewState(email: input.email))
        let view = ConfirmEmailScreenViewController(presenter: presenter)
        return ConfirmEmailScreenModule(view: view, callback: middleware)
    }
}
