//
//  ConfirmEmailScreenPresenter.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

final class ConfirmEmailScreenPresenterImpl: ConfirmEmailScreenPresenter {
    typealias View = ConfirmEmailScreenView
    typealias ViewState = ConfirmEmailScreenViewState
    typealias Middleware = ConfirmEmailScreenMiddleware
    typealias Interactor = ConfirmEmailScreenInteractor
    typealias Effect = ConfirmEmailScreenEffect
    typealias Result = ConfirmEmailScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { intent -> Observable<Result> in
            switch intent {
            case .closeButton:
                return .just(.effect(.showAlert))
            case .resetEmailButton:
                return .just(.effect(.showAccountCreatedScreen))
            case .dismissScreen:
                return .just(.effect(.dismissScreen))
            case .sendEmailToBackEnd:
                return self.interactor.sendEmailToBackend()
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
