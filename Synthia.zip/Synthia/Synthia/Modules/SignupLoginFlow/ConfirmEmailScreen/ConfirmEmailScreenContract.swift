//
//  ConfirmEmailScreenContract.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

enum ConfirmEmailScreenIntent {
    case closeButton
    case resetEmailButton
    case dismissScreen
    case sendEmailToBackEnd
}

struct ConfirmEmailScreenViewState: Equatable {
    var email: String
}

enum ConfirmEmailScreenEffect: Equatable {
    case dismissScreen
    case showAccountCreatedScreen
    case showAlert
}

struct ConfirmEmailScreenBuilderInput {
    var email: String
}

protocol ConfirmEmailScreenCallback {
}

enum ConfirmEmailScreenResult: Equatable {
    case partialState(_ value: ConfirmEmailScreenPartialState)
    case effect(_ value: ConfirmEmailScreenEffect)
}

enum ConfirmEmailScreenPartialState: Equatable {
    case sendEmail(email: String)
    func reduce(previousState: ConfirmEmailScreenViewState) -> ConfirmEmailScreenViewState {
        var state = previousState
        switch self {
        case .sendEmail(email: let email):
            state.email = email
        }
        return state
    }
}

protocol ConfirmEmailScreenBuilder {
    func build(with input: ConfirmEmailScreenBuilderInput) -> ConfirmEmailScreenModule
}

struct ConfirmEmailScreenModule {
    let view: ConfirmEmailScreenView
    let callback: ConfirmEmailScreenCallback
}

protocol ConfirmEmailScreenView: BaseView {
    var intents: Observable<ConfirmEmailScreenIntent> { get }
    func render(state: ConfirmEmailScreenViewState)
}

protocol ConfirmEmailScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: ConfirmEmailScreenView, triggerEffect: PublishSubject<ConfirmEmailScreenEffect>) -> Observable<ConfirmEmailScreenViewState>
}

protocol ConfirmEmailScreenInteractor: BaseInteractor {
    func sendEmailToBackend() -> Observable<ConfirmEmailScreenResult>
}

protocol ConfirmEmailScreenMiddleware {
    var middlewareObservable: Observable<ConfirmEmailScreenResult> { get }
    func process(result: ConfirmEmailScreenResult) -> Observable<ConfirmEmailScreenResult>
}
