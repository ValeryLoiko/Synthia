//
//  ConfirmEmailScreenInteractor.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

final class ConfirmEmailScreenInteractorImpl: ConfirmEmailScreenInteractor {
    typealias Dependencies = Any
    typealias Result = ConfirmEmailScreenResult
    
    private let dependencies: Dependencies
    private let userEmail: String
    
    init(dependencies: Dependencies, userEmail: String) {
        self.dependencies = dependencies
        self.userEmail = userEmail
    }
    
    func sendEmailToBackend() -> RxSwift.Observable<ConfirmEmailScreenResult> {
        return Observable.empty()
    }
}
