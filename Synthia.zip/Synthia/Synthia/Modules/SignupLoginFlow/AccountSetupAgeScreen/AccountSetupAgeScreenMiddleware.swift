//
//  AccountSetupAgeScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import RxSwift

final class AccountSetupAgeScreenMiddlewareImpl: AccountSetupAgeScreenMiddleware, AccountSetupAgeScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = AccountSetupAgeScreenResult
    
    private let dependencies: Dependencies
    
    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showGuideTourScreen:
                dependencies.appNavigation?.showGuideTour()
            case .enableNextButton:
                break
            case .blockNextButton:
                break
            case .showAccountSetupHeightScreen(accountInfo: let accountInfo):
                dependencies.appNavigation?.showAccountSetupHeight(accountInfo: accountInfo)
            }
        }
        return .just(result)
    }
}
