//
//  AccountSetupAgeScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import RxSwift

enum AccountSetupAgeScreenIntent {
    case skipButtonIntent
    case nextButtonIntent(age: Int)
}

struct AccountSetupAgeScreenViewState: Equatable {
}

enum AccountSetupAgeScreenEffect: Equatable {
    case showGuideTourScreen
    case showAccountSetupHeightScreen(accountInfo: AccountSetupModel)
    case enableNextButton
    case blockNextButton
}

struct AccountSetupAgeScreenBuilderInput {
    var accountInfo: AccountSetupModel
}

protocol AccountSetupAgeScreenCallback { 
}

enum AccountSetupAgeScreenResult: Equatable {
    case partialState(_ value: AccountSetupAgeScreenPartialState)
    case effect(_ value: AccountSetupAgeScreenEffect)
}

enum AccountSetupAgeScreenPartialState: Equatable {
    func reduce(previousState: AccountSetupAgeScreenViewState) -> AccountSetupAgeScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountSetupAgeScreenBuilder {
    func build(with input: AccountSetupAgeScreenBuilderInput) -> AccountSetupAgeScreenModule
}

struct AccountSetupAgeScreenModule {
    let view: AccountSetupAgeScreenView
    let callback: AccountSetupAgeScreenCallback
}

protocol AccountSetupAgeScreenView: BaseView {
    var intents: Observable<AccountSetupAgeScreenIntent> { get }
    func render(state: AccountSetupAgeScreenViewState)
}

protocol AccountSetupAgeScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountSetupAgeScreenView, triggerEffect: PublishSubject<AccountSetupAgeScreenEffect>) -> Observable<AccountSetupAgeScreenViewState>
}

protocol AccountSetupAgeScreenInteractor: BaseInteractor {
    func saveUserAge(age: Int) -> Observable<AccountSetupAgeScreenResult>
}

protocol AccountSetupAgeScreenMiddleware {
    var middlewareObservable: Observable<AccountSetupAgeScreenResult> { get }
    func process(result: AccountSetupAgeScreenResult) -> Observable<AccountSetupAgeScreenResult>
}
