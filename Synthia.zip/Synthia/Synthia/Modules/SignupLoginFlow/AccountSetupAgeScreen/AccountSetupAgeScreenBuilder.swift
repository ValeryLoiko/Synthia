//
//  AccountSetupAgeScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import UIKit
import RxSwift

final class AccountSetupAgeScreenBuilderImpl: AccountSetupAgeScreenBuilder {
    typealias Dependencies = AccountSetupAgeScreenInteractorImpl.Dependencies & AccountSetupAgeScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AccountSetupAgeScreenBuilderInput) -> AccountSetupAgeScreenModule {
        let interactor = AccountSetupAgeScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = AccountSetupAgeScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = AccountSetupAgeScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AccountSetupAgeScreenViewState())
        let view = AccountSetupAgeScreenViewController(presenter: presenter)
        return AccountSetupAgeScreenModule(view: view, callback: middleware)
    }
}
