//
//  AccountSetupAgeScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import RxSwift

final class AccountSetupAgeScreenInteractorImpl: AccountSetupAgeScreenInteractor {
    typealias Dependencies = Any
    typealias Result = AccountSetupAgeScreenResult
    
    private let dependencies: Dependencies
    private let input: AccountSetupAgeScreenBuilderInput
    
    init(dependencies: Dependencies, input: AccountSetupAgeScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func saveUserAge(age: Int) -> RxSwift.Observable<AccountSetupAgeScreenResult> {
        return .just(.effect(.showAccountSetupHeightScreen(accountInfo: AccountSetupModel(name: input.accountInfo.name, sex: input.accountInfo.sex, age: age, height: nil, weight: nil))))
    }
}
