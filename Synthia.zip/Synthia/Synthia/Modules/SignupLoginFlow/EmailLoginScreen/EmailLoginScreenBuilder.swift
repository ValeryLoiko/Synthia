//
//  EmailLoginScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import UIKit
import RxSwift

final class EmailLoginScreenBuilderImpl: EmailLoginScreenBuilder {
    typealias Dependencies = EmailLoginScreenInteractorImpl.Dependencies & EmailLoginScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: EmailLoginScreenBuilderInput) -> EmailLoginScreenModule {
        let interactor = EmailLoginScreenInteractorImpl(dependencies: dependencies)
        let middleware = EmailLoginScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = EmailLoginScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: EmailLoginScreenViewState())
        let view = EmailLoginScreenViewController(presenter: presenter)
        return EmailLoginScreenModule(view: view, callback: middleware)
    }
}
