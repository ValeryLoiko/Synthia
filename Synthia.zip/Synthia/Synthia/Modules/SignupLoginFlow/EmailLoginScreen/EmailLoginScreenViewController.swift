//
//  EmailLoginScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class EmailLoginScreenViewController: BaseViewController, EmailLoginScreenView {
    typealias ViewState = EmailLoginScreenViewState
    typealias Effect = EmailLoginScreenEffect
    typealias Intent = EmailLoginScreenIntent
    typealias E = Localization.EmailLoginScreen
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<EmailLoginScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: EmailLoginScreenPresenter
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        button.addTarget(self, action: #selector(closeView), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    private lazy var emailTextfield = TextFieldInput(type: .generalField, title: E.emailLabel, placeholder: E.emailLabel)
    private lazy var passwordTextfield = TextFieldInput(type: .passwordField, title: E.passwordLabel, placeholder: E.passwordLabel)
    private lazy var forgotPasswordButton = Button(style: .transparent, title: B.forgotPasswordButton)
    private lazy var createAccountButton = Button(style: .transparent, title: B.createNewAccountButton)
    private lazy var signInButton = Button(style: .normal, title: B.signInButton)
    
    init(presenter: EmailLoginScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        self.navigationItem.rightBarButtonItem = closeButton
        self.title = E.title
        view.addSubview(emailTextfield)
        view.addSubview(passwordTextfield)
        view.addSubview(forgotPasswordButton)
        view.addSubview(signInButton)
        signInButton.disableButton()
        view.addSubview(createAccountButton)
        
        emailTextfield.snp.makeConstraints {
            $0.top.equalToSuperview().inset(80)
            $0.left.right.equalToSuperview().inset(12)
        }
        
        passwordTextfield.snp.makeConstraints {
            $0.top.equalTo(emailTextfield.snp.bottom).offset(16)
            $0.left.right.equalToSuperview().inset(12)
        }
        
        forgotPasswordButton.snp.makeConstraints {
            $0.top.equalTo(passwordTextfield.snp.bottom).offset(16)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(16)
        }
        
        signInButton.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.height.equalTo(56)
            $0.left.right.equalToSuperview().inset(16)
            $0.bottom.equalToSuperview().inset(50)
        }
        
        createAccountButton.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.height.equalTo(16)
            $0.left.right.equalToSuperview().inset(16)
            $0.bottom.equalTo(signInButton.snp.top).offset(-16)
        }
    }
    
    private func bindControls() {
        closeButton.rx.tap
            .map { Intent.closeScreen }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        forgotPasswordButton.rx.tap
            .map { Intent.forgotPasswordButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        createAccountButton.rx.tap
            .map { Intent.createAccount }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        signInButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let email = self?.emailTextfield.textField.text, let password = self?.passwordTextfield.textField.text else { return }
                self?._intents.subject.onNext(.signInButtonIntent(email: email, password: password))
            })
            .disposed(by: bag)
        
        emailTextfield.textField.validatedEmail
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.emailTextfield.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        passwordTextfield.textField.validatePasswordLength
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.passwordTextfield.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
    }
    
    @objc private func closeView() {
        _intents.subject.onNext(.closeScreen)
    }
    
    private func checkTextfieldInput() {
        guard let passwordText = passwordTextfield.textField.text else { return }
        if emailTextfield.errorLabel.text?.count == 0 && passwordTextfield.errorLabel.text?.count == 0 && passwordText.count > 0 {
            self.effectsSubject.onNext(.enableSignInButton)
        } else {
            self.effectsSubject.onNext(.blockSignInButton)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .closeScreen:
            break
        case .showPasswordResetScreen:
            break
        case .showEmailSignUpScreen:
            break
        case .showDevicesScreen:
            break
        case .blockSignInButton:
            signInButton.disableButton()
        case .enableSignInButton:
            signInButton.enableButton()
        }
    }
    
    func render(state: ViewState) {
    }
}
