//
//  EmailLoginScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import RxSwift

final class EmailLoginScreenPresenterImpl: EmailLoginScreenPresenter {
    typealias View = EmailLoginScreenView
    typealias ViewState = EmailLoginScreenViewState
    typealias Middleware = EmailLoginScreenMiddleware
    typealias Interactor = EmailLoginScreenInteractor
    typealias Effect = EmailLoginScreenEffect
    typealias Result = EmailLoginScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .forgotPasswordButtonIntent:
                return .just(.effect(.showPasswordResetScreen))
            case .closeScreen:
                return .just(.effect(.closeScreen))
            case .createAccount:
                return .just(.effect(.showEmailSignUpScreen))
            case .signInButtonIntent(email: let email, password: let password):
                return interactor.checkUser(email: email, password: password)
            case .getUser:
                return interactor.getUser()
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
