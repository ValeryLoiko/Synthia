//
//  EmailLoginScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import RxSwift

enum EmailLoginScreenIntent {
    case forgotPasswordButtonIntent
    case closeScreen
    case createAccount
    case signInButtonIntent(email: String, password: String)
    case getUser
}

struct EmailLoginScreenViewState: Equatable {
}

enum EmailLoginScreenEffect: Equatable {
    case showPasswordResetScreen
    case closeScreen
    case showEmailSignUpScreen
    case showDevicesScreen
    case blockSignInButton
    case enableSignInButton
}

struct EmailLoginScreenBuilderInput {
}

protocol EmailLoginScreenCallback { 
}

enum EmailLoginScreenResult: Equatable {
    case partialState(_ value: EmailLoginScreenPartialState)
    case effect(_ value: EmailLoginScreenEffect)
}

enum EmailLoginScreenPartialState: Equatable {
    case somethingWentWrong
    case invalidEmailOrPassword
    
    func reduce(previousState: EmailLoginScreenViewState) -> EmailLoginScreenViewState {
        switch self {
        case .somethingWentWrong:
            print("Something went wrong")
        case .invalidEmailOrPassword:
            print("Invalid email or password")
        }
        return previousState
    }
}

protocol EmailLoginScreenBuilder {
    func build(with input: EmailLoginScreenBuilderInput) -> EmailLoginScreenModule
}

struct EmailLoginScreenModule {
    let view: EmailLoginScreenView
    let callback: EmailLoginScreenCallback
}

protocol EmailLoginScreenView: BaseView {
    var intents: Observable<EmailLoginScreenIntent> { get }
    func render(state: EmailLoginScreenViewState)
}

protocol EmailLoginScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: EmailLoginScreenView, triggerEffect: PublishSubject<EmailLoginScreenEffect>) -> Observable<EmailLoginScreenViewState>
}

protocol EmailLoginScreenInteractor: BaseInteractor {
    func checkUser(email: String, password: String) -> Observable<EmailLoginScreenResult>
    func getUser() -> Observable<EmailLoginScreenResult>
}

protocol EmailLoginScreenMiddleware {
    var middlewareObservable: Observable<EmailLoginScreenResult> { get }
    func process(result: EmailLoginScreenResult) -> Observable<EmailLoginScreenResult>
}
