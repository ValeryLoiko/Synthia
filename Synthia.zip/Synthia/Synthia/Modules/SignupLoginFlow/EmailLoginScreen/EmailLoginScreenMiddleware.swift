//
//  EmailLoginScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import RxSwift

final class EmailLoginScreenMiddlewareImpl: EmailLoginScreenMiddleware, EmailLoginScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = EmailLoginScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .closeScreen:
                dependencies.appNavigation?.dismiss()
            case .showPasswordResetScreen:
                dependencies.appNavigation?.showPasswordResetScreen()
            case .showEmailSignUpScreen:
                dependencies.appNavigation?.showEmailSignupScreen()
            case .showDevicesScreen:
                dependencies.appNavigation?.showMeasurementsScreen()
            case .blockSignInButton:
                break
            case .enableSignInButton:
                break
            }
        }
        return .just(result)
    }
}
