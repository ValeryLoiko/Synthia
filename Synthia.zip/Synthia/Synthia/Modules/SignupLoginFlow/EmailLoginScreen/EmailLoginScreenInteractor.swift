//
//  EmailLoginScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 16/01/2023.
//

import RxSwift
import KeychainAccess

final class EmailLoginScreenInteractorImpl: EmailLoginScreenInteractor {
    typealias Dependencies = HasNetworkingService & HasKeychainManager & HasUserManager
    typealias Result = EmailLoginScreenResult
    
    private let dependencies: Dependencies
    private let keychainManager: KeychainManagerService
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
        self.keychainManager = dependencies.keychainManager
    }
    
    func checkUser(email: String, password: String) -> RxSwift.Observable<EmailLoginScreenResult> {
        return dependencies.userManager.login(email: email, password: password)
            .andThen(.just(()))
            .map({ _ in
                return .effect(.showDevicesScreen)
            })
            .catch { error -> Observable<EmailLoginScreenResult> in
                guard let apiError = error as? ApiError else {
                    return .just(.partialState(.somethingWentWrong)) }
                    switch apiError {
                    case .statusCode(let int):
                        guard GetUserResponse.Code(rawValue: int) != nil else {
                            return .just(.partialState(.somethingWentWrong))
                        }
                        return .just(.partialState(.invalidEmailOrPassword))
                }
            }
    }
    
    func getUser() -> Observable<EmailLoginScreenResult> {
        return dependencies.networkingService.execute(request: API.Endpoint.getUsers, decodingFormat: .json).flatMap { (response: [GetUserResponse]) in
            print(response)
            return .just(.effect(.showDevicesScreen))
        }
        .asObservable()
    }
}
