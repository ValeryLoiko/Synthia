//
//  WelcomeScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 12/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class WelcomeScreenViewController: BaseViewController, WelcomeScreenView {
    typealias ViewState = WelcomeScreenViewState
    typealias Effect = WelcomeScreenEffect
    typealias Intent = WelcomeScreenIntent
    typealias W = Localization.WelcomeScreen
    typealias B = Localization.Buttons
    typealias A = Localization.Alerts
    
    @IntentSubject() var intents: Observable<WelcomeScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: WelcomeScreenPresenter
    
    private var pageContentSubject = PublishSubject<[WelcomeScreenPageModel]>()
    
    private lazy var pageViewController = WelcomeScreenPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
    private lazy var signInButton = Button(style: .normal, title: B.signinOrJoinButton)
    private lazy var startUsingNowButton = Button(style: .transparentBorder, title: B.startUsingNowButton)
    
    init(presenter: WelcomeScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        view.addSubview(signInButton)
        view.addSubview(startUsingNowButton)
        view.addSubview(pageViewController.view)
        
        startUsingNowButton.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalToSuperview().inset(50)
        }
        
        signInButton.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalTo(startUsingNowButton.snp.top).offset(-16)
        }
        
        let viewHeight = 896.0
        let pageControllerHeight = 567.0
        
        pageViewController.view.snp.makeConstraints {
            $0.left.right.equalToSuperview()
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.height.equalTo(view.snp.height).multipliedBy(pageControllerHeight / viewHeight)
        }
    }
    
    private func bindControls() {
        signInButton.rx.tap
        .map { Intent.signInOrJoinButtonIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
        
        let defaults = UserDefaults.standard
        if defaults.string(forKey: UserDefaultsKeys.isFirstLaunch) == "true" {
            startUsingNowButton.rx.tap
            .map { Intent.startUsingNowAlert }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        } else {
            startUsingNowButton.rx.tap
            .map { Intent.startUsingNowButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        }
        
        pageContentSubject.subscribe(onNext: { page in
            var pages: [PageVCWelcomeScreen] = []
            for item in page {
                pages.append(PageVCWelcomeScreen(imageName: item.imageName, titleText: item.headerText, descriptionText: item.descriptionText))
                self.pageViewController.setPages(pages: pages)
            }
        })
        .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showLoginSignUpScreen:
            break
        case .showTermsConditions:
            break
        case .showMeasurementsScreen:
            break
        case .showAlert:
            chooseAlert(type: .twoBtnsAlert(title: A.noRegistrationTitle, message: A.noRegistrationMessage, rightBtnTitle: A.continueButtonTitle, rightBtnStyle: .default, rightBtnAction: { _ in
                self._intents.subject.onNext(.startUsingNowButtonIntent)
            }))
        }
    }
    
    func render(state: ViewState) {
        pageContentSubject.onNext(state.pageViewData)
    }
}
