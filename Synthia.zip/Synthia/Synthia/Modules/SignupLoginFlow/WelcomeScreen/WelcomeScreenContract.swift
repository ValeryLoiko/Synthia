//
//  WelcomeScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 12/01/2023.
//

import RxSwift
import Foundation

struct WelcomeScreenPageModel: Equatable {
    var imageName: String
    var headerText: String
    var descriptionText: String
}

typealias W = Localization.WelcomeScreen

enum WelcomeScreenIntent {
    case signInOrJoinButtonIntent
    case startUsingNowAlert
    case startUsingNowButtonIntent
}

struct WelcomeScreenViewState: Equatable {
    var pageViewData: [WelcomeScreenPageModel] = [
        WelcomeScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: W.titleView1, descriptionText: W.subTitleView1),
        WelcomeScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: W.titleView2, descriptionText: W.subTitleView2),
        WelcomeScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: W.titleView3, descriptionText: W.subTitleView3),
        WelcomeScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: W.titleView4, descriptionText: W.subTitleView4)
    ]
}

enum WelcomeScreenEffect: Equatable {
    case showLoginSignUpScreen
    case showTermsConditions
    case showMeasurementsScreen
    case showAlert
}

struct WelcomeScreenBuilderInput {
}

protocol WelcomeScreenCallback {
}

enum WelcomeScreenResult: Equatable {
    case partialState(_ value: WelcomeScreenPartialState)
    case effect(_ value: WelcomeScreenEffect)
}

enum WelcomeScreenPartialState: Equatable {
    func reduce(previousState: WelcomeScreenViewState) -> WelcomeScreenViewState {
        _ = previousState
        switch self {
        default:
            break
        }
    }
}

protocol WelcomeScreenBuilder {
    func build(with input: WelcomeScreenBuilderInput) -> WelcomeScreenModule
}

struct WelcomeScreenModule {
    let view: WelcomeScreenView
    let callback: WelcomeScreenCallback
}

protocol WelcomeScreenView: BaseView {
    var intents: Observable<WelcomeScreenIntent> { get }
    func render(state: WelcomeScreenViewState)
}

protocol WelcomeScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: WelcomeScreenView, triggerEffect: PublishSubject<WelcomeScreenEffect>) -> Observable<WelcomeScreenViewState>
}

protocol WelcomeScreenInteractor: BaseInteractor {
}

protocol WelcomeScreenMiddleware {
    var middlewareObservable: Observable<WelcomeScreenResult> { get }
    func process(result: WelcomeScreenResult) -> Observable<WelcomeScreenResult>
}
