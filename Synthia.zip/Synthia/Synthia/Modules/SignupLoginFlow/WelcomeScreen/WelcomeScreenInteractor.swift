//
//  WelcomeScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 12/01/2023.
//

import RxSwift

final class WelcomeScreenInteractorImpl: WelcomeScreenInteractor {
    typealias W = Localization.WelcomeScreen
    typealias Dependencies = HasNetworkingService
    typealias Result = WelcomeScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
}
