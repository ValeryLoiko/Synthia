//
//  AccountCreatedScreenMiddleware.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

final class AccountCreatedScreenMiddlewareImpl: AccountCreatedScreenMiddleware, AccountCreatedScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = AccountCreatedScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showAccountSetUp:
                dependencies.appNavigation?.showAccountSetUpScreen()
            }
        }
        return .just(result)
    }
}
