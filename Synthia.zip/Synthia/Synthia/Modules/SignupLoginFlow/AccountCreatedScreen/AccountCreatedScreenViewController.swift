//
//  AccountCreatedScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AccountCreatedScreenViewController: BaseViewController, AccountCreatedScreenView {
    typealias ViewState = AccountCreatedScreenViewState
    typealias Effect = AccountCreatedScreenEffect
    typealias Intent = AccountCreatedScreenIntent
    typealias B = Localization.Buttons
    typealias A = Localization.CreatedAccountScreen
    
    @IntentSubject() var intents: Observable<AccountCreatedScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AccountCreatedScreenPresenter
    
    init(presenter: AccountCreatedScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = A.labelInfo
        label.tintColor = .blackColor
        label.font = .OpenSansRegular14
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    private lazy var startAppButton = Button(style: .normal, title: B.startButton)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        self.title = A.title
        self.view.addSubview(infoLabel)
        self.view.addSubview(startAppButton)
        
        infoLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(136)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(40)
        }
        
        startAppButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.right.left.equalToSuperview().inset(16)
            make.height.equalTo(56)
        }
    }
    
    private func bindControls() {
        startAppButton.rx.tap.map {
            return Intent.showAccountSetUpIntent
        }
        .bind(to: _intents.subject)
        .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showAccountSetUp:
            break
        }
    }
    
    func render(state: ViewState) {
    }
}
