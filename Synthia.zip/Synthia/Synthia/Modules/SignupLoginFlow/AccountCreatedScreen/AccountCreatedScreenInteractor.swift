//
//  AccountCreatedScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

final class AccountCreatedScreenInteractorImpl: AccountCreatedScreenInteractor {
    typealias Dependencies = Any
    typealias Result = AccountCreatedScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
}
