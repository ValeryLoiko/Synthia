//
//  AccountCreatedScreenContract.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

enum AccountCreatedScreenIntent {
    case showAccountSetUpIntent
}

struct AccountCreatedScreenViewState: Equatable {
}

enum AccountCreatedScreenEffect: Equatable {
    case showAccountSetUp
}

struct AccountCreatedScreenBuilderInput {
}

protocol AccountCreatedScreenCallback {
}

enum AccountCreatedScreenResult: Equatable {
    case partialState(_ value: AccountCreatedScreenPartialState)
    case effect(_ value: AccountCreatedScreenEffect)
}

enum AccountCreatedScreenPartialState: Equatable {
    func reduce(previousState: AccountCreatedScreenViewState) -> AccountCreatedScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountCreatedScreenBuilder {
    func build(with input: AccountCreatedScreenBuilderInput) -> AccountCreatedScreenModule
}

struct AccountCreatedScreenModule {
    let view: AccountCreatedScreenView
    let callback: AccountCreatedScreenCallback
}

protocol AccountCreatedScreenView: BaseView {
    var intents: Observable<AccountCreatedScreenIntent> { get }
    func render(state: AccountCreatedScreenViewState)
}

protocol AccountCreatedScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountCreatedScreenView, triggerEffect: PublishSubject<AccountCreatedScreenEffect>) -> Observable<AccountCreatedScreenViewState>
}

protocol AccountCreatedScreenInteractor: BaseInteractor {
}

protocol AccountCreatedScreenMiddleware {
    var middlewareObservable: Observable<AccountCreatedScreenResult> { get }
    func process(result: AccountCreatedScreenResult) -> Observable<AccountCreatedScreenResult>
}
