//
//  LoginSignupScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import UIKit
import RxSwift

final class LoginSignupScreenBuilderImpl: LoginSignupScreenBuilder {
    typealias Dependencies = LoginSignupScreenInteractorImpl.Dependencies & LoginSignupScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: LoginSignupScreenBuilderInput) -> LoginSignupScreenModule {
        let interactor = LoginSignupScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = LoginSignupScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = LoginSignupScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: LoginSignupScreenViewState())
        let view = LoginSignupScreenViewController(presenter: presenter)
        return LoginSignupScreenModule(view: view, callback: middleware)
    }
}
