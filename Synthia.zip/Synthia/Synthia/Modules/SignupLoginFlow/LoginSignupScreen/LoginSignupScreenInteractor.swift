//
//  LoginSignupScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import RxSwift

final class LoginSignupScreenInteractorImpl: LoginSignupScreenInteractor {
    typealias Dependencies = Any
    typealias Result = LoginSignupScreenResult
    
    private let dependencies: Dependencies
    private let input: LoginSignupScreenBuilderInput
    
    init(dependencies: Dependencies, input: LoginSignupScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func checkOpenCase() -> RxSwift.Observable<LoginSignupScreenResult> {
        return .just(.partialState(.updateOpenCase(openCase: input.openCase)))
    }

    func continueWithGoogle() -> Observable<LoginSignupScreenResult> {
        print("Continue with google button tapped")
        return Observable.empty()
    }
}
