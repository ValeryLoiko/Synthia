//
//  LoginSignupScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import RxSwift

enum LoginSignupCases {
    case loginRegister
    case createNewAccount
}

enum LoginSignupScreenIntent {
    case createNewAccountButtonIntent
    case signinWithEmailButtonIntent
    case continueWithGoogleButtonIntent
    case closeButtonIntent
    case viewLoaded
}

struct LoginSignupScreenViewState: Equatable {
    var openCase: LoginSignupCases = .loginRegister
}

enum LoginSignupScreenEffect: Equatable {
    case showEmailLoginScreen
    case showEmailSignupScreen
    case dismissScreen
}

struct LoginSignupScreenBuilderInput {
    var openCase: LoginSignupCases
}

protocol LoginSignupScreenCallback { 
}

enum LoginSignupScreenResult: Equatable {
    case partialState(_ value: LoginSignupScreenPartialState)
    case effect(_ value: LoginSignupScreenEffect)
}

enum LoginSignupScreenPartialState: Equatable {
    case updateOpenCase(openCase: LoginSignupCases)
    func reduce(previousState: LoginSignupScreenViewState) -> LoginSignupScreenViewState {
        var state = previousState
        switch self {
        case .updateOpenCase(openCase: let openCase):
            state.openCase = openCase
        }
        return state
    }
}

protocol LoginSignupScreenBuilder {
    func build(with input: LoginSignupScreenBuilderInput) -> LoginSignupScreenModule
}

struct LoginSignupScreenModule {
    let view: LoginSignupScreenView
    let callback: LoginSignupScreenCallback
}

protocol LoginSignupScreenView: BaseView {
    var intents: Observable<LoginSignupScreenIntent> { get }
    func render(state: LoginSignupScreenViewState)
}

protocol LoginSignupScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: LoginSignupScreenView, triggerEffect: PublishSubject<LoginSignupScreenEffect>) -> Observable<LoginSignupScreenViewState>
}

protocol LoginSignupScreenInteractor: BaseInteractor {
    func checkOpenCase() -> Observable<LoginSignupScreenResult>
    func continueWithGoogle() -> Observable<LoginSignupScreenResult>
}

protocol LoginSignupScreenMiddleware {
    var middlewareObservable: Observable<LoginSignupScreenResult> { get }
    func process(result: LoginSignupScreenResult) -> Observable<LoginSignupScreenResult>
}
