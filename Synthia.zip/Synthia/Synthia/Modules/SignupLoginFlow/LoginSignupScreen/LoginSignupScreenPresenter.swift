//
//  LoginSignupScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import RxSwift

final class LoginSignupScreenPresenterImpl: LoginSignupScreenPresenter {
    typealias View = LoginSignupScreenView
    typealias ViewState = LoginSignupScreenViewState
    typealias Middleware = LoginSignupScreenMiddleware
    typealias Interactor = LoginSignupScreenInteractor
    typealias Effect = LoginSignupScreenEffect
    typealias Result = LoginSignupScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .createNewAccountButtonIntent:
                return .just(.effect(.showEmailSignupScreen))
            case .signinWithEmailButtonIntent:
                return .just(.effect(.showEmailLoginScreen))
            case .continueWithGoogleButtonIntent:
                return interactor.continueWithGoogle()
            case .closeButtonIntent:
                return .just(.effect(.dismissScreen))
            case .viewLoaded:
                return interactor.checkOpenCase()
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
