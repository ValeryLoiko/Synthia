//
//  LoginSignupScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class LoginSignupScreenViewController: BaseViewController, LoginSignupScreenView {
    typealias ViewState = LoginSignupScreenViewState
    typealias Effect = LoginSignupScreenEffect
    typealias Intent = LoginSignupScreenIntent
    typealias B = Localization.Buttons
    typealias L = Localization.LoginSingupScreen
    
    @IntentSubject() var intents: Observable<LoginSignupScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: LoginSignupScreenPresenter
    
    private lazy var emailLabel: UILabel = {
        let label = UILabel()
        label.text = L.emailLabel
        label.font = UIFont.OpenSansRegular14
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var contentView: UIStackView = {
        let contentView = UIStackView(arrangedSubviews: [createAccountButton, signInButton])
        contentView.axis = .vertical
        contentView.backgroundColor = .clear
        contentView.spacing = 16
        return contentView
    }()
    private lazy var createAccountButton = Button(style: ButtonStyle.normal, title: B.createNewAccountButton)
    private lazy var signInButton = Button(style: ButtonStyle.normal, title: B.signInWithEmailButton)
    private lazy var googleButton = Button.continueWithGoogleButton()
    
    private lazy var separatorView: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        return view
    }()
    
    private lazy var separatorLabel: UILabel = {
        let label = UILabel()
        label.text = L.orLabel
        label.textAlignment = .center
        label.font = UIFont.OpenSansRegular12
        label.backgroundColor = .white
        return label
    }()
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        button.addTarget(self, action: #selector(closeView), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    init(presenter: LoginSignupScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = L.title
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        self.navigationItem.rightBarButtonItem = closeButton
        self.sheetPresentationController?.selectedDetentIdentifier = .medium
        self.sheetPresentationController?.detents = [
            .medium(),
            .large()
        ]
        self.sheetPresentationController?.preferredCornerRadius = 16
        view.addSubview(emailLabel)
        view.addSubview(contentView)
        view.addSubview(googleButton)
        view.addSubview(separatorView)
        view.addSubview(separatorLabel)
        
        emailLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.top.equalToSuperview().inset(72)
            $0.left.right.equalToSuperview().inset(16)
        }
        
        let buttonsHeight = 56.0
        let viewHeight = 410.0
        
        contentView.snp.makeConstraints {
            $0.top.equalTo(emailLabel.snp.bottom).offset(16)
            $0.left.right.equalToSuperview().inset(16)
        }
        
        createAccountButton.snp.makeConstraints {
            $0.height.equalTo(view.snp.height).multipliedBy(buttonsHeight / viewHeight)
        }
        
        signInButton.snp.makeConstraints {
            $0.height.equalTo(view.snp.height).multipliedBy(buttonsHeight / viewHeight)
        }
        
        separatorView.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.height.equalTo(1)
            $0.top.equalTo(contentView.snp.bottom).offset(36)
            $0.left.right.equalToSuperview().inset(16)
        }
        
        separatorLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.centerY.equalTo(separatorView.snp.centerY)
            $0.height.equalTo(12)
            $0.width.equalTo(24)
        }
        
        googleButton.snp.makeConstraints {
            $0.height.equalTo(view.snp.height).multipliedBy(buttonsHeight / viewHeight)
            $0.top.equalTo(separatorView.snp.bottom).offset(36)
            $0.left.right.equalToSuperview().inset(16)
        }
    }
    
    private func bindControls() {
        createAccountButton.rx.tap
        .map { Intent.createNewAccountButtonIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
        
        signInButton.rx.tap
        .map { Intent.signinWithEmailButtonIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
        
        googleButton.rx.tap
        .map { Intent.continueWithGoogleButtonIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
    }
    
    @objc private func closeView() {
        _intents.subject.onNext(.closeButtonIntent)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showEmailLoginScreen:
            break
        case .showEmailSignupScreen:
            break
        case .dismissScreen:
            break
        }
    }
    
    private func configureUI(openCase: LoginSignupCases) {
        switch openCase {
        case .loginRegister:
            break
        case .createNewAccount:
            signInButton.removeFromSuperview()
        }
    }
    
    func render(state: ViewState) {
        configureUI(openCase: state.openCase)
    }
}
