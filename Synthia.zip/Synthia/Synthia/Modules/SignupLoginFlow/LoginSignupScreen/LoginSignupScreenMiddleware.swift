//
//  LoginSignupScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 13/01/2023.
//

import RxSwift

final class LoginSignupScreenMiddlewareImpl: LoginSignupScreenMiddleware, LoginSignupScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = LoginSignupScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showEmailLoginScreen:
                dependencies.appNavigation?.showEmailLoginScreen()
            case .showEmailSignupScreen:
                dependencies.appNavigation?.showEmailSignupScreen()
            case .dismissScreen:
                dependencies.appNavigation?.dismiss()
            }
        }
        return .just(result)
    }
}
