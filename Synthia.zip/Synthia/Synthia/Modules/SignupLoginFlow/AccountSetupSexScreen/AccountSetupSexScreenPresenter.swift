//
//  AccountSetupSexScreenPresenter.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

final class AccountSetupSexScreenPresenterImpl: AccountSetupSexScreenPresenter {
    typealias View = AccountSetupSexScreenView
    typealias ViewState = AccountSetupSexScreenViewState
    typealias Middleware = AccountSetupSexScreenMiddleware
    typealias Interactor = AccountSetupSexScreenInteractor
    typealias Effect = AccountSetupSexScreenEffect
    typealias Result = AccountSetupSexScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .skipToGudeTourButtonIntent:
                return .just(.effect(.skipButtonSetUp))
            case .nextViewButtonIntent(sex: let sex):
                return interactor.checkUserSex(sex: sex)
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
