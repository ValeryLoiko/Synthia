//
//  AccountSetupSexScreenContract.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

struct SexDataModel: Equatable {
    var sex: String
}

typealias A = Localization.AccountSetUpScreen

enum AccountSetupSexScreenIntent {
    case skipToGudeTourButtonIntent
    case nextViewButtonIntent(sex: String)
}

struct AccountSetupSexScreenViewState: Equatable {
    var selectedSex: [SexDataModel] = [
        SexDataModel(sex: A.sexOther),
        SexDataModel(sex: A.sexMale),
        SexDataModel(sex: A.sexFemale)
    ]
}

enum AccountSetupSexScreenEffect: Equatable {
    case skipButtonSetUp
    case showAccountSetupAge(accountInfo: AccountSetupModel)
}

struct AccountSetupSexScreenBuilderInput {
    var accountInfo: AccountSetupModel
}

protocol AccountSetupSexScreenCallback {
}

enum AccountSetupSexScreenResult: Equatable {
    case partialState(_ value: AccountSetupSexScreenPartialState)
    case effect(_ value: AccountSetupSexScreenEffect)
}

enum AccountSetupSexScreenPartialState: Equatable {
    func reduce(previousState: AccountSetupSexScreenViewState) -> AccountSetupSexScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountSetupSexScreenBuilder {
    func build(with input: AccountSetupSexScreenBuilderInput) -> AccountSetupSexScreenModule
}

struct AccountSetupSexScreenModule {
    let view: AccountSetupSexScreenView
    let callback: AccountSetupSexScreenCallback
}

protocol AccountSetupSexScreenView: BaseView {
    var intents: Observable<AccountSetupSexScreenIntent> { get }
    func render(state: AccountSetupSexScreenViewState)
}

protocol AccountSetupSexScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountSetupSexScreenView, triggerEffect: PublishSubject<AccountSetupSexScreenEffect>) -> Observable<AccountSetupSexScreenViewState>
}

protocol AccountSetupSexScreenInteractor: BaseInteractor {
    func checkUserSex(sex: String) -> Observable<AccountSetupSexScreenResult>
}

protocol AccountSetupSexScreenMiddleware {
    var middlewareObservable: Observable<AccountSetupSexScreenResult> { get }
    func process(result: AccountSetupSexScreenResult) -> Observable<AccountSetupSexScreenResult>
}
