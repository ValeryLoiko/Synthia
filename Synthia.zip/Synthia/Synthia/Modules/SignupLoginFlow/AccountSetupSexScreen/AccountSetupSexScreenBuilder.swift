//
//  AccountSetupSexScreenBuilder.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import UIKit
import RxSwift

final class AccountSetupSexScreenBuilderImpl: AccountSetupSexScreenBuilder {
    typealias Dependencies = AccountSetupSexScreenInteractorImpl.Dependencies & AccountSetupSexScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AccountSetupSexScreenBuilderInput) -> AccountSetupSexScreenModule {
        let interactor = AccountSetupSexScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = AccountSetupSexScreenMiddlewareImpl(dependencies: dependencies, input: input)
        let presenter = AccountSetupSexScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AccountSetupSexScreenViewState())
        let view = AccountSetupSexScreenViewController(presenter: presenter)
        return AccountSetupSexScreenModule(view: view, callback: middleware)
    }
}
