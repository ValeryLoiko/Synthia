//
//  AccountSetupSexScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

final class AccountSetupSexScreenInteractorImpl: AccountSetupSexScreenInteractor {
    typealias Dependencies = Any
    typealias Result = AccountSetupSexScreenResult
    
    private let dependencies: Dependencies
    private let input: AccountSetupSexScreenBuilderInput

    init(dependencies: Dependencies, input: AccountSetupSexScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func checkUserSex(sex: String) -> RxSwift.Observable<AccountSetupSexScreenResult> {
        return .just(.effect(.showAccountSetupAge(accountInfo: AccountSetupModel(name: input.accountInfo.name, sex: sex, age: nil, height: nil, weight: nil))))
    }
}
