//
//  AccountSetupSexScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AccountSetupSexScreenViewController: BaseViewController, AccountSetupSexScreenView, UITextFieldDelegate {
    typealias ViewState = AccountSetupSexScreenViewState
    typealias Effect = AccountSetupSexScreenEffect
    typealias Intent = AccountSetupSexScreenIntent
    typealias B = Localization.Buttons.AccountSetupScreen
    typealias A = Localization.AccountSetUpScreen
    
    @IntentSubject() var intents: Observable<AccountSetupSexScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AccountSetupSexScreenPresenter
    private var sexState = BehaviorSubject<[SexDataModel]>(value: [])
    
    init(presenter: AccountSetupSexScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var questionLabel: UILabel = {
        let label = UILabel()
        label.text = A.questionSex
        label.tintColor = .blackColor
        label.font = .OpenSansSemiBold16
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    private lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.text = A.subtitleSexLabel
        label.tintColor = .blackColor
        label.font = .OpenSansRegular14
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        return label
    }()
    
    var sexPicker = UIPickerView()
    
    private lazy var nextButton = Button(style: .normal, title: B.nextButton)
    private lazy var userSexLabel = ImagesTextField(type: .picker, title: A.sexLabel, placeholder: A.sexLabel, image: UIImage(systemName: "chevron.up.chevron.down"))
    private lazy var skipButton: UIBarButtonItem = {
        let button = Button(style: .rightStringBlack, title: B.skipButton)
        button.addTarget(self, action: #selector(skipSetup), for: .touchUpInside)
        let skipButton = UIBarButtonItem(customView: button)
        return skipButton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        bindPickerView()
        userSexLabel.textField.inputView = sexPicker
        userSexLabel.textField.delegate = self
        nextButton.disableButton()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
      }
    
    private func layoutView() {
        self.view.addSubview(questionLabel)
        self.view.addSubview(subtitleLabel)
        self.view.addSubview(userSexLabel)
        self.view.addSubview(nextButton)
        navigationItem.rightBarButtonItem = skipButton
        navigationController?.navigationBar.isHidden = false
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        questionLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(112)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(24)
        }
        
        subtitleLabel.snp.makeConstraints { make in
            make.top.equalTo(questionLabel.snp.bottom).offset(8)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(20)
        }
        
        userSexLabel.snp.makeConstraints { make in
            make.top.equalTo(subtitleLabel.snp.bottom).offset(24)
            make.left.right.equalToSuperview().inset(16)
        }
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(56)
        }
    }
    
    @objc private func skipSetup() {
        return _intents.subject.onNext(.skipToGudeTourButtonIntent)
    }
    
    private func bindPickerView() {
        sexState.asObservable().bind(to: sexPicker.rx.itemTitles) { (_, element) in
            self.userSexLabel.textField.text = element.sex
            return element.sex
        }
        .disposed(by: bag)
    }
    
    private func bindControls() {
        nextButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let userSex = self?.userSexLabel.textField.text else { return }
                self?._intents.subject.onNext(.nextViewButtonIntent(sex: userSex))
            })
            .disposed(by: bag)
        
        userSexLabel.textField.validateUserSex
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.userSexLabel.errorLabel.text = error
                self?.checkTextFiledInput()
            })
            .disposed(by: bag)
    }
    
    private func checkTextFiledInput() {
        if userSexLabel.errorLabel.text?.isEmpty ?? false {
            self.nextButton.enableButton()
        } else {
            self.nextButton.disableButton()
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .skipButtonSetUp:
            break
        case .showAccountSetupAge:
            break
        }
    }
    
    func render(state: ViewState) {
        sexState.onNext(state.selectedSex)
        }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
}
