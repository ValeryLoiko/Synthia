//
//  AccountSetupSexScreenMiddleware.swift
//  Synthia
//
//  Created by Sławek on 23/01/2023.
//

import RxSwift

final class AccountSetupSexScreenMiddlewareImpl: AccountSetupSexScreenMiddleware, AccountSetupSexScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = AccountSetupSexScreenResult
    
    private let dependencies: Dependencies
    private let input: AccountSetupSexScreenBuilderInput
    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies, input: AccountSetupSexScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .skipButtonSetUp:
                dependencies.appNavigation?.showGuideTour()
            case .showAccountSetupAge(accountInfo: let accountInfo):
                dependencies.appNavigation?.showAccountSetupAge(accountInfo: accountInfo)
            }
        }
        return .just(result)
    }
}
