//
//  EmailSignupScreenMiddleware.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

final class EmailSignupScreenMiddlewareImpl: EmailSignupScreenMiddleware, EmailSignupScreenCallback {
    typealias Dependencies = HasAppNavigation & HasNetworkingService
    typealias Result = EmailSignupScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .dismiss:
                dependencies.appNavigation?.dismiss()
            case .showTermsConditionsScreen(email: let email):
                dependencies.appNavigation?.showTermsConditionsScreen(email: email, openCase: .newUser)
            }
        }
        return .just(result)
    }
}
