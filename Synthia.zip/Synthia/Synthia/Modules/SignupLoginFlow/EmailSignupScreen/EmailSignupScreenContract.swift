//
//  EmailSignupScreenContract.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift

enum EmailSignupScreenIntent {
    case closeButton
    case continueButtonIntent(email: String, password: String)
}

struct EmailSignupScreenViewState: Equatable {
}

enum EmailSignupScreenEffect: Equatable {
    case dismiss
    case showTermsConditionsScreen(email: String)
}

struct EmailSignupScreenBuilderInput {
}

protocol EmailSignupScreenCallback { 
}

enum EmailSignupScreenResult: Equatable {
    case partialState(_ value: EmailSignupScreenPartialState)
    case effect(_ value: EmailSignupScreenEffect)
}

enum EmailSignupScreenPartialState: Equatable {
    case somethingWentWrong
    case accountAlreadyExists
    
    func reduce(previousState: EmailSignupScreenViewState) -> EmailSignupScreenViewState {
        var state = previousState
        switch self {
        case .somethingWentWrong:
            print("Something went wrong")
        case .accountAlreadyExists:
            print("Account already exists")
        }
        return state
    }
}

protocol EmailSignupScreenBuilder {
    func build(with input: EmailSignupScreenBuilderInput) -> EmailSignupScreenModule
}

struct EmailSignupScreenModule {
    let view: EmailSignupScreenView
    let callback: EmailSignupScreenCallback
}

protocol EmailSignupScreenView: BaseView {
    var intents: Observable<EmailSignupScreenIntent> { get }
    func render(state: EmailSignupScreenViewState)
}

protocol EmailSignupScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: EmailSignupScreenView, triggerEffect: PublishSubject<EmailSignupScreenEffect>) -> Observable<EmailSignupScreenViewState>
}

protocol EmailSignupScreenInteractor: BaseInteractor {
    func checkUser(_ email: String, _ password: String) -> Observable<EmailSignupScreenResult>
    //    func addNewUser(email: String) -> RxSwift.Observable<EmailSignupScreenResult>
}

protocol EmailSignupScreenMiddleware {
    var middlewareObservable: Observable<EmailSignupScreenResult> { get }
    func process(result: EmailSignupScreenResult) -> Observable<EmailSignupScreenResult>
}
