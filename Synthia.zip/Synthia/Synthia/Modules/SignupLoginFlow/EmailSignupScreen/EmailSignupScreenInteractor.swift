//
//  EmailSignupScreenInteractor.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import RxSwift
import Foundation

final class EmailSignupScreenInteractorImpl: EmailSignupScreenInteractor {
    typealias Dependencies = HasNetworkingService
    typealias Result = EmailSignupScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func checkUser(_ email: String, _ password: String) -> Observable<EmailSignupScreenResult> {
        return dependencies.networkingService.execute(request: API.Endpoint.registerUser(email: email, password: password), decodingFormat: .json)
            .map { (response: [AuthResponse]) in
                return .effect(.showTermsConditionsScreen(email: email))
            }
            .asObservable()
            .catch { error -> Observable<EmailSignupScreenResult> in
                guard let apiError = error as? ApiError else {
                    return .just(.effect(.showTermsConditionsScreen(email: email)))
                }
                switch apiError {
                case .statusCode(let statusCode):
                    guard AuthResponse.Code(rawValue: statusCode) != nil else {
                        return .just(.partialState(.somethingWentWrong))
                    }
                    return .just(.partialState(.accountAlreadyExists))
                }
            }
    }
}
