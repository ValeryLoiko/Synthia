//
//  EmailSignupScreenBuilder.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import UIKit
import RxSwift

final class EmailSignupScreenBuilderImpl: EmailSignupScreenBuilder {
    typealias Dependencies = EmailSignupScreenInteractorImpl.Dependencies & EmailSignupScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: EmailSignupScreenBuilderInput) -> EmailSignupScreenModule {
        let interactor = EmailSignupScreenInteractorImpl(dependencies: dependencies)
        let middleware = EmailSignupScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = EmailSignupScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: EmailSignupScreenViewState())
        let view = EmailSignupScreenViewController(presenter: presenter)
        return EmailSignupScreenModule(view: view, callback: middleware)
    }
}
