//
//  EmailSignupScreenViewController.swift
//  Synthia
//
//  Created by Walery Łojko on 31/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class EmailSignupScreenViewController: BaseViewController, EmailSignupScreenView {
    typealias ViewState = EmailSignupScreenViewState
    typealias Effect = EmailSignupScreenEffect
    typealias Intent = EmailSignupScreenIntent
    
    @IntentSubject() var intents: Observable<EmailSignupScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: EmailSignupScreenPresenter
    
    private lazy var closeButton: UIBarButtonItem = {
        let closeButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: nil)
        return closeButton
    }()
    private lazy var emailTextField = TextFieldInput(type: .generalField, title: L.EmailSignupScreen.emailLabel, placeholder: L.EmailSignupScreen.emailLabel)
    private lazy var passwordTextField = TextFieldInput(type: .passwordField, title: L.EmailSignupScreen.passwordLabel, placeholder: L.EmailSignupScreen.passwordLabel)
    private lazy var repeatPasswordTextFeid = TextFieldInput(type: .passwordField, title: L.EmailSignupScreen.repeatLabel, placeholder: L.EmailSignupScreen.repeatLabel)
    private lazy var continueButton = Button(style: .normal, title: L.Buttons.continueButton)
    
    init(presenter: EmailSignupScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        title = L.EmailSignupScreen.title
        self.navigationItem.rightBarButtonItem = closeButton
        view.addSubview(emailTextField)
        view.addSubview(passwordTextField)
        view.addSubview(repeatPasswordTextFeid)
        view.addSubview(continueButton)
        continueButton.disableButton()
        
        emailTextField.snp.makeConstraints {
            $0.top.equalToSuperview().offset(80)
            $0.left.right.equalToSuperview().inset(12)
        }
        
        passwordTextField.snp.makeConstraints {
            $0.top.equalTo(emailTextField.snp.bottom).offset(12)
            $0.left.right.equalToSuperview().inset(12)
        }
        
        repeatPasswordTextFeid.snp.makeConstraints {
            $0.top.equalTo(passwordTextField.snp.bottom).offset(12)
            $0.left.right.equalToSuperview().inset(12)
        }
        
        continueButton.snp.makeConstraints {
            $0.bottom.equalToSuperview().inset(50)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
        }
    }
    
    private func bindControls() {
        closeButton.rx.tap
            .map { Intent.closeButton }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        emailTextField.textField.validatedEmail
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.emailTextField.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        passwordTextField.textField.validatedPassword
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.passwordTextField.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        repeatPasswordTextFeid.textField.passwordTheSame(passwordTextField.textField)
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.repeatPasswordTextFeid.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        passwordTextField.textField.passwordTheSame(self.repeatPasswordTextFeid.textField)
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.repeatPasswordTextFeid.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        continueButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let email = self?.emailTextField.textField.text, let password = self?.passwordTextField.textField.text else { return }
                self?._intents.subject.onNext(.continueButtonIntent(email: email, password: password))
            })
            .disposed(by: bag)
    }
    
    private func checkTextfieldInput() {
        guard let emailText = emailTextField.textField.text else { return }
        guard let passwordText = passwordTextField.textField.text else { return }
        guard let repeatPasswordText = repeatPasswordTextFeid.textField.text else { return }
        
        if emailTextField.errorLabel.text?.isEmpty ?? false
            && passwordTextField.errorLabel.text?.isEmpty ?? false
            && repeatPasswordTextFeid.errorLabel.text?.isEmpty ?? false
            && !emailText.isEmpty
            && !passwordText.isEmpty
            && !repeatPasswordText.isEmpty {
            self.continueButton.enableButton()
        } else {
            self.continueButton.disableButton()
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .dismiss:
            break
        case .showTermsConditionsScreen:
            break
        }
    }
    
    func render(state: ViewState) {
    }
}
