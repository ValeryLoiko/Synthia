//
//  TermsConditionsScreenPresenter.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import RxSwift
import Foundation

final class TermsConditionsScreenPresenterImpl: TermsConditionsScreenPresenter {
    typealias View = TermsConditionsScreenView
    typealias ViewState = TermsConditionsScreenViewState
    typealias Middleware = TermsConditionsScreenMiddleware
    typealias Interactor = TermsConditionsScreenInteractor
    typealias Effect = TermsConditionsScreenEffect
    typealias Result = TermsConditionsScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { intent -> Observable<Result> in
            switch intent {
            case .acceptButton:
                return .just(.effect(.showConfirmEmailScreen))
            case .closeDeclineButton:
                return .just(.effect(.showAlertYouSure))
            case .dismissScreen:
                return .just(.effect(.dismissScreen))
            case .loadWebView:
                // swiftlint:disable: force_unwrapping
                return .just(.partialState(.loadWebView(url: URL(string: Config.webViewURL)!)))
                // swiftlint:enable: force_unwrapping
            case .viewLoaded:
                return self.interactor.checkOpenCase()
            }
        }
                             
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
