//
//  TermsConditionsScreenViewController.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit
import WebKit

final class TermsConditionsScreenViewController: BaseViewController, TermsConditionsScreenView {
    typealias ViewState = TermsConditionsScreenViewState
    typealias Effect = TermsConditionsScreenEffect
    typealias Intent = TermsConditionsScreenIntent
    typealias A = Localization.TermsConditionsScreen
    typealias L = Localization
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<TermsConditionsScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: TermsConditionsScreenPresenter
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        let closeButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: nil)
        return closeButton
    }()
    private lazy var webView: WKWebView = {
        let webView = WKWebView()
        webView.allowsBackForwardNavigationGestures = true
        return webView
    }()
    private lazy var acceptButton = Button(style: .normal, title: B.acceptButton)
    private lazy var declineButton = Button(style: .transparentBorder, title: B.declineButton)
    
    init(presenter: TermsConditionsScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        _intents.subject.onNext(Intent.loadWebView)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        self.title = L.TermsConditionsScreen.title
        self.navigationItem.rightBarButtonItem = closeButton
    }
    
    private func configureUI(openCase: TermsConditionsCases) {
        switch openCase {
        case .showAgain:
            acceptButton.removeFromSuperview()
            declineButton.removeFromSuperview()
            webView.removeFromSuperview()
            view.addSubview(webView)
            
            webView.snp.remakeConstraints {
                $0.top.equalToSuperview().offset(80)
                $0.left.right.equalToSuperview()
                $0.bottom.equalToSuperview().inset(50)
            }
        default:
            acceptButton.removeFromSuperview()
            declineButton.removeFromSuperview()
            webView.removeFromSuperview()
            view.addSubview(acceptButton)
            view.addSubview(declineButton)
            view.addSubview(webView)
            
            declineButton.snp.remakeConstraints {
                $0.bottom.equalToSuperview().inset(50)
                $0.height.equalTo(56)
                $0.left.right.equalToSuperview().inset(16)
            }
            acceptButton.snp.remakeConstraints {
                $0.height.equalTo(56)
                $0.left.right.equalToSuperview().inset(16)
                $0.bottom.equalTo(declineButton.snp.top).inset(-16)
            }
            webView.snp.remakeConstraints {
                $0.top.equalToSuperview().offset(80)
                $0.left.right.equalToSuperview()
                $0.bottom.equalTo(acceptButton.snp.top).inset(-16)
            }
        }
    }
    
    private func bindControls() {
        acceptButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.acceptButton)
            })
            .disposed(by: bag)
        
        declineButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.closeDeclineButton)
            })
            .disposed(by: bag)
        
        closeButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.closeDeclineButton)
            })
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showConfirmEmailScreen:
            break
        case .dismissScreen:
            showAlert()
        case .showAlertYouSure:
            showAlert()
        }
    }
    
    private func showAlert() {
        chooseAlert(type: .twoBtnsAlert(title: A.alertTitle, message: A.messageAlert, rightBtnTitle: L.Alerts.confirm, rightBtnStyle: .destructive, rightBtnAction: { _ in
            self._intents.subject.onNext(.dismissScreen)
        }))
    }
    
    func render(state: ViewState) {
        configureUI(openCase: state.openCase)
        guard let url = state.termsConditionsURL else { return }
        webView.load(URLRequest(url: url))
    }
}
