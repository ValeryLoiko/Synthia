//
//  TermsConditionsScreenContract.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import RxSwift
import Foundation

enum TermsConditionsCases {
    case unregisteredUser
    case newUser
    case showAgain
}

enum TermsConditionsScreenIntent {
    case acceptButton
    case closeDeclineButton
    case dismissScreen
    case loadWebView
    case viewLoaded
}

struct TermsConditionsScreenViewState: Equatable {
    var termsConditionsURL: URL?
    var openCase: TermsConditionsCases = .unregisteredUser
}

enum TermsConditionsScreenEffect: Equatable {
    case showConfirmEmailScreen
    case dismissScreen
    case showAlertYouSure
}

struct TermsConditionsScreenBuilderInput {
    var email: String?
    var openCase: TermsConditionsCases
}

protocol TermsConditionsScreenCallback {
}

enum TermsConditionsScreenResult: Equatable {
    case partialState(_ value: TermsConditionsScreenPartialState)
    case effect(_ value: TermsConditionsScreenEffect)
}

enum TermsConditionsScreenPartialState: Equatable {
    case loadWebView(url: URL)
    case updateOpenCase(openCase: TermsConditionsCases)
    func reduce(previousState: TermsConditionsScreenViewState) -> TermsConditionsScreenViewState {
        var state = previousState
        switch self {
        case .loadWebView(url: let url):
            state.termsConditionsURL = url
        case .updateOpenCase(openCase: let openCase):
            state.openCase = openCase
        }
        return state
    }
}

protocol TermsConditionsScreenBuilder {
    func build(with input: TermsConditionsScreenBuilderInput) -> TermsConditionsScreenModule
}

struct TermsConditionsScreenModule {
    let view: TermsConditionsScreenView
    let callback: TermsConditionsScreenCallback
}

protocol TermsConditionsScreenView: BaseView {
    var intents: Observable<TermsConditionsScreenIntent> { get }
    func render(state: TermsConditionsScreenViewState)
}

protocol TermsConditionsScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: TermsConditionsScreenView, triggerEffect: PublishSubject<TermsConditionsScreenEffect>) -> Observable<TermsConditionsScreenViewState>
}

protocol TermsConditionsScreenInteractor: BaseInteractor {
    func checkOpenCase() -> Observable<TermsConditionsScreenResult>
}

protocol TermsConditionsScreenMiddleware {
    var middlewareObservable: Observable<TermsConditionsScreenResult> { get }
    func process(result: TermsConditionsScreenResult) -> Observable<TermsConditionsScreenResult>
}
