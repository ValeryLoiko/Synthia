//
//  TermsConditionsScreenInteractor.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import RxSwift

final class TermsConditionsScreenInteractorImpl: TermsConditionsScreenInteractor {
    typealias Dependencies = Any
    typealias Result = TermsConditionsScreenResult
    
    private let dependencies: Dependencies
    private let input: TermsConditionsScreenBuilderInput
    
    init(dependencies: Dependencies, input: TermsConditionsScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func checkOpenCase() -> RxSwift.Observable<TermsConditionsScreenResult> {
        return .just(.partialState(.updateOpenCase(openCase: input.openCase)))
    }
}
