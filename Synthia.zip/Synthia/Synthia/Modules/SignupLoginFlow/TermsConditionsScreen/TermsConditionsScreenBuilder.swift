//
//  TermsConditionsScreenBuilder.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import UIKit
import RxSwift

final class TermsConditionsScreenBuilderImpl: TermsConditionsScreenBuilder {
    typealias Dependencies = TermsConditionsScreenInteractorImpl.Dependencies & TermsConditionsScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func build(with input: TermsConditionsScreenBuilderInput) -> TermsConditionsScreenModule {
        let interactor = TermsConditionsScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = TermsConditionsScreenMiddlewareImpl(dependencies: dependencies, userEmail: input.email, input: input)
        let presenter = TermsConditionsScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: .init())
        let view = TermsConditionsScreenViewController(presenter: presenter)
        return TermsConditionsScreenModule(view: view, callback: middleware)
    }
}
