//
//  TermsConditionsScreenMiddleware.swift
//  Synthia
//
//  Created by Walery Łojko on 08/02/2023.
//

import RxSwift

final class TermsConditionsScreenMiddlewareImpl: TermsConditionsScreenMiddleware, TermsConditionsScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = TermsConditionsScreenResult
    
    private let dependencies: Dependencies
    
    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    private let userEmail: String?
    private let input: TermsConditionsScreenBuilderInput
    
    init(dependencies: Dependencies, userEmail: String?, input: TermsConditionsScreenBuilderInput) {
        self.dependencies = dependencies
        self.userEmail = userEmail
        self.input = input
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showConfirmEmailScreen:
                switch input.openCase {
                case .newUser:
                    if let userEmail = input.email {
                        dependencies.appNavigation?.showConfirmEmailScreen(email: userEmail)
                    }
                case .unregisteredUser:
                    dependencies.appNavigation?.showAccountSetUpScreen()
                case .showAgain:
                    break
                }
            case .dismissScreen:
                dependencies.appNavigation?.dismiss()
            case .showAlertYouSure:
                break
            }
        }
        return .just(result)
    }
}
