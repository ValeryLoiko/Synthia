//
//  AccountSetupHeightScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class AccountSetupHeightScreenViewController: BaseViewController, AccountSetupHeightScreenView {
    typealias ViewState = AccountSetupHeightScreenViewState
    typealias Effect = AccountSetupHeightScreenEffect
    typealias Intent = AccountSetupHeightScreenIntent
    typealias A = Localization.AccountSetUpScreen
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<AccountSetupHeightScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: AccountSetupHeightScreenPresenter
    
    private lazy var skipButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringBlack, title: A.skipButton)
        button.addTarget(self, action: #selector(skipSetup), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    private lazy var questionLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = UIColor.blackColor
        label.text = A.heightScreenQuestion
        label.textAlignment = .left
        label.font = UIFont.OpenSansSemiBold16
        return label
    }()
    
    private lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = UIColor.blackColor
        label.text = A.heightScreenSubtitle
        label.textAlignment = .left
        label.font = UIFont.OpenSansRegular14
        return label
    }()
    
    private lazy var weightTextfield = UnitsTextField(type: .numericKeyboard, title: A.weightScreenHeightTextFieldTitle, placeholder: A.weightScreenHeightTextFieldPlaceholder, unit: A.kgUnit)
    private lazy var heightTextField = UnitsTextField(type: .numericKeyboard, title: A.heightScreenHeightTextFieldTitle, placeholder: A.heightScreenHeightTextFieldPlaceholder, unit: A.cmUnit)
    private lazy var nextButton = Button(style: .normal, title: B.GuideTourScreen.nextButton)

    init(presenter: AccountSetupHeightScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        nextButton.disableButton()
    }
    
    private func layoutView() {
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = skipButton
        
        view.addSubview(questionLabel)
        view.addSubview(subtitleLabel)
        view.addSubview(weightTextfield)
        view.addSubview(heightTextField)
        view.addSubview(nextButton)
        
        questionLabel.snp.makeConstraints {
            $0.height.equalTo(24)
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalToSuperview().inset(112)
        }
        
        subtitleLabel.snp.makeConstraints {
            $0.height.equalTo(24)
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(questionLabel.snp.bottom).offset(8)
        }
        
        weightTextfield.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(subtitleLabel.snp.bottom).offset(24)
        }
        
        heightTextField.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(weightTextfield.snp.bottom).offset(24)
        }
        
        nextButton.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalToSuperview().inset(50)
        }
    }
    
    private func bindControls() {        
        nextButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let weight = self?.weightTextfield.textField.text, let height = self?.heightTextField.textField.text else { return }
                self?._intents.subject.onNext(.nextButtonIntent(weight: Int(weight) ?? 0, height: Int(height) ?? 0))
            })
            .disposed(by: bag)
        
        weightTextfield.textField.validateWeight
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.weightTextfield.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
        
        heightTextField.textField.validateHeight
            .skip(2)
            .subscribe(onNext: { [weak self] error in
                self?.heightTextField.errorLabel.text = error
                self?.checkTextfieldInput()
            })
            .disposed(by: bag)
    }
    
    private func checkTextfieldInput() {
        guard let weight = weightTextfield.textField.text, let height = heightTextField.textField.text else { return }
        if weightTextfield.errorLabel.text?.count == 0 && heightTextField.errorLabel.text?.count == 0 && weight.count > 0 && height.count > 0 {
            self.effectsSubject.onNext(.enableNextButton)
        } else {
            self.effectsSubject.onNext(.blockNextButton)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
      }
    
    @objc private func skipSetup() {
        _intents.subject.onNext(.skipButtonIntent)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showGuideTourScreen:
            break
        case .enableNextButton:
            nextButton.enableButton()
        case .blockNextButton:
            nextButton.disableButton()
        }
    }
    
    func render(state: ViewState) {
    }
}
