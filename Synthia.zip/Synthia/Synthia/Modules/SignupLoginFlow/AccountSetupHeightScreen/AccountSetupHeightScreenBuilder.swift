//
//  AccountSetupHeightScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import UIKit
import RxSwift

final class AccountSetupHeightScreenBuilderImpl: AccountSetupHeightScreenBuilder {
    typealias Dependencies = AccountSetupHeightScreenInteractorImpl.Dependencies & AccountSetupHeightScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: AccountSetupHeightScreenBuilderInput) -> AccountSetupHeightScreenModule {
        let interactor = AccountSetupHeightScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = AccountSetupHeightScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = AccountSetupHeightScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: AccountSetupHeightScreenViewState())
        let view = AccountSetupHeightScreenViewController(presenter: presenter)
        return AccountSetupHeightScreenModule(view: view, callback: middleware)
    }
}
