//
//  AccountSetupHeightScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import RxSwift

final class AccountSetupHeightScreenInteractorImpl: AccountSetupHeightScreenInteractor {
    typealias Dependencies = HasNetworkingService & HasKeychainManager
    typealias Result = AccountSetupHeightScreenResult
    
    private let dependencies: Dependencies
    private let input: AccountSetupHeightScreenBuilderInput
    
    init(dependencies: Dependencies, input: AccountSetupHeightScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }

    func saveUserWeightAndHeight(weight: Int, height: Int) -> RxSwift.Observable<AccountSetupHeightScreenResult> {
        dependencies.networkingService.execute(request: API.Endpoint.updateUsers(email: nil, firstName: input.accountInfo.name, lastName: nil, age: input.accountInfo.age, sex: input.accountInfo.sex, height: height, weight: weight), decodingFormat: .json)
            .flatMap { (response: [GetUserResponse]) in
                self.dependencies.keychainManager.removeUserInfo()
                let response = response[0]
                let userInfo = UserInfo(firstName: response.firstName, lastName: response.lastName, age: response.age, sex: response.sex, height: response.height, email: response.email, weight: response.weight, userID: response.userID)
                self.dependencies.keychainManager.setUserInfo(userInfo: userInfo)
                return .just(.effect(.showGuideTourScreen))
            }
            .asObservable()
    }
}
