//
//  AccountSetupHeightScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/01/2023.
//

import RxSwift

enum AccountSetupHeightScreenIntent {
    case skipButtonIntent
    case nextButtonIntent(weight: Int, height: Int)
}

struct AccountSetupHeightScreenViewState: Equatable {
}

enum AccountSetupHeightScreenEffect: Equatable {
    case showGuideTourScreen
    case enableNextButton
    case blockNextButton
}

struct AccountSetupHeightScreenBuilderInput {
    var accountInfo: AccountSetupModel
}

protocol AccountSetupHeightScreenCallback {
}

enum AccountSetupHeightScreenResult: Equatable {
    case partialState(_ value: AccountSetupHeightScreenPartialState)
    case effect(_ value: AccountSetupHeightScreenEffect)
}

enum AccountSetupHeightScreenPartialState: Equatable {
    func reduce(previousState: AccountSetupHeightScreenViewState) -> AccountSetupHeightScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol AccountSetupHeightScreenBuilder {
    func build(with input: AccountSetupHeightScreenBuilderInput) -> AccountSetupHeightScreenModule
}

struct AccountSetupHeightScreenModule {
    let view: AccountSetupHeightScreenView
    let callback: AccountSetupHeightScreenCallback
}

protocol AccountSetupHeightScreenView: BaseView {
    var intents: Observable<AccountSetupHeightScreenIntent> { get }
    func render(state: AccountSetupHeightScreenViewState)
}

protocol AccountSetupHeightScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: AccountSetupHeightScreenView, triggerEffect: PublishSubject<AccountSetupHeightScreenEffect>) -> Observable<AccountSetupHeightScreenViewState>
}

protocol AccountSetupHeightScreenInteractor: BaseInteractor {
    func saveUserWeightAndHeight(weight: Int, height: Int) -> Observable<AccountSetupHeightScreenResult>
}

protocol AccountSetupHeightScreenMiddleware {
    var middlewareObservable: Observable<AccountSetupHeightScreenResult> { get }
    func process(result: AccountSetupHeightScreenResult) -> Observable<AccountSetupHeightScreenResult>
}
