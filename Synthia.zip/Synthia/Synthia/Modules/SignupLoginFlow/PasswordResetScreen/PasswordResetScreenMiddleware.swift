//
//  PasswordResetScreenMiddleware.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

final class PasswordResetScreenMiddlewareImpl: PasswordResetScreenMiddleware, PasswordResetScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = PasswordResetScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .closeScreen:
                dependencies.appNavigation?.dismiss()
            case let .showPasswordResetConfirmation(email):
                dependencies.appNavigation?.showPasswordResetConfirmationScreen(email: email)
            }
        }
        return .just(result)
    }
}
