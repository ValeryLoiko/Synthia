//
//  PasswordResetScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class PasswordResetScreenViewController: BaseViewController, PasswordResetScreenView {
    typealias ViewState = PasswordResetScreenViewState
    typealias Effect = PasswordResetScreenEffect
    typealias Intent = PasswordResetScreenIntent
    typealias B = Localization.Buttons
    typealias P = Localization.PasswordResetScreen
    typealias L = Localization.EmailLoginScreen
    
    @IntentSubject() var intents: Observable<PasswordResetScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: PasswordResetScreenPresenter
    
    init(presenter: PasswordResetScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private lazy var labelInfo: UILabel = {
        let label = UILabel()
        label.text = P.infoLabel
        label.tintColor = .blackColor
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.font = .OpenSansRegular14
        return label
    }()
    
    private lazy var emailTextField = TextFieldInput(type: .generalField, title: L.emailLabel, placeholder: L.emailLabel)
    private lazy var resetButton = Button(style: .normal, title: B.resetButton)
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: .rightXmarkBlack, title: "")
        button.addTarget(self, action: #selector(closeView), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        resetButton.disableButton()
    }
    
    private func layoutView() {
        self.title = P.title
        self.view.addSubview(labelInfo)
        self.view.addSubview(emailTextField)
        self.view.addSubview(resetButton)
        navigationItem.rightBarButtonItem = closeButton
        
        labelInfo.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(80)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(40)
        }
        
        emailTextField.snp.makeConstraints { make in
            make.top.equalTo(labelInfo.snp.bottom).offset(24)
            make.right.left.equalToSuperview().inset(16)
        }
        
        resetButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-90)
            make.left.right.equalToSuperview().inset(16)
            make.height.equalTo(56)
        }
    }
    
    @objc private func closeView() {
        _intents.subject.onNext(.closeScreenIntent)
    }
    
    private func bindControls() {
        closeButton.rx.tap.map {
            return Intent.closeScreenIntent
        }
        .bind(to: _intents.subject)
        .disposed(by: bag)
        
        resetButton.rx.tap
            .map {
                if let email = self.emailTextField.textField.text {
                    return Intent.resetPasswordButtonIntent(email: email)
                } else {
                    return Intent.resetPasswordButtonIntent(email: "")
                }
            }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        emailTextField.textField.validatedEmail
            .skip(2)
            .subscribe(onNext: { error in
                self.emailTextField.errorLabel.text = error
                self.checkTextfieldInput()
            })
            .disposed(by: bag)
    }
    
    private func checkTextfieldInput() {
        guard let emailText = emailTextField.textField.text else { return }
        
        if emailTextField.errorLabel.text?.isEmpty ?? false
            && !emailText.isEmpty {
            self.resetButton.enableButton()
        } else {
            self.resetButton.disableButton()
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .closeScreen:
            break
        case .showPasswordResetConfirmation:
            break
        }
    }
    
    func render(state: ViewState) {
    }
}
