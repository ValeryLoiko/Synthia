//
//  PasswordResetScreenContract.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

enum PasswordResetScreenIntent {
    case closeScreenIntent
    case resetPasswordButtonIntent(email: String)
}

struct PasswordResetScreenViewState: Equatable {
}

enum PasswordResetScreenEffect: Equatable {
    case closeScreen
    case showPasswordResetConfirmation(email: String)
}

struct PasswordResetScreenBuilderInput {
}

protocol PasswordResetScreenCallback { 
}

enum PasswordResetScreenResult: Equatable {
    case partialState(_ value: PasswordResetScreenPartialState)
    case effect(_ value: PasswordResetScreenEffect)
}

enum PasswordResetScreenPartialState: Equatable {
    func reduce(previousState: PasswordResetScreenViewState) -> PasswordResetScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol PasswordResetScreenBuilder {
    func build(with input: PasswordResetScreenBuilderInput) -> PasswordResetScreenModule
}

struct PasswordResetScreenModule {
    let view: PasswordResetScreenView
    let callback: PasswordResetScreenCallback
}

protocol PasswordResetScreenView: BaseView {
    var intents: Observable<PasswordResetScreenIntent> { get }
    func render(state: PasswordResetScreenViewState)
}

protocol PasswordResetScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: PasswordResetScreenView, triggerEffect: PublishSubject<PasswordResetScreenEffect>) -> Observable<PasswordResetScreenViewState>
}

protocol PasswordResetScreenInteractor: BaseInteractor {
    func checkEmail(email: String) -> Observable<PasswordResetScreenResult>
}

protocol PasswordResetScreenMiddleware {
    var middlewareObservable: Observable<PasswordResetScreenResult> { get }
    func process(result: PasswordResetScreenResult) -> Observable<PasswordResetScreenResult>
}
