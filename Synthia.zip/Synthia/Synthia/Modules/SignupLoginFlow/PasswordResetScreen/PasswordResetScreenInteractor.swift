//
//  PasswordResetScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import RxSwift

final class PasswordResetScreenInteractorImpl: PasswordResetScreenInteractor {
    typealias Dependencies = HasNetworkingService
    typealias Result = PasswordResetScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func checkEmail(email: String) -> Observable<PasswordResetScreenResult> {
        return dependencies.networkingService.execute(request: API.Endpoint.forgotPassword(email: email), decodingFormat: .json).map { (response: [ForgotPasswordResponse]) in
            return .effect(.showPasswordResetConfirmation(email: email))
        }
        .asObservable()
    }
}
