//
//  PasswordResetScreenBuilder.swift
//  Synthia
//
//  Created by Sławek on 16/01/2023.
//

import UIKit
import RxSwift

final class PasswordResetScreenBuilderImpl: PasswordResetScreenBuilder {
    typealias Dependencies = PasswordResetScreenInteractorImpl.Dependencies & PasswordResetScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: PasswordResetScreenBuilderInput) -> PasswordResetScreenModule {
        let interactor = PasswordResetScreenInteractorImpl(dependencies: dependencies)
        let middleware = PasswordResetScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = PasswordResetScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: PasswordResetScreenViewState())
        let view = PasswordResetScreenViewController(presenter: presenter)
        return PasswordResetScreenModule(view: view, callback: middleware)
    }
}
