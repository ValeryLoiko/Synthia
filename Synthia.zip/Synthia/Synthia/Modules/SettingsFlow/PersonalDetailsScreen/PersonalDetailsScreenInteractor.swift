//
//  PersonalDetailsScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 14/03/2023.
//

import RxSwift

final class PersonalDetailsScreenInteractorImpl: PersonalDetailsScreenInteractor {
    typealias Dependencies = Any
    typealias Result = PersonalDetailsScreenResult
    
    private let dependencies: Dependencies
    private let input: PersonalDetailsScreenBuilderInput
    
    init(dependencies: Dependencies, input: PersonalDetailsScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func getUserInfo() -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return .just(.partialState(.updateUserInfo(userInfo: input.userInfo)))
    }
    
    func changeAge(age: Int) -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
    
    func changeSex(sex: String) -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
    
    func changeHeight(height: Int) -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
    
    func changeWeight(weight: Int) -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
    
    func changeMeasurementUnit() -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
    
    func changeTemperatureFormat() -> RxSwift.Observable<PersonalDetailsScreenResult> {
        return Observable.empty()
    }
}
