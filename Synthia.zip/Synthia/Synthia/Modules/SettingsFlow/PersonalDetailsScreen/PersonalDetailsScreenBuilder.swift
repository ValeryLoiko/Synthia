//
//  PersonalDetailsScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 14/03/2023.
//

import UIKit
import RxSwift

final class PersonalDetailsScreenBuilderImpl: PersonalDetailsScreenBuilder {
    typealias Dependencies = PersonalDetailsScreenInteractorImpl.Dependencies & PersonalDetailsScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: PersonalDetailsScreenBuilderInput) -> PersonalDetailsScreenModule {
        let interactor = PersonalDetailsScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = PersonalDetailsScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = PersonalDetailsScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: PersonalDetailsScreenViewState(userInfo: input.userInfo))
        let view = PersonalDetailsScreenViewController(presenter: presenter)
        return PersonalDetailsScreenModule(view: view, callback: middleware)
    }
}
