//
//  PersonalDetailsScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 14/03/2023.
//

import RxSwift

final class PersonalDetailsScreenPresenterImpl: PersonalDetailsScreenPresenter {
    typealias View = PersonalDetailsScreenView
    typealias ViewState = PersonalDetailsScreenViewState
    typealias Middleware = PersonalDetailsScreenMiddleware
    typealias Interactor = PersonalDetailsScreenInteractor
    typealias Effect = PersonalDetailsScreenEffect
    typealias Result = PersonalDetailsScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .viewLoaded:
                return interactor.getUserInfo()
            case .ageIntent(age: let age):
                return interactor.changeAge(age: age)
            case .sexIntent(sex: let sex):
                return interactor.changeSex(sex: sex)
            case .heightIntent(height: let height):
                return interactor.changeHeight(height: height)
            case .weightIntent(weight: let weight):
                return interactor.changeWeight(weight: weight)
            case .measurementUnitIntent:
                return interactor.changeMeasurementUnit()
            case .temperatureFormat:
                return interactor.changeTemperatureFormat()
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
