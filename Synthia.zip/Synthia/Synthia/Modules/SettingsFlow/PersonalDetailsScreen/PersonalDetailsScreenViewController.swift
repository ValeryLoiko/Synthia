//
//  PersonalDetailsScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 14/03/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class PersonalDetailsScreenViewController: BaseViewController, PersonalDetailsScreenView {
    typealias ViewState = PersonalDetailsScreenViewState
    typealias Effect = PersonalDetailsScreenEffect
    typealias Intent = PersonalDetailsScreenIntent
    
    typealias L = Localization.PersonalDetailsScreen
    @IntentSubject() var intents: Observable<PersonalDetailsScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: PersonalDetailsScreenPresenter
    
    init(presenter: PersonalDetailsScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var personalDetailsView: PersonalDetailsTable = {
        let view = PersonalDetailsTable()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        return view
    }()

    private lazy var measurementsSectionLabel: UILabel = {
        let label = UILabel()
        label.text = L.measurements
        label.textAlignment = .left
        label.font = .OpenSansSemiBold16
        return label
    }()
    
    private lazy var measurementsStackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [measurementUnitButton, temperatureFormatButton])
        view.axis = .vertical
        view.distribution = .fillEqually
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var measurementUnitButton = PersonalDetailButton()
    private lazy var temperatureFormatButton = PersonalDetailButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = false
        title = L.personalDetails
        view.backgroundColor = .devicesScreenBackgroundColor
        view.addSubview(personalDetailsView)
        view.addSubview(measurementsSectionLabel)
        view.addSubview(measurementsStackView)
        
        personalDetailsView.snp.makeConstraints {
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(8)
            $0.height.equalTo(376)
            $0.left.right.equalToSuperview().inset(16)
        }
        
        measurementsSectionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(personalDetailsView.snp.bottom).offset(16)
        }
        
        measurementsStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(measurementsSectionLabel.snp.bottom).offset(16)
        }
        measurementUnitButton.configureDataInput(detailName: L.measurementUnit, detailValue: L.metric, isArrowPresent: true, isSeparatorNeeded: true)
        temperatureFormatButton.configureDataInput(detailName: L.temperatureFormat, detailValue: Units.celsius.rawValue, isArrowPresent: true, isSeparatorNeeded: false)
        
        measurementUnitButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
                                                 
        temperatureFormatButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
    }
    
    private func bindControls() {
        personalDetailsView.ageButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
//                self?._intents.subject.onNext(.ageIntent(age: 0))
            })
            .disposed(by: bag)
        
        personalDetailsView.sexButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
//                self?._intents.subject.onNext(.sexIntent(sex: ""))
            })
            .disposed(by: bag)
        
        personalDetailsView.heightButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
//                self?._intents.subject.onNext(.heightIntent(height: 0))
            })
            .disposed(by: bag)
        
        personalDetailsView.weightButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
//                self?._intents.subject.onNext(.weightIntent(weight: 0))
            })
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        }
    }
    
    func render(state: ViewState) {
        let userInfo = state.userInfo
        personalDetailsView.setupLabels(firstName: userInfo.firstName ?? L.unassignedValue, lastName: userInfo.lastName ?? L.unassignedValue, age: userInfo.age.flatMap({ String(describing: $0) }), sex: userInfo.sex ?? L.unassignedValue, height: userInfo.height.flatMap({ String(describing: $0) }), weight: userInfo.weight.flatMap({ String(describing: $0) }))
    }
}
