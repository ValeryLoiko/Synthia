//
//  PersonalDetailsScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 14/03/2023.
//

import RxSwift

enum PersonalDetailsScreenIntent {
    case viewLoaded
    case ageIntent(age: Int)
    case sexIntent(sex: String)
    case heightIntent(height: Int)
    case weightIntent(weight: Int)
    case measurementUnitIntent
    case temperatureFormat
}

struct PersonalDetailsScreenViewState: Equatable {
    var userInfo: UserInfo
}

enum PersonalDetailsScreenEffect: Equatable {
}

struct PersonalDetailsScreenBuilderInput {
    var userInfo: UserInfo
}

protocol PersonalDetailsScreenCallback {
}

enum PersonalDetailsScreenResult: Equatable {
    case partialState(_ value: PersonalDetailsScreenPartialState)
    case effect(_ value: PersonalDetailsScreenEffect)
}

enum PersonalDetailsScreenPartialState: Equatable {
    case updateUserInfo(userInfo: UserInfo)
    func reduce(previousState: PersonalDetailsScreenViewState) -> PersonalDetailsScreenViewState {
        var state = previousState
        switch self {
        case .updateUserInfo(userInfo: let userInfo):
            state.userInfo = userInfo
        }
        return state
    }
}

protocol PersonalDetailsScreenBuilder {
    func build(with input: PersonalDetailsScreenBuilderInput) -> PersonalDetailsScreenModule
}

struct PersonalDetailsScreenModule {
    let view: PersonalDetailsScreenView
    let callback: PersonalDetailsScreenCallback
}

protocol PersonalDetailsScreenView: BaseView {
    var intents: Observable<PersonalDetailsScreenIntent> { get }
    func render(state: PersonalDetailsScreenViewState)
}

protocol PersonalDetailsScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: PersonalDetailsScreenView, triggerEffect: PublishSubject<PersonalDetailsScreenEffect>) -> Observable<PersonalDetailsScreenViewState>
}

protocol PersonalDetailsScreenInteractor: BaseInteractor {
    func getUserInfo() -> Observable<PersonalDetailsScreenResult>
    func changeAge(age: Int) -> Observable<PersonalDetailsScreenResult>
    func changeSex(sex: String) -> Observable<PersonalDetailsScreenResult>
    func changeHeight(height: Int) -> Observable<PersonalDetailsScreenResult>
    func changeWeight(weight: Int) -> Observable<PersonalDetailsScreenResult>
    func changeMeasurementUnit() -> Observable<PersonalDetailsScreenResult>
    func changeTemperatureFormat() -> Observable<PersonalDetailsScreenResult>
    
}

protocol PersonalDetailsScreenMiddleware {
    var middlewareObservable: Observable<PersonalDetailsScreenResult> { get }
    func process(result: PersonalDetailsScreenResult) -> Observable<PersonalDetailsScreenResult>
}
