//
//  SettingsScreenInteractor.swift
//  Synthia
//
//  Created by Sławek on 14/12/2022.
//

import RxSwift

final class SettingsScreenInteractorImpl: SettingsScreenInteractor {
    typealias Dependencies = HasNetworkingService & HasAccessManager & HasKeychainManager & HasUserManager & HasMeasurementsPersistanceService & HasDevicesPersistanceService & HasToastMessageService
    typealias Result = SettingsScreenResult
    
    private let dependencies: Dependencies
    private let bag = DisposeBag()
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    private var measurementsArray: [Measurement] = []
    
    func getUserInfo() -> Observable<SettingsScreenResult> {
        guard let userInfo = dependencies.keychainManager.getUserInfo() else {
            return Observable.error(KeychainError.noUserInfo) }
        return .just(.partialState(.updateUserInfo(userInfo: userInfo)))
    }
    
    func getUserState() -> RxSwift.Observable<SettingsScreenResult> {
        return dependencies.accessManager.userStateRelay
            .flatMapLatest({ state -> Observable<SettingsScreenResult> in
                var result: Observable<SettingsScreenResult>
                if state == .loggedIn {
                    result = self.getUserInfo()
                        .startWith(SettingsScreenResult.partialState(.updateUserState(userState: .loggedIn)))
                } else {
                    result = .just(SettingsScreenResult.partialState(.updateUserState(userState: .unregistered)))
                }
                return result
            })
    }
    
    func changePassword() -> RxSwift.Observable<SettingsScreenResult> {
        return .just(.effect(.showChangePasswordScreen))
    }
    
    func logOut() -> RxSwift.Observable<SettingsScreenResult> {
        return dependencies.userManager.logOut()
            .andThen(.just(()))
            .map({ _ in
                return .effect(.showWelcomeScreen)
            })
    }
    
    func deleteAccount() -> RxSwift.Observable<SettingsScreenResult> {
        return dependencies.userManager.deleteAccount()
            .andThen(.just(()))
            .map({ _ in
                return .effect(.showWelcomeScreen)
            })
    }
    
    func deleteAllMeasurements() -> RxSwift.Observable<SettingsScreenResult> {
        dependencies.measurementsPersistanceService.deleteAllMeasurements()
        return .just(.effect(.measurementDeleted))
    }
    
    func deleteAllDevices() -> Observable<SettingsScreenResult> {
        dependencies.devicesPersistanceService.deleteAllDevices()
        return .just(.effect(.measurementDeleted))
    }
    
    func deleteAllData() -> Observable<SettingsScreenResult> {
        return deleteAllMeasurements()
            .flatMap { _ in self.deleteAllDevices() }
            .map { _ in
                self.dependencies.toastMessageService.showToastMessage(type: .removeAllData)
                return .effect(.measurementDeleted)
            }
    }
}
