//
//  SettingsScreenPresenter.swift
//  Synthia
//
//  Created by Sławek on 14/12/2022.
//

import RxSwift

final class SettingsScreenPresenterImpl: SettingsScreenPresenter {
    typealias View = SettingsScreenView
    typealias ViewState = SettingsScreenViewState
    typealias Middleware = SettingsScreenMiddleware
    typealias Interactor = SettingsScreenInteractor
    typealias Effect = SettingsScreenEffect
    typealias Result = SettingsScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .repeatGuideTourIntent:
                return .just(.effect(.showGuideTour))
            case .privacyPolicyIntent:
                return .just(.effect(.showPrivacyPolicy))
            case .termsAndConditionsIntent:
                return .just(.effect(.showTermsAndConditionsScreen))
            case .changePasswordIntent:
                return .just(.effect(.showChangePasswordScreen))
            case .logoutIntent:
                return interactor.logOut()
            case .deleteAccountIntent:
                return interactor.deleteAccount()
            case .viewLoaded:
                return interactor.getUserState()
            case .deleteAllDataIntent:
                return interactor.deleteAllData()
            case .personalDetailsIntent(userInfo: let userInfo):
                return .just(.effect(.showPersonalDetailsScreen(userInfo: userInfo)))
            case .welcomeScreenIntent:
                return .just(.effect(.showWelcomeScreen))
            case .createAccountIntent:
                return .just(.effect(.showLoginSignupScreen))
            case .showDeleteAccountAlert:
                return .just(.effect(.showDeleteAccountAlert))
            case .showDeleteAllDataAlert:
                return .just(.effect(.showDeleteAllDataAlert))
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
