//
//  SettingsScreenViewController.swift
//  Synthia
//
//  Created by Sławek on 14/12/2022.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class SettingsScreenViewController: BaseViewController, SettingsScreenView {
    typealias ViewState = SettingsScreenViewState
    typealias Effect = SettingsScreenEffect
    typealias Intent = SettingsScreenIntent
    typealias L = Localization.SettingsScreen
    typealias B = Localization.Buttons
    @IntentSubject() var intents: Observable<SettingsScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: SettingsScreenPresenter
    private var userInfo = UserInfo(firstName: nil, lastName: nil, age: nil, sex: nil, height: nil, email: nil, weight: nil, userID: -1)
    private var userStateSubject = PublishSubject<UserState>()
    
    init(presenter: SettingsScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.isScrollEnabled = true
        scrollView.showsVerticalScrollIndicator = true
        scrollView.backgroundColor = .clear
        return scrollView
    }()
    private lazy var contentView: UIStackView = {
        let contentView = UIStackView()
        contentView.axis = .vertical
        contentView.backgroundColor = .clear
        return contentView
    }()
    private lazy var mainView = UIView()
    
    private lazy var personalDetailsStackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.spacing = 8
        view.backgroundColor = .clear
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var userNameLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = .OpenSansSemiBold24
        return label
    }()
    private lazy var createAccountButton = Button.settingsReusableWhiteButton(title: L.createAccount)
    private lazy var personalDetailsButton = Button.settingsReusableButtonWithArrow(title: L.personalDetails)
    
    private lazy var notificationsSectionLabel: UILabel = {
        let label = UILabel()
        label.text = L.notificationsSettings
        label.textAlignment = .left
        label.font = .OpenSansSemiBold16
        return label
    }()
    
    private lazy var notificationsView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var notificationsHorizontalStackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [notificationsLabel, notificationsSwitch])
        view.axis = .horizontal
        view.backgroundColor = .white
        view.distribution = .fill
        view.alignment = .center
        view.spacing = 8
        return view
    }()
    
    private lazy var notificationsLabel: UILabel = {
        let label = UILabel()
        label.text = L.notifications
        label.textAlignment = .left
        label.font = .OpenSansRegular14
        return label
    }()
    
    private lazy var notificationsSwitch: UISwitch = {
        let notificationsSwitch = UISwitch()
        return notificationsSwitch
    }()
    
    private lazy var notificationsSubLabel: UILabel = {
        let label = UILabel()
        label.text = L.notificationsSublabel
        label.textAlignment = .left
        label.font = .OpenSansRegular14
        label.textColor = .grayColor
        return label
    }()
    
    private lazy var guideTourSectionLabel: UILabel = {
        let label = UILabel()
        label.text = L.guideTour
        label.textAlignment = .left
        label.font = .OpenSansSemiBold16
        return label
    }()
    
    private lazy var guideTourStackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [guideTourButton, welcomeScreenButton])
        view.axis = .vertical
        view.spacing = 8
        view.backgroundColor = .clear
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var guideTourButton = Button.settingsReusableButtonWithArrow(title: L.repeatGuideTour)
    private lazy var welcomeScreenButton = Button.settingsReusableButtonWithArrow(title: L.welcomeScreen)
    
    private lazy var legalSectionLabel: UILabel = {
        let label = UILabel()
        label.text = L.legal
        label.textAlignment = .left
        label.font = .OpenSansSemiBold16
        return label
    }()
    
    private lazy var legalStackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [termsConditionsButton])
        view.axis = .vertical
        view.backgroundColor = .white
        view.distribution = .fillProportionally
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var termsConditionsButton = Button.settingsReusableButtonWithArrow(title: L.termsConditions)
    
    private lazy var privacySectionLabel: UILabel = {
        let label = UILabel()
        label.text = L.privacy
        label.textAlignment = .left
        label.font = .OpenSansSemiBold16
        return label
    }()
    
    private lazy var privacyStackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.backgroundColor = .clear
        view.distribution = .fillProportionally
        view.spacing = 8
        view.layer.cornerRadius = 8
        return view
    }()
    
    private lazy var deleteAllDataButton = Button.settingsReusableWhiteButton(title: L.deleteAllData)
    private lazy var changePasswordButton = Button.settingsReusableButtonWithArrow(title: L.changePassword)
    private lazy var logoutButton = Button.settingsReusableWhiteButton(title: L.logOut)
    private lazy var deleteAccountButton = Button.settingsReusableWhiteButton(title: L.deleteAccount)
    
    private lazy var appVersionLabel: UILabel = {
        let label = UILabel()
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            label.text = L.appVersion + version
        }
        label.textAlignment = .center
        label.font = .OpenSansRegular14
        label.textColor = .lightGray
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = true
        view.backgroundColor = .devicesScreenBackgroundColor
        view.addSubview(scrollView)
        scrollView.snp.makeConstraints {
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top)
            $0.left.equalToSuperview()
            $0.right.equalToSuperview()
            $0.bottom.equalToSuperview()
        }
        scrollView.addSubview(mainView)
        
        let views = [personalDetailsStackView, notificationsSectionLabel, notificationsView, notificationsSubLabel, guideTourSectionLabel, guideTourStackView, legalSectionLabel, legalStackView, privacySectionLabel, privacyStackView, appVersionLabel]
        for view in views {
            mainView.addSubview(view)
        }
        
        mainView.snp.makeConstraints {
            $0.top.bottom.equalToSuperview()
            $0.left.right.equalTo(view)
        }
        
        personalDetailsStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalToSuperview()
        }
        
        notificationsSectionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(personalDetailsStackView.snp.bottom).offset(16)
            $0.height.equalTo(24)
        }
        
        notificationsView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(notificationsSectionLabel.snp.bottom).offset(16)
            $0.height.equalTo(56)
        }
        
        notificationsView.addSubview(notificationsHorizontalStackView)
        
        notificationsHorizontalStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.bottom.equalToSuperview()
        }
        
        notificationsSubLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(notificationsView.snp.bottom).offset(8)
            $0.height.equalTo(16)
        }
        
        guideTourSectionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(24)
            $0.top.equalTo(notificationsSubLabel.snp.bottom).offset(24)
        }
        
        guideTourStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(guideTourSectionLabel.snp.bottom).offset(16)
        }
        
        guideTourButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
        
        welcomeScreenButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
        
        legalSectionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(24)
            $0.top.equalTo(guideTourStackView.snp.bottom).offset(24)
        }
        
        legalStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(legalSectionLabel.snp.bottom).offset(16)
        }
        
        termsConditionsButton.snp.makeConstraints {
            $0.height.equalTo(56)
        }
        
        privacySectionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(24)
            $0.top.equalTo(legalStackView.snp.bottom).offset(24)
        }
        
        privacyStackView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(privacySectionLabel.snp.bottom).offset(16)
        }
        
        appVersionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(privacyStackView.snp.bottom).offset(24)
            $0.bottom.equalToSuperview()
        }
    }
    
    private func bindControls() {
        guideTourButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.repeatGuideTourIntent)
            })
            .disposed(by: bag)
        
        createAccountButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.createAccountIntent)
            })
            .disposed(by: bag)
        
        welcomeScreenButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.welcomeScreenIntent)
            })
            .disposed(by: bag)
        
        termsConditionsButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.termsAndConditionsIntent)
            })
            .disposed(by: bag)
        
        changePasswordButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.changePasswordIntent)
            })
            .disposed(by: bag)
        
        logoutButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.logoutIntent)
            })
            .disposed(by: bag)
        
        deleteAccountButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.showDeleteAccountAlert)
            })
            .disposed(by: bag)
        
        deleteAllDataButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                self?._intents.subject.onNext(.showDeleteAllDataAlert)
            })
            .disposed(by: bag)
        
        personalDetailsButton.rx.tap
            .subscribe(onNext: { [weak self] _ in
                guard let self else { return }
                self._intents.subject.onNext(.personalDetailsIntent(userInfo: self.userInfo))
            })
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showDeleteAccountAlert:
            chooseAlert(type: .twoBtnsAlert(title: L.deleteAccountAlertTitle, message: L.deleteAccountAlertMessage, rightBtnTitle: B.confirmButton, rightBtnStyle: .destructive, rightBtnAction: { _ in
                self._intents.subject.onNext(.deleteAccountIntent)
            }))
        case .showDeleteAllDataAlert:
            chooseAlert(type: .twoBtnsAlert(title: L.deleteAllDataTitle, message: L.deleteAllDataMessage, rightBtnTitle: B.confirmButton, rightBtnStyle: .destructive, rightBtnAction: { _ in
                self._intents.subject.onNext(.deleteAllDataIntent)
            }))
        default:
            break
        }
    }
    
    private func configureUI(userState: UserState) {
        switch userState {
        case .unregistered, .unknown:
            userNameLabel.removeFromSuperview()
            personalDetailsButton.removeFromSuperview()
            createAccountButton.removeFromSuperview()
            changePasswordButton.removeFromSuperview()
            logoutButton.removeFromSuperview()
            deleteAccountButton.removeFromSuperview()
            deleteAllDataButton.removeFromSuperview()
            
            personalDetailsStackView.addArrangedSubview(createAccountButton)
            personalDetailsStackView.addArrangedSubview(personalDetailsButton)
            
            createAccountButton.snp.remakeConstraints {
                $0.height.equalTo(56)
            }
            personalDetailsButton.snp.remakeConstraints {
                $0.height.equalTo(56)
            }
            
            privacyStackView.addArrangedSubview(deleteAllDataButton)
            deleteAllDataButton.snp.makeConstraints {
                $0.height.equalTo(56)
            }
        case .loggedIn:
            userNameLabel.removeFromSuperview()
            personalDetailsButton.removeFromSuperview()
            createAccountButton.removeFromSuperview()
            changePasswordButton.removeFromSuperview()
            logoutButton.removeFromSuperview()
            deleteAccountButton.removeFromSuperview()
            deleteAllDataButton.removeFromSuperview()
            
            personalDetailsStackView.addArrangedSubview(userNameLabel)
            personalDetailsStackView.addArrangedSubview(personalDetailsButton)
            personalDetailsButton.snp.remakeConstraints {
                $0.height.equalTo(56)
            }
            
            privacyStackView.addArrangedSubview(changePasswordButton)
            privacyStackView.addArrangedSubview(logoutButton)
            privacyStackView.addArrangedSubview(deleteAccountButton)
            changePasswordButton.snp.makeConstraints {
                $0.height.equalTo(56)
            }
            logoutButton.snp.makeConstraints {
                $0.height.equalTo(56)
            }
            deleteAccountButton.snp.makeConstraints {
                $0.height.equalTo(56)
            }
        }
    }
    
    func render(state: ViewState) {
        configureUI(userState: state.userState)
        userStateSubject.onNext(state.userState)
        userInfo = state.userInfo
        if let firstName = state.userInfo.firstName, let lastName = state.userInfo.lastName {
            userNameLabel.text = firstName + " " + lastName
        }
    }
    // swiftlint:disable:next file_length
}
