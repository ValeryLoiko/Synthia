//
//  SettingsScreenMiddleware.swift
//  Synthia
//
//  Created by Sławek on 14/12/2022.
//

import RxSwift

final class SettingsScreenMiddlewareImpl: SettingsScreenMiddleware, SettingsScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = SettingsScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showGuideTour:
                dependencies.appNavigation?.showGuideTour()
            case .showPrivacyPolicy:
                break
            case .showTermsAndConditionsScreen:
                dependencies.appNavigation?.showTermsConditionsScreen(email: nil, openCase: .showAgain)
            case .showPersonalDetailsScreen(userInfo: let userInfo):
                dependencies.appNavigation?.showPersonalDetails(userInfo: userInfo)
            case .showWelcomeScreen:
                dependencies.appNavigation?.showWelcomeScreen()
            case .showLoginSignupScreen:
                dependencies.appNavigation?.showLoginSignupScreen(openCase: .createNewAccount)
            case .showDeleteAccountAlert:
                break
            case .measurementDeleted:
                break
            case .showDeleteAllDataAlert:
                break
            case .showChangePasswordScreen:
                dependencies.appNavigation?.showPasswordResetScreen()
            }
        }
        return .just(result)
    }
}
