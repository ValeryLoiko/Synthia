//
//  SettingsScreenContract.swift
//  Synthia
//
//  Created by Sławek on 14/12/2022.
//

import RxSwift

struct UserInfo: Equatable, Codable {
    let firstName: String?
    let lastName: String?
    let age: Int?
    let sex: String?
    let height: Int?
    let email: String?
    let weight: Int?
    let userID: Int
}

enum SettingsScreenIntent {
    case personalDetailsIntent(userInfo: UserInfo)
    case repeatGuideTourIntent
    case privacyPolicyIntent
    case termsAndConditionsIntent
    case changePasswordIntent
    case logoutIntent
    case deleteAccountIntent
    case showDeleteAccountAlert
    case showDeleteAllDataAlert
    case viewLoaded
    case deleteAllDataIntent
    case welcomeScreenIntent
    case createAccountIntent
}

struct SettingsScreenViewState: Equatable {
    var userState: UserState = .unregistered
    var userInfo = UserInfo(firstName: nil, lastName: nil, age: nil, sex: nil, height: nil, email: nil, weight: nil, userID: -1)
}

enum SettingsScreenEffect: Equatable {
    case showPersonalDetailsScreen(userInfo: UserInfo)
    case showGuideTour
    case showPrivacyPolicy
    case showTermsAndConditionsScreen
    case showWelcomeScreen
    case showLoginSignupScreen
    case showDeleteAccountAlert
    case showDeleteAllDataAlert
    case measurementDeleted
    case showChangePasswordScreen
}

struct SettingsScreenBuilderInput {
}

protocol SettingsScreenCallback {
}

enum SettingsScreenResult: Equatable {
    case partialState(_ value: SettingsScreenPartialState)
    case effect(_ value: SettingsScreenEffect)
}

enum SettingsScreenPartialState: Equatable {
    case updateUserState(userState: UserState)
    case updateUserInfo(userInfo: UserInfo)
    func reduce(previousState: SettingsScreenViewState) -> SettingsScreenViewState {
        var state = previousState
        switch self {
        case .updateUserState(userState: let userState):
            state.userState = userState
        case .updateUserInfo(userInfo: let userInfo):
            state.userInfo = userInfo
        }
        return state
    }
}

protocol SettingsScreenBuilder {
    func build(with input: SettingsScreenBuilderInput) -> SettingsScreenModule
}

struct SettingsScreenModule {
    let view: SettingsScreenView
    let callback: SettingsScreenCallback
}

protocol SettingsScreenView: BaseView {
    var intents: Observable<SettingsScreenIntent> { get }
    func render(state: SettingsScreenViewState)
}

protocol SettingsScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: SettingsScreenView, triggerEffect: PublishSubject<SettingsScreenEffect>) -> Observable<SettingsScreenViewState>
}

protocol SettingsScreenInteractor: BaseInteractor {
    func changePassword() -> Observable<SettingsScreenResult>
    func logOut() -> Observable<SettingsScreenResult>
    func deleteAccount() -> Observable<SettingsScreenResult>
    func getUserInfo() -> Observable<SettingsScreenResult>
    func getUserState() -> Observable<SettingsScreenResult>
    func deleteAllData() -> Observable<SettingsScreenResult>
}

protocol SettingsScreenMiddleware {
    var middlewareObservable: Observable<SettingsScreenResult> { get }
    func process(result: SettingsScreenResult) -> Observable<SettingsScreenResult>
}
