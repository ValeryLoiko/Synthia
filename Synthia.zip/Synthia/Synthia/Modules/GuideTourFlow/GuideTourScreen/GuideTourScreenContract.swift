//
//  GuideTourScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 20/01/2023.
//

import RxSwift

struct GuideTourScreenPageModel: Equatable {
    var imageName: String
    var headerText: String
    var descriptionText: String
}

typealias G = Localization.GuideTour

enum GuideTourScreenIntent {
    case skipGuideTourIntent
}

struct GuideTourScreenViewState: Equatable {
    var pageViewData: [GuideTourScreenPageModel] = [
        GuideTourScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: G.titleView1, descriptionText: G.subTitleView1),
        GuideTourScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: G.titleView2, descriptionText: G.subTitleView2),
        GuideTourScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: G.titleView3, descriptionText: G.subTitleView3),
        GuideTourScreenPageModel(imageName: AssetsCatalog.General.welcomeScreenImage, headerText: G.titleView4, descriptionText: G.subTitleView4)
    ]
}

enum GuideTourScreenEffect: Equatable {
    case showStartButton
    case showNextButton
    case showGetStartedButton
    case showDevicesScreen
}

struct GuideTourScreenBuilderInput {
}

protocol GuideTourScreenCallback {
}

enum GuideTourScreenResult: Equatable {
    case partialState(_ value: GuideTourScreenPartialState)
    case effect(_ value: GuideTourScreenEffect)
}

enum GuideTourScreenPartialState: Equatable {
    func reduce(previousState: GuideTourScreenViewState) -> GuideTourScreenViewState {
        switch self {
        default:
            return previousState
        }
    }
}

protocol GuideTourScreenBuilder {
    func build(with input: GuideTourScreenBuilderInput) -> GuideTourScreenModule
}

struct GuideTourScreenModule {
    let view: GuideTourScreenView
    let callback: GuideTourScreenCallback
}

protocol GuideTourScreenView: BaseView {
    var intents: Observable<GuideTourScreenIntent> { get }
    func render(state: GuideTourScreenViewState)
}

protocol GuideTourScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: GuideTourScreenView, triggerEffect: PublishSubject<GuideTourScreenEffect>) -> Observable<GuideTourScreenViewState>
}

protocol GuideTourScreenInteractor: BaseInteractor {
}

protocol GuideTourScreenMiddleware {
    var middlewareObservable: Observable<GuideTourScreenResult> { get }
    func process(result: GuideTourScreenResult) -> Observable<GuideTourScreenResult>
}
