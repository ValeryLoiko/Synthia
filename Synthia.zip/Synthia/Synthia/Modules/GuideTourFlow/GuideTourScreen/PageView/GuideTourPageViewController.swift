//
//  WelcomeScreenPageViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 17/01/2023.
//

import UIKit
import SnapKit
import RxSwift

class GuideTourPageViewController: UIPageViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    private lazy var pageControl = UIPageControl()
    
    var pages: [PageVCGuideScreen] = []
    private var currentPageSubject = PublishSubject<Int>()
    var currentPageObserver: RxSwift.Observable<Int> { return currentPageSubject }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        self.delegate = self
    }
    
    func showNextPage() {
        let currentIndex = self.pageControl.currentPage
        let nextIndex = currentIndex + 1
        if nextIndex < self.pages.count {
            setViewControllers([pages[nextIndex]], direction: .forward, animated: true, completion: nil)
            self.pageControl.currentPage = nextIndex
            self.currentPageSubject.onNext(nextIndex)
        }
    }
    
    func changePange(index: Int) {
        self.pageControl.currentPage = index
        self.currentPageSubject.onNext(index)
        setViewControllers([pages[index]], direction: .forward, animated: true, completion: nil)
    }
    
    func setPages(pages: [PageVCGuideScreen]) {
        self.pages = pages
        setPageControl()
    }
    
    private func setPageControl() {
        pageControl.isEnabled = false
        let initialPage = 0
        if !pages.isEmpty {
            setViewControllers([pages[initialPage]], direction: .forward, animated: false, completion: nil)
        }
         self.pageControl.frame = CGRect()
         self.pageControl.currentPageIndicatorTintColor = UIColor.black
         self.pageControl.pageIndicatorTintColor = UIColor.lightGray
         self.pageControl.numberOfPages = self.pages.count
         self.pageControl.currentPage = initialPage
         self.view.addSubview(self.pageControl)
        
        pageControl.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.width.equalToSuperview().inset(10)
            $0.bottom.equalToSuperview()
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        // swiftlint:disable:next force_cast
        if let viewControllerIndex = self.pages.firstIndex(of: viewController as! PageVCGuideScreen) {
            // swiftlint:enable force_cast
            if viewControllerIndex != 0 {
                return self.pages[viewControllerIndex - 1]
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        // swiftlint:disable:next force_cast
        if let viewControllerIndex = self.pages.firstIndex(of: viewController as! PageVCGuideScreen) {
            // swiftlint:enable force_cast
            if viewControllerIndex < self.pages.count - 1 {
                return self.pages[viewControllerIndex + 1]
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if let viewControllers = pageViewController.viewControllers {
            // swiftlint:disable:next force_cast
            if let viewControllerIndex = self.pages.firstIndex(of: viewControllers[0] as! PageVCGuideScreen) {
                // swiftlint:enable force_cast
                self.pageControl.currentPage = viewControllerIndex
                self.currentPageSubject.onNext(self.pageControl.currentPage)
            }
        }
    }
}
