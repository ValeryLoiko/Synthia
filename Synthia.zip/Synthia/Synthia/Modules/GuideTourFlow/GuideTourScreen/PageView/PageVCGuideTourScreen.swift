//
//  PageVCWelcomeScreen.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 18/01/2023.
//

import UIKit
import SnapKit

class PageVCGuideScreen: UIViewController {
    var imageName: String
    var titleText: String
    var descriptionText: String
    
    private lazy var guideTourImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage.assetImageName(imageName)
        image.contentMode = .scaleAspectFit
        image.tintColor = .blackColor
        return image
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = UIColor.blackColor
        label.text = titleText
        label.textAlignment = .center
        label.font = UIFont.OpenSansSemiBold16
        label.numberOfLines = 0
        return label
    }()
    
    lazy var descriptionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackColor
        label.text = descriptionText
        label.textAlignment = .center
        label.font = UIFont.sfProTextRegular14
        label.numberOfLines = 0
        return label
    }()
    
    init(imageName: String, titleText: String, descriptionText: String) {
        self.titleText = titleText
        self.imageName = imageName
        self.descriptionText = descriptionText
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutViews()
    }
    
    private func layoutViews() {
        view.addSubview(guideTourImage)
        view.addSubview(titleLabel)
        view.addSubview(descriptionLabel)
        
        guideTourImage.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(24)
            $0.top.equalToSuperview()
            $0.bottom.equalTo(titleLabel.snp.top).offset(-40)
        }
        
        titleLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(28)
            $0.bottom.equalTo(descriptionLabel.snp.top).offset(-16)
            $0.height.equalTo(24)
        }
        
        descriptionLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(24)
            $0.bottom.equalToSuperview().offset(-64)
            $0.height.equalTo(84)
        }
    }
}
