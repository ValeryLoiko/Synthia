//
//  GuideTourScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 20/01/2023.
//

import UIKit
import RxSwift

final class GuideTourScreenBuilderImpl: GuideTourScreenBuilder {
    typealias Dependencies = GuideTourScreenInteractorImpl.Dependencies & GuideTourScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: GuideTourScreenBuilderInput) -> GuideTourScreenModule {
        let interactor = GuideTourScreenInteractorImpl(dependencies: dependencies)
        let middleware = GuideTourScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = GuideTourScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: GuideTourScreenViewState())
        let view = GuideTourScreenViewController(presenter: presenter)
        return GuideTourScreenModule(view: view, callback: middleware)
    }
}
