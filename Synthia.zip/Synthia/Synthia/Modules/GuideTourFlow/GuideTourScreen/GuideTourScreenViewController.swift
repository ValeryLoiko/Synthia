//
//  GuideTourScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 20/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class GuideTourScreenViewController: BaseViewController, GuideTourScreenView {
    typealias ViewState = GuideTourScreenViewState
    typealias Effect = GuideTourScreenEffect
    typealias Intent = GuideTourScreenIntent
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<GuideTourScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: GuideTourScreenPresenter
    
    private var pages: [PageVCGuideScreen] = []
    private var currentPage: Int = 0
    
    private lazy var pageViewController = GuideTourPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
    
    private lazy var skipButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringBlack, title: B.GuideTourScreen.skipGuideTourButton)
        button.addTarget(self, action: #selector(skipGuideTour), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    private lazy var startButton = Button(style: .normal, title: B.GuideTourScreen.startButton)
    private lazy var nextButton = Button(style: .normal, title: B.GuideTourScreen.nextButton)
    private lazy var getStartedButton = Button(style: .normal, title: B.GuideTourScreen.getStartedButton)
    
    init(presenter: GuideTourScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
    }
    
    private func layoutView() {
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.rightBarButtonItem = skipButton
        startButton.showButton()
        nextButton.hideButton()
        getStartedButton.hideButton()
        
        view.addSubview(startButton)
        view.addSubview(nextButton)
        view.addSubview(getStartedButton)
        view.addSubview(pageViewController.view)
        
        let viewHeight = 896.0
        let pageControllerHeight = 554.0
        
        startButton.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalToSuperview().inset(50)
        }
        
        nextButton.snp.makeConstraints {
            $0.edges.equalTo(startButton.snp.edges)
        }
        
        getStartedButton.snp.makeConstraints {
            $0.edges.equalTo(startButton.snp.edges)
        }
        
        pageViewController.view.snp.makeConstraints {
            $0.left.right.equalToSuperview()
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.height.equalTo(view.snp.height).multipliedBy(pageControllerHeight / viewHeight)
        }
    }
    
    private func bindControls() {
        getStartedButton.rx.tap
            .map { Intent.skipGuideTourIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        startButton.rx.tap.asObservable()
            .subscribe(onNext: { _ in
                self.pageViewController.showNextPage()
            }).disposed(by: bag)
        
        nextButton.rx.tap.asObservable()
            .subscribe(onNext: { _ in
                self.pageViewController.showNextPage()
            }).disposed(by: bag)
        
        getStartedButton.rx.tap.asObservable()
            .subscribe(onNext: { _ in
                self.pageViewController.showNextPage()
            }).disposed(by: bag)
        
        pageViewController.currentPageObserver.subscribe(onNext: { page in
            self.currentPage = page
            switch self.currentPage {
            case 0:
                self.effectsSubject.onNext(.showStartButton)
            case 1, 2:
                self.effectsSubject.onNext(.showNextButton)
            case 3:
                self.effectsSubject.onNext(.showGetStartedButton)
            default:
                self.effectsSubject.onNext(.showStartButton)
            }
        }).disposed(by: bag)
    }
    
    @objc private func skipGuideTour() {
        _intents.subject.onNext(.skipGuideTourIntent)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showStartButton:
            startButton.showButton()
            nextButton.hideButton()
            getStartedButton.hideButton()
            self.navigationItem.rightBarButtonItem = skipButton
        case .showNextButton:
            startButton.hideButton()
            nextButton.showButton()
            getStartedButton.hideButton()
            self.navigationItem.rightBarButtonItem = skipButton
        case .showGetStartedButton:
            startButton.hideButton()
            nextButton.hideButton()
            getStartedButton.showButton()
            self.navigationItem.setRightBarButton(nil, animated: true)
        case .showDevicesScreen:
            break
        }
    }
    
    func render(state: ViewState) {
        let pages = state.pageViewData.map { item in
            PageVCGuideScreen(imageName: item.imageName, titleText: item.headerText, descriptionText: item.descriptionText)
        }
        self.pageViewController.setPages(pages: pages)
    }
}
