//
//  GuideTourScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 20/01/2023.
//

import RxSwift

final class GuideTourScreenInteractorImpl: GuideTourScreenInteractor {
    typealias Dependencies = Any
    typealias Result = GuideTourScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
}
