//
//  GuideTourScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 20/01/2023.
//

import RxSwift

final class GuideTourScreenMiddlewareImpl: GuideTourScreenMiddleware, GuideTourScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = GuideTourScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showStartButton:
                break
            case .showNextButton:
                break
            case .showGetStartedButton:
                break
            case .showDevicesScreen:
                dependencies.appNavigation?.showDevicesScreen()
            }
        }
        return .just(result)
    }
}
