//
//  MeasurementsGroupedDataScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 06/02/2023.
//

import RxSwift

final class MeasurementsGroupedDataScreenPresenterImpl: MeasurementsGroupedDataScreenPresenter {
    typealias View = MeasurementsGroupedDataScreenView
    typealias ViewState = MeasurementsGroupedDataScreenViewState
    typealias Middleware = MeasurementsGroupedDataScreenMiddleware
    typealias Interactor = MeasurementsGroupedDataScreenInteractor
    typealias Effect = MeasurementsGroupedDataScreenEffect
    typealias Result = MeasurementsGroupedDataScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .viewLoaded:
                return interactor.loadMeasurements()
            case .cellTapped(deviceID: let deviceID, measurementName: let measurementName, day: let day):
                return .just(.effect(.showMeasurementHistorySingle(deviceID: deviceID, measurementName: measurementName, day: day)))
            case .deleteMeasurement(row: let row):
                return interactor.deleteMeasurement(at: row)
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
