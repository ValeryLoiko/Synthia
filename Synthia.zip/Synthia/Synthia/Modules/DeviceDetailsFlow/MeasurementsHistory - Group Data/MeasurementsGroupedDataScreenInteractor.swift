//
//  MeasurementsGroupedDataScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 06/02/2023.
//

import RxSwift
import Foundation

final class MeasurementsGroupedDataScreenInteractorImpl: MeasurementsGroupedDataScreenInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = MeasurementsGroupedDataScreenResult
    
    private let dependencies: Dependencies
    private let input: MeasurementsGroupedDataScreenBuilderInput
    
    init(dependencies: Dependencies, input: MeasurementsGroupedDataScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    private var measurementsArray: [Measurement] = []

    func loadMeasurements() -> RxSwift.Observable<MeasurementsGroupedDataScreenResult> {
        dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByIdAndName(id: self.input.deviceID, name: self.input.measurementName)
                    .asObservable()
            }
            .map({ measurements -> [Measurement] in
                measurements.map { measurement in
                    Measurement(deviceId: measurement.deviceId, name: measurement.name, value: measurement.value, unit: measurement.unit, measurementDate: measurement.measurementDate, measurementID: measurement.measurementID)
                }
            })
            .map({ savedMeasurements -> MeasurementsGroupedDataScreenResult in
                let calendar = Calendar.current
                let groupingComponentFlags: Set<Calendar.Component> = [.year, .month, .day]
                let groupedMeasurements = Dictionary(grouping: savedMeasurements) { measurement in
                    calendar.dateComponents(groupingComponentFlags, from: measurement.measurementDate)
                }
                
                let latestMeasurements = groupedMeasurements.compactMap { _, measurements in
                    measurements.sorted { $0.measurementDate > $1.measurementDate }.first
                }.sorted { $0.measurementDate > $1.measurementDate }
                self.measurementsArray = latestMeasurements
                return .partialState(.updateMeasurementsArray(measurements: latestMeasurements))
            })
            .asObservable()
    }
    
    func deleteMeasurement(at row: Int) -> RxSwift.Observable<MeasurementsGroupedDataScreenResult> {
        let chosenMeasurement = measurementsArray[row]
        dependencies.measurementsPersistanceService.deleteMeasurementsFromDeviceFromSelectedDay(measurement: chosenMeasurement)
        return .just(.effect(.measurementDeleted))
    }
}
