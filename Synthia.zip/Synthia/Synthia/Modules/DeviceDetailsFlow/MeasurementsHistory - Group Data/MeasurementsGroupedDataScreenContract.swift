//
//  MeasurementsGroupedDataScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 06/02/2023.
//

import RxSwift
import Foundation

enum MeasurementsGroupedDataScreenIntent {
    case viewLoaded
    case cellTapped(deviceID: String, measurementName: MeasurementName, day: Date)
    case deleteMeasurement(row: Int)
}

struct MeasurementsGroupedDataScreenViewState: Equatable {
    var deviceID: String
    var measurementName: MeasurementName
    var measurements: [Measurement] = []
}

enum MeasurementsGroupedDataScreenEffect: Equatable {
    case showMeasurementHistorySingle(deviceID: String, measurementName: MeasurementName, day: Date)
    case measurementDeleted
}

struct MeasurementsGroupedDataScreenBuilderInput {
    var deviceID: String
    var measurementName: MeasurementName
}

protocol MeasurementsGroupedDataScreenCallback {
}

enum MeasurementsGroupedDataScreenResult: Equatable {
    case partialState(_ value: MeasurementsGroupedDataScreenPartialState)
    case effect(_ value: MeasurementsGroupedDataScreenEffect)
}

enum MeasurementsGroupedDataScreenPartialState: Equatable {
    case updateMeasurementsArray(measurements: [Measurement])

    func reduce(previousState: MeasurementsGroupedDataScreenViewState) -> MeasurementsGroupedDataScreenViewState {
        var state = previousState
        switch self {
        case .updateMeasurementsArray(measurements: let measurements):
            state.measurements = measurements
        }
        return state
    }
}

protocol MeasurementsGroupedDataScreenBuilder {
    func build(with input: MeasurementsGroupedDataScreenBuilderInput) -> MeasurementsGroupedDataScreenModule
}

struct MeasurementsGroupedDataScreenModule {
    let view: MeasurementsGroupedDataScreenView
    let callback: MeasurementsGroupedDataScreenCallback
}

protocol MeasurementsGroupedDataScreenView: BaseView {
    var intents: Observable<MeasurementsGroupedDataScreenIntent> { get }
    func render(state: MeasurementsGroupedDataScreenViewState)
}

protocol MeasurementsGroupedDataScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: MeasurementsGroupedDataScreenView, triggerEffect: PublishSubject<MeasurementsGroupedDataScreenEffect>) -> Observable<MeasurementsGroupedDataScreenViewState>
}

protocol MeasurementsGroupedDataScreenInteractor: BaseInteractor {
    func loadMeasurements() -> Observable<MeasurementsGroupedDataScreenResult>
    func deleteMeasurement(at row: Int) -> Observable<MeasurementsGroupedDataScreenResult>

}

protocol MeasurementsGroupedDataScreenMiddleware {
    var middlewareObservable: Observable<MeasurementsGroupedDataScreenResult> { get }
    func process(result: MeasurementsGroupedDataScreenResult) -> Observable<MeasurementsGroupedDataScreenResult>
}
