//
//  MeasurementsGroupedDataScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 06/02/2023.
//

import RxSwift

final class MeasurementsGroupedDataScreenMiddlewareImpl: MeasurementsGroupedDataScreenMiddleware, MeasurementsGroupedDataScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = MeasurementsGroupedDataScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .showMeasurementHistorySingle(deviceID: let deviceID, measurementName: let measurementName, day: let day):
                dependencies.appNavigation?.showMeasurementHistorySingle(deviceID: deviceID, measurementName: measurementName, day: day)
            case .measurementDeleted:
                break
            }
        }
        return .just(result)
    }
}
