//
//  MeasurementsGroupedDataScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 06/02/2023.
//

import UIKit
import RxSwift

final class MeasurementsGroupedDataScreenBuilderImpl: MeasurementsGroupedDataScreenBuilder {
    typealias Dependencies = MeasurementsGroupedDataScreenInteractorImpl.Dependencies & MeasurementsGroupedDataScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: MeasurementsGroupedDataScreenBuilderInput) -> MeasurementsGroupedDataScreenModule {
        let interactor = MeasurementsGroupedDataScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = MeasurementsGroupedDataScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = MeasurementsGroupedDataScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: MeasurementsGroupedDataScreenViewState(deviceID: input.deviceID, measurementName: input.measurementName))
        let view = MeasurementsGroupedDataScreenViewController(presenter: presenter)
        return MeasurementsGroupedDataScreenModule(view: view, callback: middleware)
    }
}
