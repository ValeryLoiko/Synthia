//
//  LatestMeasurementsHistoryScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 21/02/2023.
//

import UIKit
import RxSwift

final class LatestMeasurementsHistoryScreenBuilderImpl: LatestMeasurementsHistoryScreenBuilder {
    typealias Dependencies = LatestMeasurementsHistoryScreenInteractorImpl.Dependencies & LatestMeasurementsHistoryScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: LatestMeasurementsHistoryScreenBuilderInput) -> LatestMeasurementsHistoryScreenModule {
        let interactor = LatestMeasurementsHistoryScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = LatestMeasurementsHistoryScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = LatestMeasurementsHistoryScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: LatestMeasurementsHistoryScreenViewState())
        let view = LatestMeasurementsHistoryScreenViewController(presenter: presenter)
        return LatestMeasurementsHistoryScreenModule(view: view, callback: middleware)
    }
}
