//
//  LatestMeasurementsHistoryScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 21/02/2023.
//

import RxSwift

enum LatestMeasurementsHistoryScreenIntent {
    case viewLoaded
    case cellTapped(deviceID: String, measurementName: MeasurementName)
}

struct LatestMeasurementsHistoryScreenViewState: Equatable {
    var measurementsArray: [Measurement] = []
}

enum LatestMeasurementsHistoryScreenEffect: Equatable {
    case showMeasurementsHistoryGroupedScreen(deviceID: String, measurementName: MeasurementName)
}

struct LatestMeasurementsHistoryScreenBuilderInput {
    var deviceID: String
}

protocol LatestMeasurementsHistoryScreenCallback {
}

enum LatestMeasurementsHistoryScreenResult: Equatable {
    case partialState(_ value: LatestMeasurementsHistoryScreenPartialState)
    case effect(_ value: LatestMeasurementsHistoryScreenEffect)
}

enum LatestMeasurementsHistoryScreenPartialState: Equatable {
    case updateData(characteristics: [Measurement])
    func reduce(previousState: LatestMeasurementsHistoryScreenViewState) -> LatestMeasurementsHistoryScreenViewState {
        var state = previousState
        switch self {
        case .updateData(characteristics: let characteristics):
            state.measurementsArray = characteristics
        }
        return state
    }
}

protocol LatestMeasurementsHistoryScreenBuilder {
    func build(with input: LatestMeasurementsHistoryScreenBuilderInput) -> LatestMeasurementsHistoryScreenModule
}

struct LatestMeasurementsHistoryScreenModule {
    let view: LatestMeasurementsHistoryScreenView
    let callback: LatestMeasurementsHistoryScreenCallback
}

protocol LatestMeasurementsHistoryScreenView: BaseView {
    var intents: Observable<LatestMeasurementsHistoryScreenIntent> { get }
    func render(state: LatestMeasurementsHistoryScreenViewState)
}

protocol LatestMeasurementsHistoryScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: LatestMeasurementsHistoryScreenView, triggerEffect: PublishSubject<LatestMeasurementsHistoryScreenEffect>) -> Observable<LatestMeasurementsHistoryScreenViewState>
}

protocol LatestMeasurementsHistoryScreenInteractor: BaseInteractor {
    func fetchLatestMeasurements() -> Observable<LatestMeasurementsHistoryScreenResult>
}

protocol LatestMeasurementsHistoryScreenMiddleware {
    var middlewareObservable: Observable<LatestMeasurementsHistoryScreenResult> { get }
    func process(result: LatestMeasurementsHistoryScreenResult) -> Observable<LatestMeasurementsHistoryScreenResult>
}
