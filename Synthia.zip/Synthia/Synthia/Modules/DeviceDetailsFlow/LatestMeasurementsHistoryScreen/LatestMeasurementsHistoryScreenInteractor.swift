//
//  LatestMeasurementsHistoryScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 21/02/2023.
//

import RxSwift

final class LatestMeasurementsHistoryScreenInteractorImpl: LatestMeasurementsHistoryScreenInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = LatestMeasurementsHistoryScreenResult
    
    private let dependencies: Dependencies
    private let input: LatestMeasurementsHistoryScreenBuilderInput
    
    init(dependencies: Dependencies, input: LatestMeasurementsHistoryScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func fetchLatestMeasurements() -> RxSwift.Observable<LatestMeasurementsHistoryScreenResult> {
        return dependencies.measurementsPersistanceService.fetchLatestDeviceMeasurementsForEachType(id: input.deviceID)
            .map { measurements in
                return .partialState(.updateData(characteristics: measurements))
            }
            .asObservable()
    }
}
