//
//  MeasurementHistorySingleBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/02/2023.
//

import UIKit
import RxSwift

final class MeasurementHistorySingleBuilderImpl: MeasurementHistorySingleBuilder {
    typealias Dependencies = MeasurementHistorySingleInteractorImpl.Dependencies & MeasurementHistorySingleMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: MeasurementHistorySingleBuilderInput) -> MeasurementHistorySingleModule {
        let interactor = MeasurementHistorySingleInteractorImpl(dependencies: dependencies, input: input)
        let middleware = MeasurementHistorySingleMiddlewareImpl(dependencies: dependencies)
        let presenter = MeasurementHistorySinglePresenterImpl(interactor: interactor, middleware: middleware, initialViewState: MeasurementHistorySingleViewState(deviceID: input.deviceID, measurementName: input.measurementName, date: input.date))
        let view = MeasurementHistorySingleViewController(presenter: presenter)
        return MeasurementHistorySingleModule(view: view, callback: middleware)
    }
}
