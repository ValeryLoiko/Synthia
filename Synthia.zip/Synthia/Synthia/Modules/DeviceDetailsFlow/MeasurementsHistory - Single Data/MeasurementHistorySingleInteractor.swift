//
//  MeasurementHistorySingleInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/02/2023.
//

import RxSwift

final class MeasurementHistorySingleInteractorImpl: MeasurementHistorySingleInteractor {
    typealias Dependencies = HasMeasurementsPersistanceService
    typealias Result = MeasurementHistorySingleResult
    
    private let dependencies: Dependencies
    private let input: MeasurementHistorySingleBuilderInput

    init(dependencies: Dependencies, input: MeasurementHistorySingleBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    private var measurementsArray: [Measurement] = []
    
    func loadMeasurements() -> RxSwift.Observable<MeasurementHistorySingleResult> {
        dependencies.measurementsPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.measurementsPersistanceService.fetchMeasurementsByDateNameID(id: self.input.deviceID, name: self.input.measurementName, date: self.input.date)
                    .asObservable()
            }
            .map ({ measurements -> [Measurement] in
                measurements.map { measurement in
                    Measurement(deviceId: measurement.deviceId, name: measurement.name, value: measurement.value, unit: measurement.unit, measurementDate: measurement.measurementDate, measurementID: measurement.measurementID)
                }
            })
            .map({ savedMeasurements -> MeasurementHistorySingleResult in
                let sortedMeasurements = savedMeasurements.sorted { $0.measurementDate > $1.measurementDate }
                self.measurementsArray = sortedMeasurements
                return .partialState(.updateMeasurementsArray(measurements: sortedMeasurements))
            })
            .asObservable()
    }
    
    func deleteMeasurement(at row: Int) -> RxSwift.Observable<MeasurementHistorySingleResult> {
        dependencies.measurementsPersistanceService.deleteMeasurement(measurementID: measurementsArray[row].measurementID)
        return .just(.effect(.measurementDeleted))
    }
}
