//
//  MeasurementHistorySingleContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 23/02/2023.
//

import RxSwift
import Foundation

enum MeasurementHistorySingleIntent {
    case viewLoaded
    case deleteMeasurement(row: Int)
}

struct MeasurementHistorySingleViewState: Equatable {
    var deviceID: String
    var measurementName: MeasurementName
    var date: Date
    var measurements: [Measurement] = []
}

enum MeasurementHistorySingleEffect: Equatable {
    case measurementDeleted
}

struct MeasurementHistorySingleBuilderInput {
    var deviceID: String
    var measurementName: MeasurementName
    var date: Date
}

protocol MeasurementHistorySingleCallback {
}

enum MeasurementHistorySingleResult: Equatable {
    case partialState(_ value: MeasurementHistorySinglePartialState)
    case effect(_ value: MeasurementHistorySingleEffect)
}

enum MeasurementHistorySinglePartialState: Equatable {
    case updateMeasurementsArray(measurements: [Measurement])
    func reduce(previousState: MeasurementHistorySingleViewState) -> MeasurementHistorySingleViewState {
        var state = previousState
        switch self {
        case .updateMeasurementsArray(measurements: let measurements):
            state.measurements = measurements
        }
        return state
    }
}

protocol MeasurementHistorySingleBuilder {
    func build(with input: MeasurementHistorySingleBuilderInput) -> MeasurementHistorySingleModule
}

struct MeasurementHistorySingleModule {
    let view: MeasurementHistorySingleView
    let callback: MeasurementHistorySingleCallback
}

protocol MeasurementHistorySingleView: BaseView {
    var intents: Observable<MeasurementHistorySingleIntent> { get }
    func render(state: MeasurementHistorySingleViewState)
}

protocol MeasurementHistorySinglePresenter: AnyObject, BasePresenter {
    func bindIntents(view: MeasurementHistorySingleView, triggerEffect: PublishSubject<MeasurementHistorySingleEffect>) -> Observable<MeasurementHistorySingleViewState>
}

protocol MeasurementHistorySingleInteractor: BaseInteractor {
    func loadMeasurements() -> Observable<MeasurementHistorySingleResult>
    func deleteMeasurement(at row: Int) -> Observable<MeasurementHistorySingleResult>
}

protocol MeasurementHistorySingleMiddleware {
    var middlewareObservable: Observable<MeasurementHistorySingleResult> { get }
    func process(result: MeasurementHistorySingleResult) -> Observable<MeasurementHistorySingleResult>
}
