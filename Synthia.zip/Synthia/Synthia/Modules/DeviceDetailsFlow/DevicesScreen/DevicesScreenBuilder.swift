//
//  DevicesScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import UIKit
import RxSwift

final class DevicesScreenBuilderImpl: DevicesScreenBuilder {
    typealias Dependencies = DevicesScreenInteractorImpl.Dependencies & DevicesScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: DevicesScreenBuilderInput) -> DevicesScreenModule {
        let interactor = DevicesScreenInteractorImpl(dependencies: dependencies)
        let middleware = DevicesScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = DevicesScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: DevicesScreenViewState())
        let view = DevicesScreenViewController(presenter: presenter)
        return DevicesScreenModule(view: view, callback: middleware)
    }
}
