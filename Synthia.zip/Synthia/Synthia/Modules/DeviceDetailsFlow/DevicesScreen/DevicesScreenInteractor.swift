//
//  DevicesScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift
import Foundation

final class DevicesScreenInteractorImpl: DevicesScreenInteractor {
    typealias Dependencies = HasBLEService & HasDevicesPersistanceService
    typealias Result = DevicesScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    private var devices = [Device]()
    
    func loadDevices() -> RxSwift.Observable<DevicesScreenResult> {
        dependencies.devicesPersistanceService.dataHasChanged
            .map({ _ in })
            .startWith(())
            .flatMapLatest { _ in
                self.dependencies.devicesPersistanceService.fetchAllDevices()
                    .asObservable()
            }
            .map({ peripherals -> [Device] in
                peripherals.map { device in
                    Device(deviceID: device.deviceID, deviceName: device.deviceName, manufacturerName: device.manufacturerName, serialNumber: device.serialNumber, firmware: device.firmware, modelNumber: device.modelNumber, soleUser: device.soleUser)
                }
            })
            .map { savedDevices -> DevicesScreenResult in
                self.devices = savedDevices
                return .partialState(.updateDevicesArray(devices: savedDevices))
            }
            .asObservable()
    }
    
    func connectToDevice(deviceID: String) -> RxSwift.Observable<DevicesScreenResult> {
        // swiftlint:disable:next force_unwrapping
//        dependencies.bleService.autoReconnect(identifier: UUID(uuidString: deviceID)!)
        return Observable.empty()
    }
}
