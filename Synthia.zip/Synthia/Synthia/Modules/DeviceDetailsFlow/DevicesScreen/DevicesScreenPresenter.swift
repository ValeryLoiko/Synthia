//
//  DevicesScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift

final class DevicesScreenPresenterImpl: DevicesScreenPresenter {
    typealias View = DevicesScreenView
    typealias ViewState = DevicesScreenViewState
    typealias Middleware = DevicesScreenMiddleware
    typealias Interactor = DevicesScreenInteractor
    typealias Effect = DevicesScreenEffect
    typealias Result = DevicesScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .viewLoaded:
                return interactor.loadDevices()
            case .addNewDeviceButtonIntent:
                return .just(.effect(.showSearchingScreen))
            case .supportedDevicesButtonIntent:
                return .just(.effect(.showSupportedDevicesList))
            case .connectToDevice(deviceID: let deviceID):
                return interactor.connectToDevice(deviceID: deviceID)
            case .cellTapped(device: let device):
                return .just(.effect(.showDeviceDetailsScreen(device: device)))
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
