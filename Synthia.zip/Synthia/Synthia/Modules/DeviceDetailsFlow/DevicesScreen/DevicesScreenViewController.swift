//
//  DevicesScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class DevicesScreenViewController: BaseViewController, DevicesScreenView {
    typealias ViewState = DevicesScreenViewState
    typealias Effect = DevicesScreenEffect
    typealias Intent = DevicesScreenIntent
    typealias B = Localization.Buttons
    
    @IntentSubject() var intents: Observable<DevicesScreenIntent>
    
    private enum Constants {
        static let topSpacing = 116
        static let bottomSpacing = 40
        static let padding: CGFloat = 16
        static let collectionViewItemOffset: CGFloat = 16
        static let verticalItemOffset: CGFloat = 16
        static let cellHeight = 240
    }
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: DevicesScreenPresenter
    
    private var devicesSubject = PublishSubject<[Device]>()
    private let numberOfDevicesSubject = PublishSubject<Float>()
    
    private lazy var addNewDeviceButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightStringPlus, title: B.addNewDeviceButton)
        button.addTarget(self, action: #selector(addNewDevicePressed), for: .touchUpInside)
        let addDeviceButton = UIBarButtonItem(customView: button)
        return addDeviceButton
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = Constants.verticalItemOffset
        layout.itemSize = CGSize(width: Int(view.frame.width - (2 * Constants.padding) - Constants.collectionViewItemOffset) / 2, height: Constants.cellHeight)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(SavedDevicesCell.self, forCellWithReuseIdentifier: SavedDevicesCell.identifier)
        collectionView.backgroundColor = .clear
        return collectionView
    }()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.isScrollEnabled = true
        scrollView.showsVerticalScrollIndicator = false
        scrollView.backgroundColor = .clear
        return scrollView
    }()
    
    private lazy var contentView: UIStackView = {
        let contentView = UIStackView()
        contentView.axis = .vertical
        contentView.backgroundColor = .clear
        return contentView
    }()
    
    private lazy var supportedDevicesButton = Button(style: .transparentBlackFontColor, title: B.listOfSupportedDevicesButton)
    
    init(presenter: DevicesScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        self.navigationItem.rightBarButtonItem = addNewDeviceButton
        view.backgroundColor = .devicesScreenBackgroundColor
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        scrollView.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.left.equalToSuperview()
            $0.right.equalToSuperview()
            $0.bottom.equalToSuperview()
        }
    }
    
    private func bindControls() {
        // swiftlint:disable: unused_closure_parameter
        devicesSubject
            .bind(to: collectionView.rx.items(cellIdentifier: SavedDevicesCell.identifier, cellType: SavedDevicesCell.self)) { indexPath, item, cell in
                cell.configureCell(deviceName: item.deviceName ?? "", connectionStatus: "")
            }.disposed(by: bag)
        // swiftlint:enable unused_closure_parameter
        
        numberOfDevicesSubject.distinctUntilChanged()
            .subscribe(onNext: {
                self.calculateHeightOfCollectionView(numberOfRows: ceil($0 / 2))
            })
            .disposed(by: bag)
        
        supportedDevicesButton.rx.tap
        .map { Intent.supportedDevicesButtonIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
        
        collectionView.rx.modelSelected(Device.self)
            .subscribe { device in
                if let element = device.element {
                    self._intents.subject.onNext(.cellTapped(device: element))
                }
            }
            .disposed(by: bag)
    }
    
    @objc private func addNewDevicePressed() {
        _intents.subject.onNext(.addNewDeviceButtonIntent)
      }
    
    private func calculateHeightOfCollectionView(numberOfRows: Float) {
        var collectionViewHeight: CGFloat
        if numberOfRows != 0 {
             collectionViewHeight = CGFloat(numberOfRows) * CGFloat(Constants.cellHeight) + CGFloat(numberOfRows - 1) * CGFloat(Constants.verticalItemOffset)
        } else {
            collectionViewHeight = 0
        }
        let heightOfLabel = 24
        
        contentView.snp.removeConstraints()
        contentView.snp.makeConstraints {
            $0.top.equalToSuperview().inset(Constants.padding)
            $0.left.equalToSuperview().inset(Constants.padding)
            $0.right.equalToSuperview().inset(Constants.padding)
            $0.bottom.equalToSuperview()
            $0.width.equalToSuperview().inset(Constants.padding)
            $0.height.equalTo(Int(collectionViewHeight) + 2 * Constants.bottomSpacing + heightOfLabel)
        }

        contentView.addSubview(collectionView)
        collectionView.snp.removeConstraints()
        collectionView.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.left.equalToSuperview()
            $0.right.equalToSuperview()
            if collectionViewHeight > 0 {
                $0.height.equalTo(collectionViewHeight)
            } else {
                $0.height.equalToSuperview()
            }
        }

        contentView.addSubview(supportedDevicesButton)
        supportedDevicesButton.snp.removeConstraints()
        if numberOfRows == 0 {
            supportedDevicesButton.snp.makeConstraints {
                $0.top.equalToSuperview()
                $0.left.equalToSuperview()
                $0.right.equalToSuperview()
                $0.height.equalTo(heightOfLabel)
            }
        } else {
            supportedDevicesButton.snp.makeConstraints {
                $0.top.equalTo(collectionView.snp.bottom).offset(40)
                $0.left.equalToSuperview()
                $0.right.equalToSuperview()
                $0.height.equalTo(heightOfLabel)
            }
        }
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .showSearchingScreen:
            break
        case .showSupportedDevicesList:
            break
        case .showDeviceDetailsScreen(device: _):
            break
        }
    }
    
    func render(state: ViewState) {
        devicesSubject.onNext(state.savedDevicesArray)
        numberOfDevicesSubject.onNext(Float(state.savedDevicesArray.count))
    }
}
