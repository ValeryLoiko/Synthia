//
//  DevicesScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 11/01/2023.
//

import RxSwift

enum DevicesScreenIntent {
    case viewLoaded
    case addNewDeviceButtonIntent
    case supportedDevicesButtonIntent
    case cellTapped(device: Device)
    case connectToDevice(deviceID: String)
}

struct DevicesScreenViewState: Equatable {
    var savedDevicesArray: [Device] = []
}

enum DevicesScreenEffect: Equatable {
    case showSearchingScreen
    case showSupportedDevicesList
    case showDeviceDetailsScreen(device: Device)
}

struct DevicesScreenBuilderInput {
}

protocol DevicesScreenCallback {
}

enum DevicesScreenResult: Equatable {
    case partialState(_ value: DevicesScreenPartialState)
    case effect(_ value: DevicesScreenEffect)
}

enum DevicesScreenPartialState: Equatable {
    case updateDevicesArray(devices: [Device])
    
    func reduce(previousState: DevicesScreenViewState) -> DevicesScreenViewState {
        var state = previousState
        switch self {
        case .updateDevicesArray(devices: let devices):
            state.savedDevicesArray = devices
        }
        return state
    }
}

protocol DevicesScreenBuilder {
    func build(with input: DevicesScreenBuilderInput) -> DevicesScreenModule
}

struct DevicesScreenModule {
    let view: DevicesScreenView
    let callback: DevicesScreenCallback
}

protocol DevicesScreenView: BaseView {
    var intents: Observable<DevicesScreenIntent> { get }
    func render(state: DevicesScreenViewState)
}

protocol DevicesScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: DevicesScreenView, triggerEffect: PublishSubject<DevicesScreenEffect>) -> Observable<DevicesScreenViewState>
}

protocol DevicesScreenInteractor: BaseInteractor {
    func loadDevices() -> Observable<DevicesScreenResult>
    func connectToDevice(deviceID: String) -> Observable<DevicesScreenResult>
}

protocol DevicesScreenMiddleware {
    var middlewareObservable: Observable<DevicesScreenResult> { get }
    func process(result: DevicesScreenResult) -> Observable<DevicesScreenResult>
}
