//
//  SupportedDevicesScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 03/03/2023.
//

import RxSwift

final class SupportedDevicesScreenInteractorImpl: SupportedDevicesScreenInteractor {
    typealias Dependencies = Any
    typealias Result = SupportedDevicesScreenResult
    
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    var supportedDevices: [SupportedDevice] = [
        SupportedDevice(type: .bodyComposition, name: "Mi Body Composition Scale 2", producer: "Xiaomi"),
        SupportedDevice(type: .bodyComposition, name: "Mi Body Composition Scale 3", producer: "Xiaomi"),
        SupportedDevice(type: .bodyComposition, name: "Mi Body Composition Scale 4", producer: "Xiaomi"),
        SupportedDevice(type: .scale, name: "Mi Body Composition Scale 2", producer: "Xiaomi"),
        SupportedDevice(type: .pressure, name: "Mi Body Composition Scale 2", producer: "Xiaomi"),
        SupportedDevice(type: .pressure, name: "Omron Connect", producer: "Omron"),
        SupportedDevice(type: .thermometer, name: "FT 95", producer: "Beurer"),
        SupportedDevice(type: .pressure, name: "M7 Intelli", producer: "Omron")
    ]
    
    var data = [String]()
    
    func loadData() -> Observable<SupportedDevicesScreenResult> {
        return .just(.partialState(.updateDevicesList(supportedDevices: supportedDevices)))
    }
    
    func queryList(userInput: String?) -> RxSwift.Observable<SupportedDevicesScreenResult> {
        return Observable<[SupportedDevice]>.just(supportedDevices)
            .map({ devices in
                guard let userInput else { return .partialState(.updateDevicesList(supportedDevices: self.supportedDevices))}
                let filteredDevices = devices.filter { $0.name.contains(userInput) }
                return .partialState(.updateDevicesList(supportedDevices: filteredDevices))
            })
    }
}
