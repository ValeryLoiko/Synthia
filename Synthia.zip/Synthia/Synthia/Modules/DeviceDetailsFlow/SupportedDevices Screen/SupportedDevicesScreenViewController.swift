//
//  SupportedDevicesScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 03/03/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class SupportedDevicesScreenViewController: BaseViewController, SupportedDevicesScreenView {
    typealias ViewState = SupportedDevicesScreenViewState
    typealias Effect = SupportedDevicesScreenEffect
    typealias Intent = SupportedDevicesScreenIntent
    typealias S = Localization.SupportedDevices
    
    @IntentSubject() var intents: Observable<SupportedDevicesScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: SupportedDevicesScreenPresenter
    
    private var dataSource = [DeviceType: [SupportedDevice]]()
    private var sectionTitles = [Dictionary<DeviceType, [SupportedDevice]>.Keys.Element]()
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        let closeButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: nil)
        return closeButton
    }()
    
    private lazy var queryTextField: UITextField = {
        let imageView = UIImageView()
        imageView.image = UIImage.assetImageName(AssetsCatalog.General.searchingIcon)
        imageView.contentMode = .scaleAspectFit
        let textField = UITextField()
        textField.backgroundColor = .textfieldBackgroundColor
        textField.leftViewMode = .always
        textField.leftView = imageView
        textField.layer.cornerRadius = 10
        textField.placeholder = S.placeholder
        return textField
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .singleLine
        tableView.rowHeight = 78
        tableView.register(SupportedDevicesCell.self, forCellReuseIdentifier: SupportedDevicesCell.identifier)
        return tableView
    }()
    
    init(presenter: SupportedDevicesScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        title = S.title
        self.navigationItem.rightBarButtonItem = closeButton
        view.addSubview(queryTextField)
        view.addSubview(tableView)
        queryTextField.snp.makeConstraints {
            $0.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).inset(16)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(36)
        }
        
        tableView.snp.makeConstraints {
            $0.top.equalTo(queryTextField.snp.bottom).offset(40)
            $0.left.right.bottom.equalToSuperview()
        }
    }
    
    private func bindControls() {
        closeButton.rx.tap
            .map { Intent.closeButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        queryTextField.rx.text
            .debounce(.milliseconds(500), scheduler: MainScheduler.instance)
            .subscribe(onNext: { text in
                guard let text else { return }
                if !text.isEmpty {
                    self._intents.subject.onNext(.queryList(inputText: text))
                } else {
                    self._intents.subject.onNext(.viewLoaded)
                }
            })
            .disposed(by: bag)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .dismissScreen:
            break
        }
    }
    
    func render(state: ViewState) {
        dataSource = Dictionary(grouping: state.supportedDevices, by: { $0.type })
        sectionTitles = Array(dataSource.keys)
        tableView.reloadData()
    }
}

extension SupportedDevicesScreenViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        sectionTitles.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        sectionTitles[section].rawValue
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        24
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let deviceType = sectionTitles[section]
        //            swiftlint:disable:next force_unwrapping
        return dataSource[deviceType]!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SupportedDevicesCell.identifier, for: indexPath) as? SupportedDevicesCell else {
                 return UITableViewCell()
             }
        let deviceType = sectionTitles[indexPath.section]
        //            swiftlint:disable:next force_unwrapping
        let supportedDevice = dataSource[deviceType]![indexPath.row]
        cell.configureCell(deviceName: supportedDevice.name, producerName: supportedDevice.producer)
        return cell
    }
}
