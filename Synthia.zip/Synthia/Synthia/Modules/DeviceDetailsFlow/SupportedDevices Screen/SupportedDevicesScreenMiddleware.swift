//
//  SupportedDevicesScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 03/03/2023.
//

import RxSwift

final class SupportedDevicesScreenMiddlewareImpl: SupportedDevicesScreenMiddleware, SupportedDevicesScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = SupportedDevicesScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .dismissScreen:
                dependencies.appNavigation?.dismiss()
            }
        }
        return .just(result)
    }
}
