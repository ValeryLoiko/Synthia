//
//  SupportedDevicesScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 03/03/2023.
//

import UIKit
import RxSwift

final class SupportedDevicesScreenBuilderImpl: SupportedDevicesScreenBuilder {
    typealias Dependencies = SupportedDevicesScreenInteractorImpl.Dependencies & SupportedDevicesScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: SupportedDevicesScreenBuilderInput) -> SupportedDevicesScreenModule {
        let interactor = SupportedDevicesScreenInteractorImpl(dependencies: dependencies)
        let middleware = SupportedDevicesScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = SupportedDevicesScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: SupportedDevicesScreenViewState())
        let view = SupportedDevicesScreenViewController(presenter: presenter)
        return SupportedDevicesScreenModule(view: view, callback: middleware)
    }
}
