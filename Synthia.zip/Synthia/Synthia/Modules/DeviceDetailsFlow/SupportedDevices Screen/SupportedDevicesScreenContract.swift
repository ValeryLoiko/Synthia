//
//  SupportedDevicesScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 03/03/2023.
//

import RxSwift
typealias S = Localization.SupportedDevices

enum DeviceType: String {
    case thermometer = "Thermometers"
    case scale = "Scale"
    case pressure = "Pressure sensors"
    case bodyComposition = "Body composition"
}

struct SupportedDevice: Equatable {
    let type: DeviceType
    let name: String
    let producer: String
}

enum SupportedDevicesScreenIntent {
    case queryList(inputText: String?)
    case viewLoaded
    case closeButtonIntent
}

struct SupportedDevicesScreenViewState: Equatable {
    var supportedDevices = [SupportedDevice]()
}

enum SupportedDevicesScreenEffect: Equatable {
    case dismissScreen
}

struct SupportedDevicesScreenBuilderInput {
}

protocol SupportedDevicesScreenCallback {
}

enum SupportedDevicesScreenResult: Equatable {
    case partialState(_ value: SupportedDevicesScreenPartialState)
    case effect(_ value: SupportedDevicesScreenEffect)
}

enum SupportedDevicesScreenPartialState: Equatable {
    case updateDevicesList(supportedDevices: [SupportedDevice])
    func reduce(previousState: SupportedDevicesScreenViewState) -> SupportedDevicesScreenViewState {
        var state = previousState
        switch self {
        case .updateDevicesList(supportedDevices: let supportedDevices):
            state.supportedDevices = supportedDevices
        }
        return state
    }
}

protocol SupportedDevicesScreenBuilder {
    func build(with input: SupportedDevicesScreenBuilderInput) -> SupportedDevicesScreenModule
}

struct SupportedDevicesScreenModule {
    let view: SupportedDevicesScreenView
    let callback: SupportedDevicesScreenCallback
}

protocol SupportedDevicesScreenView: BaseView {
    var intents: Observable<SupportedDevicesScreenIntent> { get }
    func render(state: SupportedDevicesScreenViewState)
}

protocol SupportedDevicesScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: SupportedDevicesScreenView, triggerEffect: PublishSubject<SupportedDevicesScreenEffect>) -> Observable<SupportedDevicesScreenViewState>
}

protocol SupportedDevicesScreenInteractor: BaseInteractor {
    func loadData() -> Observable<SupportedDevicesScreenResult>
    func queryList(userInput: String?) -> Observable<SupportedDevicesScreenResult>
}

protocol SupportedDevicesScreenMiddleware {
    var middlewareObservable: Observable<SupportedDevicesScreenResult> { get }
    func process(result: SupportedDevicesScreenResult) -> Observable<SupportedDevicesScreenResult>
}
