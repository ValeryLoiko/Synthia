//
//  SearchingScreenPresenter.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import RxSwift

final class SearchingScreenPresenterImpl: SearchingScreenPresenter {
    typealias View = SearchingScreenView
    typealias ViewState = SearchingScreenViewState
    typealias Middleware = SearchingScreenMiddleware
    typealias Interactor = SearchingScreenInteractor
    typealias Effect = SearchingScreenEffect
    typealias Result = SearchingScreenResult
    
    private let interactor: Interactor
    private let middleware: Middleware
    
    private let initialViewState: ViewState
    
    init(interactor: Interactor, middleware: Middleware, initialViewState: ViewState) {
        self.interactor = interactor
        self.middleware = middleware
        self.initialViewState = initialViewState
    }
    
    func bindIntents(view: View, triggerEffect: PublishSubject<Effect>) -> Observable<ViewState> {
        let intentResults = view.intents.flatMap { [unowned self] intent -> Observable<Result> in
            switch intent {
            case .viewLoaded:
                return interactor.turnOnCentralManager()
            case .closeButtonIntent:
                return .just(.effect(.dismissScreen))
            case .checkScanningStateIntent:
                return interactor.checkScanning()
            case .stopScanningIntent:
                return interactor.stopScanning()
            case .disconnectChosenDeviceIntent(peripheral: let peripheral):
                return interactor.disconnectFromDevice(peripheral: peripheral)
            case .cellTapped(peripheral: let peripheral):
                return .just(.effect(.showPairingAlert(peripheral: peripheral)))
            case .troublesButtonIntent:
                return .just(.effect(.troubleButtonPressed))
            case .seeSupportedDevicesIntent:
                return .just(.effect(.showListOfSupportedDevices))
            case .askForNumberOfUsers(peripheral: let peripheral):
                return .just(.effect(.showNumberOfUsersAlert(peripheral: peripheral)))
            case .connectToChosenDeviceIntent(peripheral: let peripheral, isOnlyUser: let isOnlyUser):
                return interactor.connectToDevice(peripheral: peripheral, isOnlyUser: isOnlyUser)
            case .addNewDeviceIntent(peripheral: let peripheral, isOnlyUser: let isOnlyUser):
                return .merge(
                    interactor.addNewDevice(device: peripheral, isOnlyUser: isOnlyUser),
                    .just(.effect(.dismiss))
                )
            }
        }
        return Observable.merge(middleware.middlewareObservable, intentResults)
            .flatMap { self.middleware.process(result: $0) }
            .scan(initialViewState, accumulator: { (previousState, result) -> ViewState in
                switch result {
                case .partialState(let partialState):
                    return partialState.reduce(previousState: previousState)
                case .effect(let effect):
                    triggerEffect.onNext(effect)
                    return previousState
                }
            })
            .startWith(initialViewState)
            .distinctUntilChanged()
    }
}
