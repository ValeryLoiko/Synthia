//
//  SearchingScreenContract.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import RxSwift
import CoreBluetooth

enum SearchingScreenIntent {
    case viewLoaded
    case checkScanningStateIntent
    case closeButtonIntent
    case cellTapped(peripheral: CBPeripheral)
    case askForNumberOfUsers(peripheral: CBPeripheral)
    case connectToChosenDeviceIntent(peripheral: CBPeripheral, isOnlyUser: Bool)
    case addNewDeviceIntent(peripheral: CBPeripheral, isOnlyUser: Bool)
    case stopScanningIntent
    case disconnectChosenDeviceIntent(peripheral: CBPeripheral)
    case troublesButtonIntent
    case seeSupportedDevicesIntent
}

struct SearchingScreenViewState: Equatable {
    var discoveredPeripherals: [CBPeripheral] = []
    var connectedPeripherals: [CBPeripheral] = []
    var isScanning = false
    var addedDevice = Device(deviceID: "", deviceName: "", soleUser: true)
}

enum SearchingScreenEffect: Equatable {
    case showTableView
    case showTips
    case dismissScreen
    case showPairingAlert(peripheral: CBPeripheral)
    case showNumberOfUsersAlert(peripheral: CBPeripheral)
    case deviceConnected
    case deviceAdded
    case troubleButtonPressed
    case showListOfSupportedDevices
    case dismiss
}

struct SearchingScreenBuilderInput {
}

protocol SearchingScreenCallback { 
}

enum SearchingScreenResult: Equatable {
    case partialState(_ value: SearchingScreenPartialState)
    case effect(_ value: SearchingScreenEffect)
}

enum SearchingScreenPartialState: Equatable {
    case updateFoundPeripheralsList(devices: [CBPeripheral])
    case updateConnectedPeripheralsList(devices: [CBPeripheral])
    case isScanningPeripherals(isScanning: Bool)
    case deviceAdded(device: Device)
    
    func reduce(previousState: SearchingScreenViewState) -> SearchingScreenViewState {
        var state = previousState
        switch self {
        case .updateFoundPeripheralsList(devices: let devices):
            state.discoveredPeripherals = devices
        case .isScanningPeripherals(isScanning: let isScanning):
            state.isScanning = isScanning
        case .updateConnectedPeripheralsList(devices: let devices):
            state.connectedPeripherals = devices
        case .deviceAdded(device: let device):
            state.addedDevice = device
        }
        return state
    }
}

protocol SearchingScreenBuilder {
    func build(with input: SearchingScreenBuilderInput) -> SearchingScreenModule
}

struct SearchingScreenModule {
    let view: SearchingScreenView
    let callback: SearchingScreenCallback
}

protocol SearchingScreenView: BaseView {
    var intents: Observable<SearchingScreenIntent> { get }
    func render(state: SearchingScreenViewState)
}

protocol SearchingScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: SearchingScreenView, triggerEffect: PublishSubject<SearchingScreenEffect>) -> Observable<SearchingScreenViewState>
}

protocol SearchingScreenInteractor: BaseInteractor {
    func turnOnCentralManager() -> Observable<SearchingScreenResult>
    func checkScanning() -> RxSwift.Observable<SearchingScreenResult>
    func connectToDevice(peripheral: CBPeripheral, isOnlyUser: Bool) -> Observable<SearchingScreenResult>
    func addNewDevice(device: CBPeripheral, isOnlyUser: Bool) -> RxSwift.Observable<SearchingScreenResult>
    func disconnectFromDevice(peripheral: CBPeripheral) -> Observable<SearchingScreenResult>
    func stopScanning() -> Observable<SearchingScreenResult>
}

protocol SearchingScreenMiddleware {
    var middlewareObservable: Observable<SearchingScreenResult> { get }
    func process(result: SearchingScreenResult) -> Observable<SearchingScreenResult>
}
