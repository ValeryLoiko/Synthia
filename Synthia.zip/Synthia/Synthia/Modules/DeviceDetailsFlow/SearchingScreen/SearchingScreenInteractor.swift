//
//  SearchingScreenInteractor.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import RxSwift
import CoreBluetooth

final class SearchingScreenInteractorImpl: SearchingScreenInteractor {
    typealias Dependencies = HasBLEService & HasDevicesPersistanceService
    typealias Result = SearchingScreenResult
    
    private let dependencies: Dependencies
    private let bag = DisposeBag()
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    private var discoveredPeripherals = [CBPeripheral]()
    
    func turnOnCentralManager() -> RxSwift.Observable<SearchingScreenResult> {
        dependencies.bleService.startScanning()
        return dependencies.bleService.discoveredPeripheralObservable.map { discoveredDevice in
            if !self.discoveredPeripherals.contains(discoveredDevice) {
                self.discoveredPeripherals.append(discoveredDevice)
            }
            return (.partialState(.updateFoundPeripheralsList(devices: self.discoveredPeripherals)))
        }
    }
    
    func checkScanning() -> RxSwift.Observable<SearchingScreenResult> {
        dependencies.bleService.isScanningObservable
            .map { bool in
                return .partialState(.isScanningPeripherals(isScanning: bool))
            }
    }
    
    func stopScanning() -> RxSwift.Observable<SearchingScreenResult> {
        dependencies.bleService.stopScanning()
        return dependencies.bleService.isScanningObservable
            .map { bool in
                return .partialState(.isScanningPeripherals(isScanning: bool))
            }
    }
    
    func connectToDevice(peripheral: CBPeripheral, isOnlyUser: Bool) -> RxSwift.Observable<SearchingScreenResult> {
        dependencies.bleService.connect(peripheral: peripheral)
        return .just(.effect(.deviceConnected))
    }
    
    func addNewDevice(device: CBPeripheral, isOnlyUser: Bool) -> RxSwift.Observable<SearchingScreenResult> {
        let manufacturerNameObservable = dependencies.bleService.manufacturerNameObservable
        let serialNumberObservable = dependencies.bleService.serialNumberObservable
        let modelNumberObservable = dependencies.bleService.modelNumberObservable
        let firmwareObservable = dependencies.bleService.firmwareObservable
        
        return Observable.combineLatest(manufacturerNameObservable,
                                        serialNumberObservable,
                                        modelNumberObservable,
                                        firmwareObservable)
        .take(1)
        .map { (manufacturerName, serialNumber, modelNumber, firmware) -> Device in
            return Device(deviceID: device.identifier.uuidString, deviceName: device.name, manufacturerName: manufacturerName, serialNumber: serialNumber, firmware: firmware, modelNumber: modelNumber, soleUser: isOnlyUser)
        }
        .map { device -> SearchingScreenResult in
            self.dependencies.devicesPersistanceService.addDeviceIfNew(device: device)
            return .partialState(.deviceAdded(device: device))
        }
    }
    
    func disconnectFromDevice(peripheral: CBPeripheral) -> RxSwift.Observable<SearchingScreenResult> {
        dependencies.bleService.disconnect(peripheral: peripheral)
        return dependencies.bleService.connectedPeripheralObservable
            .map { connectedPeripherals in
                return .partialState(.updateConnectedPeripheralsList(devices: connectedPeripherals))
            }
    }
}
