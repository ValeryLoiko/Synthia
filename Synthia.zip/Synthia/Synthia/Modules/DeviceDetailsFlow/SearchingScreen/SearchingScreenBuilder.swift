//
//  SearchingScreenBuilder.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import UIKit
import RxSwift

final class SearchingScreenBuilderImpl: SearchingScreenBuilder {
    typealias Dependencies = SearchingScreenInteractorImpl.Dependencies & SearchingScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: SearchingScreenBuilderInput) -> SearchingScreenModule {
        let interactor = SearchingScreenInteractorImpl(dependencies: dependencies)
        let middleware = SearchingScreenMiddlewareImpl(dependencies: dependencies)
        let presenter = SearchingScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: SearchingScreenViewState())
        let view = SearchingScreenViewController(presenter: presenter)
        return SearchingScreenModule(view: view, callback: middleware)
    }
}
