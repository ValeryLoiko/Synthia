//
//  SearchingScreenViewController.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit
import CoreBluetooth

final class SearchingScreenViewController: BaseViewController, SearchingScreenView {
    typealias ViewState = SearchingScreenViewState
    typealias Effect = SearchingScreenEffect
    typealias Intent = SearchingScreenIntent
    typealias A = AssetsCatalog
    typealias L = Localization
    
    @IntentSubject() var intents: Observable<SearchingScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: SearchingScreenPresenter
    
    private var devicesSubject = PublishSubject<[CBPeripheral]>()
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        button.addTarget(self, action: #selector(closeView), for: .touchUpInside)
        let closeButton = UIBarButtonItem(customView: button)
        return closeButton
    }()
    
    private lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        let text = L.SearchingScreen.subtitleLabel
        label.text = text
        label.font = UIFont.OpenSansRegular14
        let boldString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: L.SearchingScreen.subtitleLabelTap)
        boldString.addAttribute(NSAttributedString.Key.font, value: UIFont.OpenSansSemiBold14 ?? UIFont(), range: range1)
        boldString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.black, range: range1)
        label.attributedText = boldString
        label.isUserInteractionEnabled = true
        label.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapLabel(gesture:))))
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private var tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.rowHeight = 72
        tableView.register(DiscoveredPeripheralCell.self, forCellReuseIdentifier: DiscoveredPeripheralCell.identifier)
        return tableView
    }()
    
    private lazy var searchingImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage.assetImageName(A.AddDevice.searchingDeviceBackground)
        image.contentMode = .scaleAspectFit
        image.tintColor = .blackColor
        return image
    }()
    
    private lazy var timeLimitTitle: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = UIColor.blackColor
        label.text = L.SearchingScreen.timeLimitTitle
        label.textAlignment = .center
        label.font = UIFont.OpenSansSemiBold14
        return label
    }()
    
    private lazy var timeLimitSubtitle: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = UIColor.blackColor
        label.text = L.SearchingScreen.timeLimitSubtitle
        label.textAlignment = .center
        label.font = UIFont.OpenSansRegular14
        return label
    }()
    
    private lazy var troublesButton = Button(style: .normal, title: L.SearchingScreen.troublesButton)
    
    init(presenter: SearchingScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
        self._intents.subject.onNext(.checkScanningStateIntent)
    }
    
    private func layoutView() {
        navigationController?.navigationBar.isHidden = false
        self.navigationItem.rightBarButtonItem = closeButton
        self.title = L.SearchingScreen.title
        
        view.addSubview(subtitleLabel)
        view.addSubview(tableView)
        view.addSubview(searchingImage)
        view.addSubview(timeLimitTitle)
        view.addSubview(timeLimitSubtitle)
        view.addSubview(troublesButton)
        
        subtitleLabel.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(32)
            $0.top.equalToSuperview().inset(64)
            $0.height.equalTo(48)
        }
        
        tableView.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.top.equalTo(subtitleLabel.snp.bottom).offset(24)
            $0.bottom.equalToSuperview().inset(150)
        }
        
        troublesButton.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalToSuperview().inset(50)
        }
        
        timeLimitSubtitle.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.bottom.equalTo(troublesButton.snp.top).offset(-40)
            $0.height.equalTo(16)
        }
        
        timeLimitTitle.snp.makeConstraints {
            $0.left.right.equalToSuperview().inset(16)
            $0.bottom.equalTo(timeLimitSubtitle.snp.top).offset(-16)
            $0.height.equalTo(16)
        }
        
        searchingImage.snp.makeConstraints {
            $0.leading.trailing.equalToSuperview().inset(67)
            $0.top.equalTo(subtitleLabel.snp.bottom).offset(40)
            $0.bottom.equalTo(timeLimitTitle.snp.top).offset(-80)
        }
    }
    
    private func bindControls() {
        devicesSubject.bind(to: tableView.rx.items(cellIdentifier: DiscoveredPeripheralCell.identifier, cellType: DiscoveredPeripheralCell.self)) { _, item, cell in
            if let name = item.name {
                cell.configureCell(deviceName: "\(name)", deviceModel: "\(item.identifier)")
            }
        }
        .disposed(by: bag)
        
        tableView.rx.modelSelected(CBPeripheral.self)
            .subscribe(
                onNext: { model in
                    self._intents.subject.onNext(.stopScanningIntent)
                    self._intents.subject.onNext(.cellTapped(peripheral: model))
                })
            .disposed(by: bag)
        
        tableView.rx.modelDeleted(CBPeripheral.self)
            .subscribe(
            onNext: { model in
                self._intents.subject.onNext(.disconnectChosenDeviceIntent(peripheral: model))
            })
            .disposed(by: bag)
        
        troublesButton.rx.tap
            .map { Intent.troublesButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
    }
    
    @objc private func tapLabel(gesture: UITapGestureRecognizer) {
        let text = L.SearchingScreen.subtitleLabel
        let tapRange = (text as NSString).range(of: L.SearchingScreen.subtitleLabelTap)
        if gesture.didTapAttributedTextInLabel(label: subtitleLabel, inRange: tapRange) {
            self._intents.subject.onNext(.seeSupportedDevicesIntent)
        }
    }
    
    @objc private func closeView() {
        _intents.subject.onNext(.closeButtonIntent)
    }
    
    private func trigger(effect: Effect) {
        switch effect {
        case .dismissScreen:
            break
        case .showTableView:
            tableView.isHidden = false
            searchingImage.isHidden = true
            timeLimitTitle.isHidden = true
            timeLimitSubtitle.isHidden = true
            troublesButton.isHidden = true
        case .showTips:
            tableView.isHidden = true
            searchingImage.isHidden = false
            timeLimitTitle.isHidden = false
            timeLimitSubtitle.isHidden = false
            troublesButton.isHidden = false
        case .showPairingAlert(peripheral: let peripheral):
            chooseAlert(type: .twoBtnsAlert(title: L.Alerts.areYouSurePair, message: L.Alerts.areYouSurePair, rightBtnTitle: L.Alerts.pair, rightBtnStyle: .default, rightBtnAction: { _ in
                self._intents.subject.onNext(.askForNumberOfUsers(peripheral: peripheral))
            }))
        case .showNumberOfUsersAlert(peripheral: let peripheral):
            chooseAlert(type: .twoBtnActionSheet(title: L.Alerts.numberOfUsersTitle, message: L.Alerts.numberOfUsersMessage, upBtnTitle: L.Alerts.onlyUser, downBtnTitle: L.Alerts.multipleUsers, upBtnAction: { _ in
                self._intents.subject.onNext(.connectToChosenDeviceIntent(peripheral: peripheral, isOnlyUser: true))
                self._intents.subject.onNext(.addNewDeviceIntent(peripheral: peripheral, isOnlyUser: true))
            }, downBtnAction: { _ in
                self._intents.subject.onNext(.connectToChosenDeviceIntent(peripheral: peripheral, isOnlyUser: false))
                self._intents.subject.onNext(.addNewDeviceIntent(peripheral: peripheral, isOnlyUser: false))
            }))
        case .deviceAdded:
            break
        case .troubleButtonPressed:
            break
        case .showListOfSupportedDevices:
            break
        case .deviceConnected:
            break
        case .dismiss:
            break
        }
    }
    
    func render(state: ViewState) {
        devicesSubject.onNext(state.discoveredPeripherals)
        if state.discoveredPeripherals.isEmpty {
            self.effectsSubject.onNext(.showTips)
        } else {
            self.effectsSubject.onNext(.showTableView)
        }
    }
    // swiftlint:disable:next file_length
}
