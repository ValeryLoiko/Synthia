//
//  SearchingScreenMiddleware.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 24/01/2023.
//

import RxSwift

final class SearchingScreenMiddlewareImpl: SearchingScreenMiddleware, SearchingScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = SearchingScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .dismissScreen:
                dependencies.appNavigation?.dismiss()
            case .showTableView:
                break
            case .showTips:
                break
            case .showPairingAlert(peripheral: _):
                break
            case .showNumberOfUsersAlert(peripheral: _):
                break
            case .deviceAdded:
                break
            case .troubleButtonPressed:
                break
            case .showListOfSupportedDevices:
                dependencies.appNavigation?.showListOfSupportedDevices()
            case .deviceConnected:
                break
            case .dismiss:
                dependencies.appNavigation?.dismiss()
            }
        }
        return .just(result)
    }
}
