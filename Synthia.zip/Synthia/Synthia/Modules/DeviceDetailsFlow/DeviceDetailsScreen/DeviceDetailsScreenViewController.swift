//
//  DeviceDetailsScreenViewController.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import UIKit
import RxSwift
import RxCocoa
import SnapKit

final class DeviceDetailsScreenViewController: BaseViewController, DeviceDetailsScreenView {
    typealias ViewState = DeviceDetailsScreenViewState
    typealias Effect = DeviceDetailsScreenEffect
    typealias Intent = DeviceDetailsScreenIntent
    typealias D = Localization.DeviceDetailsScreen
    
    @IntentSubject() var intents: Observable<DeviceDetailsScreenIntent>
    
    private let effectsSubject = PublishSubject<Effect>()
    private let bag = DisposeBag()
    private let presenter: DeviceDetailsScreenPresenter
    
    private var isConnectedSubject = PublishSubject<Bool>()
    private let isSwitchOnSubject = PublishSubject<Bool>()
    private let tapGesture = UITapGestureRecognizer()
    
    private lazy var closeButton: UIBarButtonItem = {
        let button: UIButton = Button(style: ButtonStyle.rightXmarkBlack, title: "")
        let closeButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: nil)
        return closeButton
    }()
    
    private lazy var scrollView = UIScrollView()
    private lazy var mainView = UIView()
    
    let imageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "WelcomeScreenImage"))
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    let imageView2: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "WelcomeScreenImage"))
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var  isConnectedLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.OpenSansRegular14
//        label.text = D.deviceConnected
        return label
    }()
    
    private lazy var tryToConnectButton: UIButton = {
        let button = UIButton()
        button.setTitle(D.tryConnect, for: .normal)
        button.titleLabel?.font = UIFont.OpenSansSemiBold16
        button.setTitleColor(UIColor.blackColor, for: .normal)
        return button
    }()
    
    private lazy var disconnectButton: UIButton = {
        let button = UIButton()
        button.setTitle(D.disconnect, for: .normal)
        button.titleLabel?.font = UIFont.OpenSansSemiBold16
        button.setTitleColor(UIColor.blackColor, for: .normal)
        return button
    }()
    
    private lazy var  batteryView: UIView = {
        let view = BatteryView()
        view.setBatteryLevel(level: 37)
        return view
    }()
    
    private lazy var measurementsHistoryButton = Button.measurementsHistoryButton()
    
    private lazy var detailsLabel: UILabel = {
        let label = UILabel()
        label.text = D.detailsLabel
        label.font = UIFont.OpenSansSemiBold16
        label.textColor = UIColor.black
        return label
    }()
    
    private lazy var deviceNameField: UITextField = {
        let textField = UITextField()
        textField.textContentType = .nickname
        textField.keyboardType = .default
        textField.returnKeyType = .done
        textField.isSecureTextEntry = false
        textField.layer.borderWidth = 1
        textField.layer.cornerRadius = 8
        textField.layer.borderColor = UIColor.blackColor?.withAlphaComponent(0.4).cgColor
        textField.placeholder = D.deviceNamePlaceholder
        textField.setLeftPaddingPoints(12)
        return textField
    }()
    
    private lazy var multipleUsersView = MultipleUsersView()
    
    private lazy var deviceInfoView = DeviceInfoView()
    
    private lazy var removeDeviceButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 8.0
        button.clipsToBounds = true
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.black.cgColor
        button.setTitle("Remove Device", for: .normal)
        button.setTitleColor(UIColor.blackColor, for: .normal)
        button.titleLabel?.font = UIFont.OpenSansSemiBold16
        return button
    }()
    
    init(presenter: DeviceDetailsScreenPresenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutView()
        bindControls()
        effectsSubject.subscribe(onNext: { [weak self] effect in self?.trigger(effect: effect) })
            .disposed(by: bag)
        presenter.bindIntents(view: self, triggerEffect: effectsSubject)
            .subscribe(onNext: { [weak self] state in self?.render(state: state) })
            .disposed(by: bag)
        self._intents.subject.onNext(.viewLoaded)
    }
    
    private func layoutView() {
        title = D.title
        navigationItem.rightBarButtonItem = closeButton
        view.addGestureRecognizer(tapGesture)
        view.addSubview(scrollView)
        scrollView.addSubview(mainView)
        
        let views = [imageView, isConnectedLabel, tryToConnectButton, disconnectButton, batteryView, measurementsHistoryButton, detailsLabel, deviceNameField, multipleUsersView, deviceInfoView, removeDeviceButton]
        for view in views {
            mainView.addSubview(view)
        }
        
        scrollView.snp.makeConstraints {
            $0.edges.equalTo(view)
        }
        
        mainView.snp.makeConstraints {
            $0.top.bottom.equalTo(scrollView)
            $0.left.right.equalTo(view)
        }
        
        imageView.snp.makeConstraints {
            $0.top.equalToSuperview().inset(24)
            $0.height.equalTo(216)
            $0.left.right.equalToSuperview().inset(16)
        }
        isConnectedLabel.snp.makeConstraints {
            $0.top.equalTo(imageView.snp.bottom).offset(24)
            $0.centerX.equalToSuperview()
        }
        
        tryToConnectButton.snp.makeConstraints {
            $0.top.equalTo(isConnectedLabel.snp.bottom).offset(20)
            $0.centerX.equalToSuperview()
        }
        
        disconnectButton.snp.makeConstraints {
            $0.top.equalTo(isConnectedLabel.snp.bottom).offset(20)
            $0.centerX.equalToSuperview()
        }
        
        batteryView.snp.makeConstraints {
            $0.top.equalTo(tryToConnectButton.snp.bottom).offset(16)
            $0.centerX.equalToSuperview()
        }
        
        measurementsHistoryButton.snp.makeConstraints {
            $0.top.equalTo(batteryView.snp.bottom).offset(40)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
        }
        
        detailsLabel.snp.makeConstraints {
            $0.top.equalTo(measurementsHistoryButton.snp.bottom).offset(20)
            $0.left.equalToSuperview().inset(16)
        }
        
        deviceNameField.snp.makeConstraints {
            $0.top.equalTo(detailsLabel.snp.bottom).offset(18)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
        }
        
        multipleUsersView.snp.makeConstraints {
            $0.top.equalTo(deviceNameField.snp.bottom).offset(20)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
        }
        
        deviceInfoView.snp.makeConstraints {
            $0.left.right.equalTo(mainView).inset(16)
            $0.top.equalTo(multipleUsersView.snp.bottom).offset(20)
            $0.height.equalTo(216)
        }
        
        removeDeviceButton.snp.makeConstraints {
            $0.top.equalTo(deviceInfoView.snp.bottom).offset(40)
            $0.left.right.equalToSuperview().inset(16)
            $0.height.equalTo(56)
            $0.bottom.equalTo(mainView).offset(-20)
        }
    }
    
    private func bindControls() {
        closeButton.rx.tap
            .map { Intent.closeButton }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        tryToConnectButton.rx.tap
            .map { Intent.tryToConnectButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        disconnectButton.rx.tap
            .map { Intent.disconnectButtonIntent }
            .bind(to: _intents.subject)
            .disposed(by: bag)
        
        let connectionObservable = isConnectedSubject
            .map { item -> String in
                if item {
                    self.disconnectButton.isHidden = false
                    self.tryToConnectButton.isHidden = true
                    return "Connected"
                } else {
                    self.disconnectButton.isHidden = true
                    self.tryToConnectButton.isHidden = false
                    return "Disconnected"
                }
            }
        
        connectionObservable.bind(to: isConnectedLabel.rx.text)
            .disposed(by: bag)
    
    measurementsHistoryButton.rx.tap
        .map { Intent.measurementsHistoryIntent }
        .bind(to: _intents.subject)
        .disposed(by: bag)
    
    multipleUsersView.mySwitch.rx.controlEvent(.valueChanged)
        .withLatestFrom(multipleUsersView.mySwitch.rx.value)
        .subscribe(onNext: { bool in
            self._intents.subject.onNext(.changeMultipleUser(isMultipleUser: bool))
        })
        .disposed(by: bag)
    
    isSwitchOnSubject
        .bind(to: multipleUsersView.mySwitch.rx.isOn)
        .disposed(by: bag)
    
    tapGesture.rx.event
        .subscribe(onNext: { [weak self] _ in
            self?.view.endEditing(true)
        })
        .disposed(by: bag)
    
    deviceNameField.rx.controlEvent(.editingDidEnd)
        .debounce(.milliseconds(500), scheduler: MainScheduler.instance)
        .subscribe(onNext: { [weak self] in
            if let newName = self?.deviceNameField.text {
                if !newName.isEmpty {
                    self?._intents.subject.onNext(.updateNameOfDevice(newName: newName))
                }
            }
        })
        .disposed(by: bag)
    
    removeDeviceButton.rx.tap
        .subscribe(onNext: { [weak self] _ in
            self?._intents.subject.onNext(.showAlert)
        })
        .disposed(by: bag)
}

private func trigger(effect: Effect) {
    switch effect {
    case .dismiss:
        break
    case .showLatestMeasurementsScreen:
        break
    case .deviceNameChanged:
        break
    case .soleUserChoiceChanged:
        break
    case .showAlert:
        chooseAlert(type: .removeDevice(removeDeviceAction: { _ in
            self._intents.subject.onNext(.removeDevice)
        }, removeDeviceDataAction: { _ in
            self._intents.subject.onNext(.removeDeviceAndEraseData)
        }))
    case .deviceRemoved:
        break
    case .deviceAndDataErased:
        break
    }
}

func render(state: ViewState) {
    title = state.deviceData.deviceName
    isSwitchOnSubject.onNext(!state.deviceData.soleUser)
    deviceInfoView.updateDetailsValueLabel(labelType: .manufacturer, detailsValue: state.deviceData.manufacturerName ?? "")
    deviceInfoView.updateDetailsValueLabel(labelType: .serialNumber, detailsValue: state.deviceData.serialNumber ?? "")
    deviceInfoView.updateDetailsValueLabel(labelType: .model, detailsValue: state.deviceData.modelNumber ?? "")
    deviceInfoView.updateDetailsValueLabel(labelType: .firmware, detailsValue: state.deviceData.firmware ?? "")
    isConnectedSubject.onNext(state.isConnected)
}
// swiftlint:disable:next file_length
}
