//
//  DeviceDetailsScreenMiddleware.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import RxSwift

final class DeviceDetailsScreenMiddlewareImpl: DeviceDetailsScreenMiddleware, DeviceDetailsScreenCallback {
    typealias Dependencies = HasAppNavigation
    typealias Result = DeviceDetailsScreenResult
    
    private let dependencies: Dependencies

    private let middlewareSubject = PublishSubject<Result>()
    var middlewareObservable: Observable<Result> { return middlewareSubject }
    private let deviceId: String
    
    init(dependencies: Dependencies, deviceId: String) {
        self.dependencies = dependencies
        self.deviceId = deviceId
    }
    
    func process(result: Result) -> Observable<Result> {
        switch result {
        case .partialState(_): break
        case .effect(let effect):
            switch effect {
            case .dismiss:
                dependencies.appNavigation?.dismiss()
            case .showLatestMeasurementsScreen:
                dependencies.appNavigation?.showLatestMeasurementScreen(deviceID: deviceId)
            case .deviceNameChanged:
                break
            case .soleUserChoiceChanged:
                break
            case .showAlert:
                break
            case .deviceRemoved:
                dependencies.appNavigation?.dismiss()
            case .deviceAndDataErased:
                dependencies.appNavigation?.dismiss()
            }
        }
        return .just(result)
    }
}
