//
//  DeviceDetailsScreenBuilder.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import UIKit
import RxSwift

final class DeviceDetailsScreenBuilderImpl: DeviceDetailsScreenBuilder {
    typealias Dependencies = DeviceDetailsScreenInteractorImpl.Dependencies & DeviceDetailsScreenMiddlewareImpl.Dependencies
    private let dependencies: Dependencies
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
        
    func build(with input: DeviceDetailsScreenBuilderInput) -> DeviceDetailsScreenModule {
        let interactor = DeviceDetailsScreenInteractorImpl(dependencies: dependencies, input: input)
        let middleware = DeviceDetailsScreenMiddlewareImpl(dependencies: dependencies, deviceId: input.device.deviceID)
        let presenter = DeviceDetailsScreenPresenterImpl(interactor: interactor, middleware: middleware, initialViewState: DeviceDetailsScreenViewState(deviceData: input.device))
        let view = DeviceDetailsScreenViewController(presenter: presenter)
        return DeviceDetailsScreenModule(view: view, callback: middleware)
    }
}
