//
//  DeviceDetailsScreenInteractor.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import RxSwift
import Foundation

final class DeviceDetailsScreenInteractorImpl: DeviceDetailsScreenInteractor {
    typealias Dependencies = HasDevicesPersistanceService & HasBLEService
    typealias Result = DeviceDetailsScreenResult
    
    private let dependencies: Dependencies
    private let input: DeviceDetailsScreenBuilderInput
    
    init(dependencies: Dependencies, input: DeviceDetailsScreenBuilderInput) {
        self.dependencies = dependencies
        self.input = input
    }
    
    func connectToDevice() -> RxSwift.Observable<DeviceDetailsScreenResult> {
        dependencies.bleService.retrieveConnection(identifier: UUID(uuidString: input.device.deviceID)!)
        return Observable.empty()
    }
    
    func disconnectDevice() -> RxSwift.Observable<DeviceDetailsScreenResult> {
        dependencies.bleService.disconnectDevice(identifier: UUID(uuidString: input.device.deviceID)!)
        return Observable.empty()
    }
    
    func updateDeviceName(newName: String) -> RxSwift.Observable<DeviceDetailsScreenResult> {
        dependencies.devicesPersistanceService.updateDeviceName(id: input.device.deviceID, newName: newName)
        return .just(.effect(.deviceNameChanged))
    }
    
    func changeSoleUserChoice(isMultipleUser: Bool) -> RxSwift.Observable<DeviceDetailsScreenResult> {
        dependencies.devicesPersistanceService.updateSoleUserChoice(id: input.device.deviceID, isMultipleUser: isMultipleUser)
        return .just(.effect(.soleUserChoiceChanged))
    }
    
    func removeDevice() -> RxSwift.Observable<DeviceDetailsScreenResult> {
        dependencies.devicesPersistanceService.deleteDevice(id: input.device.deviceID)
        return .just(.effect(.deviceRemoved))
    }
    
    func removeDeviceAndEraseData() -> Observable<DeviceDetailsScreenResult> {
        dependencies.devicesPersistanceService.deleteDevice(id: input.device.deviceID)
        return .just(.effect(.deviceAndDataErased))
    }
    
    func checkIfDeviceConnected() -> RxSwift.Observable<DeviceDetailsScreenResult> {
        var isConnected = false
        return dependencies.bleService.connectedPeripheralObservable.map { peripherals in
            switch peripherals.isEmpty {
            case true: isConnected = false
            case false:   peripherals.map { device in
                if device.identifier.uuidString == self.input.device.deviceID {
                    isConnected = true
                } else {
                    isConnected = false
                }
                return device
            }
            }
            return .partialState(.checkConnectionState(isConnected: isConnected))
        }
        .asObservable()
    }
}
