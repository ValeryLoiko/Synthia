//
//  DeviceDetailsScreenContract.swift
//  Synthia
//
//  Created by Walery Łojko on 28/02/2023.
//

import RxSwift

enum DeviceDetailsScreenIntent {
    case viewLoaded
    case closeButton
    case measurementsHistoryIntent
    case updateNameOfDevice(newName: String)
    case changeMultipleUser(isMultipleUser: Bool)
    case showAlert
    case removeDevice
    case removeDeviceAndEraseData
    case tryToConnectButtonIntent
    case disconnectButtonIntent
}

struct DeviceDetailsScreenViewState: Equatable {
    var deviceData: Device
    var isConnected = false
}

enum DeviceDetailsScreenEffect: Equatable {
    case dismiss
    case showLatestMeasurementsScreen
    case deviceNameChanged
    case soleUserChoiceChanged
    case deviceRemoved
    case deviceAndDataErased
    case showAlert
}

struct DeviceDetailsScreenBuilderInput {
    var device: Device
}

protocol DeviceDetailsScreenCallback {
}

enum DeviceDetailsScreenResult: Equatable {
    case partialState(_ value: DeviceDetailsScreenPartialState)
    case effect(_ value: DeviceDetailsScreenEffect)
}

enum DeviceDetailsScreenPartialState: Equatable {
    case checkConnectionState(isConnected: Bool)
    func reduce(previousState: DeviceDetailsScreenViewState) -> DeviceDetailsScreenViewState {
        var state = previousState
        switch self {
        case .checkConnectionState(isConnected: let isConnected):
            state.isConnected = isConnected
        }
        return state
    }
}

protocol DeviceDetailsScreenBuilder {
    func build(with input: DeviceDetailsScreenBuilderInput) -> DeviceDetailsScreenModule
}

struct DeviceDetailsScreenModule {
    let view: DeviceDetailsScreenView
    let callback: DeviceDetailsScreenCallback
}

protocol DeviceDetailsScreenView: BaseView {
    var intents: Observable<DeviceDetailsScreenIntent> { get }
    func render(state: DeviceDetailsScreenViewState)
}

protocol DeviceDetailsScreenPresenter: AnyObject, BasePresenter {
    func bindIntents(view: DeviceDetailsScreenView, triggerEffect: PublishSubject<DeviceDetailsScreenEffect>) -> Observable<DeviceDetailsScreenViewState>
}

protocol DeviceDetailsScreenInteractor: BaseInteractor {
    func updateDeviceName(newName: String) -> Observable<DeviceDetailsScreenResult>
    func changeSoleUserChoice(isMultipleUser: Bool) -> Observable<DeviceDetailsScreenResult>
    func removeDevice() -> Observable<DeviceDetailsScreenResult>
    func removeDeviceAndEraseData() -> Observable<DeviceDetailsScreenResult>
    func connectToDevice() -> Observable<DeviceDetailsScreenResult>
    func checkIfDeviceConnected() -> Observable<DeviceDetailsScreenResult>
    func disconnectDevice() -> Observable<DeviceDetailsScreenResult>
}

protocol DeviceDetailsScreenMiddleware {
    var middlewareObservable: Observable<DeviceDetailsScreenResult> { get }
    func process(result: DeviceDetailsScreenResult) -> Observable<DeviceDetailsScreenResult>
}
