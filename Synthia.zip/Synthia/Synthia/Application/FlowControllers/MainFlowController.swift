import UIKit
import RxSwift

protocol HasAppNavigation {
    var appNavigation: AppNavigation? { get }
}

protocol AppNavigation: AnyObject {
    func startApplication()
    func showWelcomeScreen()
    func showLoginSignupScreen(openCase: LoginSignupCases)
    func showEmailLoginScreen()
    func showEmailSignupScreen()
    func showSettingsScreen()
    func showDevicesScreen()
    func showMeasurementsScreen()
    func showPasswordResetScreen()
    func dismissPasswordResetScreen()
    func showPasswordResetConfirmationScreen(email: String)
    func showAccountCreatedScreen()
    func showAccountSetUpScreen()
    func showAccountSetupSexScreen(accountInfo: AccountSetupModel)
    func showAccountSetupAge(accountInfo: AccountSetupModel)
    func showAccountSetupHeight(accountInfo: AccountSetupModel)
    func showGuideTour()
    func showSearchingScreen()
    func showListOfSupportedDevices()
    func dismiss()
    func showTermsConditionsScreen(email: String?, openCase: TermsConditionsCases)
    func showConfirmEmailScreen(email: String)
    func showLatestMeasurementScreen(deviceID: String)
    func showMeasurementHistoryGrouped(deviceID: String, measurementName: MeasurementName)
    func showMeasurementHistorySingle(deviceID: String, measurementName: MeasurementName, day: Date)
    func showDeviceDetailsScreen(device: Device)
    func showMeasurementsChartsScreen(measurementName: MeasurementName)
    func showAddDataList()
    func showAddData(dataType: MeasurementName)
    func showGeneralHistoryGrouped(measurementName: MeasurementName)
    func showGeneralHistorySingle(measurementName: MeasurementName, day: Date)
    func showPersonalDetails(userInfo: UserInfo)
}

final class MainFlowController: AppNavigation {
    typealias T = AssetsCatalog.TabBar
    typealias M = Localization.MeasurementsScreen
    typealias D = Localization.DevicesScreen
    typealias S = Localization.SettingsScreen
    typealias Dependencies = HasNavigation
    
    struct ExtendedDependencies: Dependencies, HasAppNavigation, HasCoreDataService, HasDevicesPersistanceService, HasMeasurementsPersistanceService, HasBLEService, HasHeartRateService, HasBatteryService, HasBloodPressureService, HasHealthThermometerService, HasBodyCompositionService, HasPulseOximeterService, HasBLEMeasurementsManager, HasNetworkingService, HasBLEConnectionManager, HasToastMessageService, HasKeychainManager, HasAccessManager, HasUserManager {
        private let dependencies: Dependencies
        weak var appNavigation: AppNavigation?
        var navigation: Navigation { dependencies.navigation }
        let accessManager: AccessManager
        let coreDataService: CoreDataService
        let devicesPersistanceService: DevicesPersistanceService
        let measurementsPersistanceService: MeasurementsPersistanceService
        let bleService: BLEService
        let bleConnectionManager: BLEConnectionManager
        let heartRateService: HeartRateService
        let batteryService: BatteryService
        let weightScaleService: WeightScaleService
        let bloodPressureService: BloodPressureService
        let healthThermometerService: HealthThermometerService
        let bodyCompositionService: BodyCompositionService
        let pulseOximeterService: PulseOximeterService
        let bleMeasurementsManager: BLEMeasurementsManager
        let networkingService: NetworkingService
        let keychainManager: KeychainManagerService
        let toastMessageService: ToastsMessageService
        let userManager: UserManager
        
        init(dependencies: Dependencies, appNavigation: AppNavigation) {
            self.dependencies = dependencies
            self.appNavigation = appNavigation
            self.coreDataService = CoreDataServiceImpl()
            self.toastMessageService = ToastMessageServiceImpl()
            self.keychainManager = KeychainManagerImpl()
            self.accessManager = AccessManagerImpl(keychainManager: keychainManager)
            self.networkingService = NetworkingServiceImpl(keychainManager: keychainManager, accessManager: accessManager)
            self.devicesPersistanceService = DevicesPersistanceServiceImpl(coreDataService: coreDataService, toastMessageService: toastMessageService)
            self.measurementsPersistanceService = MeasurementsPersistanceServiceImpl(coreDataService: coreDataService, networkingService: networkingService, toastMessageService: toastMessageService, keychainManager: keychainManager, accessManager: accessManager)
            self.bleService = BLEServiceImpl()
            self.bleService.turnOnCentralManager()
            self.bleConnectionManager = BLEConnectionManagerImpl(bluetoothService: bleService, devicesPersistanceService: devicesPersistanceService)
            self.heartRateService = HeartRateServiceImpl(bluetoothService: bleService)
            self.batteryService = BatteryServiceImpl(bluetoothService: bleService)
            self.weightScaleService = WeightScaleServiceImpl(bluetoothService: bleService)
            self.bloodPressureService = BloodPressureServiceImpl(bluetoothService: bleService)
            self.healthThermometerService = HealthThermometerServiceImpl(bluetoothService: bleService)
            self.bodyCompositionService = BodyCompositionServiceImpl(bluetoothService: bleService)
            self.pulseOximeterService = PulseOximeterServiceImpl(bluetoothService: bleService)
            
            self.userManager = UserManagerImpl(keychainManager: keychainManager, networkingService: networkingService, accessManager: accessManager, devicesPersistanceService: devicesPersistanceService, measurementsPersistanceService: measurementsPersistanceService)
            self.userManager.setUserInfo()
            self.bleMeasurementsManager = BLEMeasurementsManagerImpl(bluetoothService: bleService, measurementService: measurementsPersistanceService, heartRateService: heartRateService, bloodPressureService: bloodPressureService, batteryService: batteryService, bodyCompositionService: bodyCompositionService, healthThermometerService: healthThermometerService, pulseOximeterService: pulseOximeterService, weightScaleService: weightScaleService, networkingService: networkingService, keychainManager: keychainManager)
        }
    }
    
    // MARK: - Properties
    
    private let dependencies: Dependencies
    // swiftlint:disable: redundant_type_annotation
    private lazy var extendedDependencies: ExtendedDependencies = ExtendedDependencies(dependencies: dependencies, appNavigation: self)
    // swiftlint:enable: redundant_type_annotation
    
    // MARK: - Builders
    private lazy var welcomeScreenBuilder: WelcomeScreenBuilder = WelcomeScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var passwordResetScreenBuilder: PasswordResetScreenBuilder = PasswordResetScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var passwordResetConfirmationBuilder: PasswordResetConfirmationScreenBuilder = PasswordResetConfirmationScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var accountCreatedBuilder: AccountCreatedScreenBuilder = AccountCreatedScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var loginSignupScreenBuilder: LoginSignupScreenBuilder = LoginSignupScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var emailLoginScreenBuilder: EmailLoginScreenBuilder = EmailLoginScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var guideTourScreenBuilder: GuideTourScreenBuilder = GuideTourScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var measurementsScreenBuilder: MeasurementsScreenBuilder = MeasurementsScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var devicesScreenBuilder: DevicesScreenBuilder = DevicesScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var settingsScreenBuilder: SettingsScreenBuilder = SettingsScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var accountSetupNameBuilder: AccountSetupNameScreenBuilder = AccountSetupNameScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var accountSetupSexBuilder: AccountSetupSexScreenBuilder = AccountSetupSexScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var accountSetupAgeBuilder: AccountSetupAgeScreenBuilder = AccountSetupAgeScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var accountSetupHeightBuilder: AccountSetupHeightScreenBuilder = AccountSetupHeightScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var confirmEmailScreenBuilder: ConfirmEmailScreenBuilder = ConfirmEmailScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var emailSignupScreenBuilder: EmailSignupScreenBuilder = EmailSignupScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var termsConditionsScreenBuilder: TermsConditionsScreenBuilder = TermsConditionsScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var searchingScreenBuilder: SearchingScreenBuilder = SearchingScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var latestMeasurementScreenBuilder: LatestMeasurementsHistoryScreenBuilder = LatestMeasurementsHistoryScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var measurementHistoryGroupedBuilder: MeasurementsGroupedDataScreenBuilder = MeasurementsGroupedDataScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var measurementHistorySingleBuilder: MeasurementHistorySingleBuilder = MeasurementHistorySingleBuilderImpl(dependencies: extendedDependencies)
    private lazy var deviceDetailsScreenBuilder: DeviceDetailsScreenBuilder = DeviceDetailsScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var measurementChartsBuilder: MeasurementsChartScreenBuilder = MeasurementsChartScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var addDataListBuilder: AddDataListBuilder = AddDataListBuilderImpl(dependencies: extendedDependencies)
    private lazy var addDataBuilder: AddDataScreenBuilder = AddDataScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var generalHistoryGroupedBuilder: GeneralHistoryGroupedBuilder = GeneralHistoryGroupedBuilderImpl(dependencies: extendedDependencies)
    private lazy var generalHistorySingleBuilder: GeneralHistorySingleBuilder = GeneralHistorySingleBuilderImpl(dependencies: extendedDependencies)
    private lazy var supportedDevicesBuilder: SupportedDevicesScreenBuilder = SupportedDevicesScreenBuilderImpl(dependencies: extendedDependencies)
    private lazy var personalDetailsBuilder: PersonalDetailsScreenBuilder = PersonalDetailsScreenBuilderImpl(dependencies: extendedDependencies)
    
    // MARK: - Initialization
    
    init(dependencies: Dependencies) {
        self.dependencies = dependencies
    }
    
    // MARK: - AppNavigation
    func startApplication() {
        extendedDependencies.accessManager.userStateRelay
            .observe(on: MainScheduler.instance)
            .map { userState in
                switch userState {
                case .loggedIn:
                    self.showMeasurementsScreen()
                case .unregistered:
                    self.showWelcomeScreen()
                case .unknown:
                    self.showWelcomeScreen()
                }
            }
            .take(2)
            .subscribe()
    }
    
    func showWelcomeScreen() {
        let view = welcomeScreenBuilder.build(with: .init()).view
        dependencies.navigation.set(view: view, animated: true)
    }
    
    func showLoginSignupScreen(openCase: LoginSignupCases) {
        let view = loginSignupScreenBuilder.build(with: .init(openCase: openCase)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showEmailLoginScreen() {
        let view = emailLoginScreenBuilder.build(with: .init()).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showEmailSignupScreen() {
        let view = emailSignupScreenBuilder.build(with: .init()).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showGuideTour() {
        let view = guideTourScreenBuilder.build(with: .init()).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func dismiss() {
        dependencies.navigation.dismiss(completion: nil, animated: true)
    }
    
    func showPasswordResetScreen() {
        let view = passwordResetScreenBuilder.build(with: .init()).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func setTabBar() -> [UINavigationController] {
        let measurementScreen = measurementsScreenBuilder.build(with: .init()).view
        let deviceScreen = devicesScreenBuilder.build(with: .init()).view
        let settingsScreen = settingsScreenBuilder.build(with: .init()).view
        
        let measurementsVC = UINavigationController(rootViewController: measurementScreen as? UIViewController ?? UIViewController())
        let devicesVC = UINavigationController(rootViewController: deviceScreen as? UIViewController ?? UIViewController())
        let settingsVC = UINavigationController(rootViewController: settingsScreen as? UIViewController ?? UIViewController())
        
        let measurementsIcon = UIImage.assetImageName(T.tabBarMeasurements)
        let devicesIcon = UIImage.assetImageName(T.tabBarDevices)
        let settingsIcon = UIImage.assetImageName(T.tabBarSettings)
        
        let tabBarItemMeasurements = UITabBarItem(title: M.title, image: measurementsIcon, selectedImage: measurementsIcon)
        let tabBarItemDevices = UITabBarItem(title: D.title, image: devicesIcon, selectedImage: devicesIcon)
        let tabBarItemSettings = UITabBarItem(title: S.title, image: settingsIcon, selectedImage: settingsIcon)
        
        measurementsVC.tabBarItem = tabBarItemMeasurements
        devicesVC.tabBarItem = tabBarItemDevices
        settingsVC.tabBarItem = tabBarItemSettings
        let tabBarVCs = [measurementsVC, devicesVC, settingsVC]
        return tabBarVCs
    }
    
    func showMeasurementsScreen() {
        dependencies.navigation.setTabBar(viewControllers: setTabBar(), animated: true, selectedTab: 0)
    }
    
    func showDevicesScreen() {
        dependencies.navigation.setTabBar(viewControllers: setTabBar(), animated: true, selectedTab: 1)
    }
    
    func showSettingsScreen() {
        dependencies.navigation.setTabBar(viewControllers: setTabBar(), animated: true, selectedTab: 2)
    }
    
    func dismissPasswordResetScreen() {
        dependencies.navigation.dismiss(completion: nil, animated: true)
    }
    
    func showPasswordResetConfirmationScreen(email: String) {
        let view = passwordResetConfirmationBuilder.build(with: .init(email: email)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAccountCreatedScreen() {
        let view = accountCreatedBuilder.build(with: .init()).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAccountSetUpScreen() {
        let view = accountSetupNameBuilder.build(with: .init()).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAccountSetupSexScreen(accountInfo: AccountSetupModel) {
        let view = accountSetupSexBuilder.build(with: .init(accountInfo: accountInfo)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAccountSetupAge(accountInfo: AccountSetupModel) {
        let view = accountSetupAgeBuilder.build(with: .init(accountInfo: accountInfo)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAccountSetupHeight(accountInfo: AccountSetupModel) {
        let view = accountSetupHeightBuilder.build(with: .init(accountInfo: accountInfo)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showSearchingScreen() {
        let view = searchingScreenBuilder.build(with: .init()).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showListOfSupportedDevices() {
        let view = supportedDevicesBuilder.build(with: .init()).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showConfirmEmailScreen(email: String) {
        let view = confirmEmailScreenBuilder.build(with: .init(email: email)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showTermsConditionsScreen(email: String?, openCase: TermsConditionsCases) {
        let view = termsConditionsScreenBuilder.build(with: .init(email: email, openCase: openCase)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showLatestMeasurementScreen(deviceID: String) {
        let view = latestMeasurementScreenBuilder.build(with: .init(deviceID: deviceID)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showMeasurementHistoryGrouped(deviceID: String, measurementName: MeasurementName) {
        let view = measurementHistoryGroupedBuilder.build(with: .init(deviceID: deviceID, measurementName: measurementName)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showMeasurementHistorySingle(deviceID: String, measurementName: MeasurementName, day: Date) {
        let view = measurementHistorySingleBuilder.build(with: .init(deviceID: deviceID, measurementName: measurementName, date: day)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    func showDeviceDetailsScreen(device: Device) {
        let view = deviceDetailsScreenBuilder.build(with: .init(device: device)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showMeasurementsChartsScreen(measurementName: MeasurementName) {
        let view = measurementChartsBuilder.build(with: .init(chosenMeasurement: measurementName)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showAddDataList() {
        let view = addDataListBuilder.build(with: .init()).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showAddData(dataType: MeasurementName) {
        let view = addDataBuilder.build(with: .init(dataType: dataType)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    func showGeneralHistoryGrouped(measurementName: MeasurementName) {
        let view = generalHistoryGroupedBuilder.build(with: .init(measurementName: measurementName)).view
        dependencies.navigation.present(view: view, animated: true, completion: nil)
    }
    
    func showGeneralHistorySingle(measurementName: MeasurementName, day: Date) {
        let view = generalHistorySingleBuilder.build(with: .init(measurementName: measurementName, date: day)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    
    func showPersonalDetails(userInfo: UserInfo) {
        let view = personalDetailsBuilder.build(with: .init(userInfo: userInfo)).view
        dependencies.navigation.show(view: view, animated: true)
    }
    // swiftlint:disable:next file_length
}
