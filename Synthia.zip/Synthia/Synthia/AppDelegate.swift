//
//  AppDelegate.swift
//  Synthia
//
//  Created by Rafał Wojtuś on 07/12/2022.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {    
    // MARK: - Properties
    var window: UIWindow?
    
    private var mainFlowController: AppNavigation?
    private lazy var navigationController: UINavigationController = {
        let navigationController = UINavigationController()
        navigationController.navigationBar.isHidden = true
        return navigationController
    }()
    // swiftlint:disable redundant_type_annotation
    private lazy var synthiaDepenedencies: AppDependencies = AppDependencies(navigationController: navigationController)
    // swiftlint:enable redundant_type_annotation
    
    // MARK: - UIApplicationDelegate
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        setupInterface()
        checkIfFirstLaunch()
        return true
    }
    
    // MARK: - Private implementation
    
    private func setupInterface() {
        mainFlowController = MainFlowController(dependencies: synthiaDepenedencies)
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        window?.overrideUserInterfaceStyle = .light
        mainFlowController?.startApplication()
    }
    
    private func checkIfFirstLaunch() {
        let defaults = UserDefaults.standard
        if defaults.string(forKey: UserDefaultsKeys.isFirstLaunch) == nil {
            defaults.set("true", forKey: UserDefaultsKeys.isFirstLaunch)
        } else {
            defaults.set("false", forKey: UserDefaultsKeys.isFirstLaunch)
        }
    }
}

enum UserDefaultsKeys {
    static let isFirstLaunch = "isFirstLaunch"
}
